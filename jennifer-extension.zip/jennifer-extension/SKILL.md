---
name: jennifer-extension
description: Develop JENNIFER View Server extension modules (adapters) using Java and Kotlin. Supports Event, Transaction, Login, SSO, and System Event handlers with templates, examples, and Kubernetes metadata context.
---

# JENNIFER Extension Development Guide

JENNIFER APM 시스템의 확장 모듈(Event, Transaction, Login, SSO, System Event 어댑터) 개발을 위한 종합 가이드입니다.

## 목차

1. [어댑터 개요](#어댑터-개요)
2. [개발 환경 요구사항](#개발-환경-요구사항)
3. [프로젝트 생성](#프로젝트-생성)
4. [Event Adapter 개발](#event-adapter-개발)
5. [Transaction Adapter 개발](#transaction-adapter-개발)
6. [Login Adapter 개발](#login-adapter-개발)
7. [System Event Adapter 개발](#system-event-adapter-개발)
8. [공통 패턴](#공통-패턴)
9. [배포 및 설정](#배포-및-설정)
10. [API 레퍼런스](#api-레퍼런스)
11. [트러블슈팅](#트러블슈팅)
12. [베스트 프랙티스](#베스트-프랙티스)
13. [참고 자료](#참고-자료)

---

## 어댑터 개요

### 어댑터란?

JENNIFER Adapter는 JENNIFER APM 시스템의 데이터를 외부 시스템과 연동하거나, 외부 인증 시스템과 통합하기 위한 확장 모듈입니다.

### 지원 어댑터 유형

#### 1. Event Adapter
**목적**: JENNIFER 이벤트 발생 시 외부 서비스로 알림 전송

**사용 사례**:
- Slack, Teams, Telegram 등 메신저 알림
- Discord, LINE 등 채팅 플랫폼 연동
- 파일 로깅, SNMP Trap 전송
- Jira 이슈 자동 생성

**인터페이스**: `com.aries.extension.handler.EventHandler`

**핵심 메서드**:
```java
void on(EventData[] events)    // 배치로 이벤트 배열 수신
```

#### 2. Transaction Adapter
**목적**: X-View 실시간 트랜잭션 데이터 처리

**사용 사례**:
- 트랜잭션 로그 파일 저장
- 데이터베이스에 트랜잭션 기록
- 실시간 스트리밍 (Kafka, RabbitMQ)
- 외부 분석 시스템 연동

**인터페이스**: `com.aries.extension.handler.TransactionHandler`

**핵심 메서드**:
```java
void on(TransactionData[] transactions)    // 배치로 트랜잭션 배열 수신
```

#### 3. Login Adapter
**목적**: SSO 및 외부 인증 시스템 연동

**타입**:
- **PAGE 타입**: JENNIFER 로그인 페이지에서 직접 인증 (예: LDAP, AD)
- **SSO 타입**: 외부 시스템 인증 후 JENNIFER 자동 로그인 (예: SAML, OAuth)

**인터페이스**:
- `com.aries.extension.handler.LoginHandler` (PAGE 타입)
- `com.aries.extension.handler.SSOLoginHandler` (SSO 타입)

**핵심 메서드**:
```java
// PAGE 타입 (LoginHandler)
UserData preHandle(String id, String password)              // 인증 처리, UserData 반환
String redirect(String id, String password)                 // 리다이렉트 URL 반환

// SSO 타입 (SSOLoginHandler)
UserData preHandle(HttpServletRequest request)              // SSO 인증 처리
```

#### 4. System Event Adapter
**목적**: JENNIFER 데이터 서버의 시스템 레벨 이벤트 처리

**사용 사례**:
- 데이터 서버 상태 모니터링
- 시스템 이벤트 알림
- 인프라 이벤트 로깅
- 운영 알림 통합

**인터페이스**: `com.aries.extension.handler.SystemEventHandler`

**핵심 메서드**:
```java
void on(SystemEventData[] events)    // 배치로 시스템 이벤트 배열 수신
```

**특징**:
- 애플리케이션 이벤트(EventData)와 별도로 시스템 레벨 이벤트 처리
- JENNIFER 데이터 서버의 인프라/운영 이벤트에 특화
- 더 단순한 데이터 구조 (subject, message, dataServer)

---

## 개발 환경 요구사항

### 버전 요구사항 (중요)

| 구성요소 | 최소 버전 | 권장 버전 | 비고 |
|---------|----------|----------|------|
| **JENNIFER Server** | 5.5.0 | 5.6.5+ | 어댑터 배포 및 실행 환경 |
| **Extension Library** | 1.5.8 | 1.5.8 | LogUtil 및 K8s 메타데이터 포함, type=pom 필수 |
| **Java** | 17 | 17 | JENNIFER 5.5부터 필수 |
| **Kotlin** | 1.9.22 | 1.9.22 | Kotlin 개발 지원 (선택사항) |
| **Maven** | 3.6 | 3.9+ | 빌드 도구 |

### 권장 개발 환경

- **IDE**: IntelliJ IDEA, Eclipse, VSCode
- **Java SDK**: OpenJDK 17 또는 Oracle JDK 17
- **Kotlin SDK**: Kotlin 1.9.22 (선택사항)
- **Maven 저장소**: JenniferSoft Nexus 접근 설정

### 버전 호환성

- **JENNIFER 5.5 이전 버전**: Java 8 + Extension 이전 버전
- **JENNIFER 5.5 이상**: Java 17 + Extension 1.5.8 (필수)

---

## 프로젝트 생성

### 템플릿 사용법

이 스킬의 템플릿 파일에는 다음 플레이스홀더가 포함되어 있습니다:

| 플레이스홀더 | 설명 | 예시 |
|------------|------|------|
| `{SERVICE_NAME}` | 서비스 전체 이름 | Slack, Microsoft Teams, Telegram |
| `{SERVICE_CLASS}` | Java 클래스 이름 | Slack, Teams, Telegram |
| `{SERVICE_LOWER}` | 소문자 패키지명 | slack, teams, telegram |
| `{AUTHOR_NAME}` | 개발자 이름 | Your Name, Team Name |

**사용 예시**:

Slack 어댑터를 만들 경우:
```java
// 템플릿
package com.aries.{SERVICE_LOWER};
public class {SERVICE_CLASS}Adapter implements EventAdapter {

// 실제 코드
package com.aries.slack;
public class SlackAdapter implements EventAdapter {
```

**일괄 치환 방법**:
```bash
# Linux/Mac
sed -i 's/{SERVICE_NAME}/Slack/g' *.java
sed -i 's/{SERVICE_CLASS}/Slack/g' *.java
sed -i 's/{SERVICE_LOWER}/slack/g' *.java
sed -i 's/{AUTHOR_NAME}/Your Name/g' *.java

# Windows (PowerShell)
(Get-Content *.java) | ForEach-Object { $_ -replace '{SERVICE_NAME}', 'Slack' } | Set-Content *.java
```

---

## 프로젝트 생성

### 1. Maven 프로젝트 구조

```
jennifer-view-adapter-{service}/
├── pom.xml
└── src/
    └── main/
        └── java/
            └── com/aries/{service}/
                ├── {Service}Adapter.java
                ├── model/              # 선택사항
                └── util/               # 선택사항
```

### 2. pom.xml 설정

#### 기본 설정

```xml
<properties>
    <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
    <maven.compiler.source>17</maven.compiler.source>
    <maven.compiler.target>17</maven.compiler.target>
</properties>
```

#### JenniferSoft Nexus 저장소

```xml
<repositories>
    <repository>
        <id>jennifer-maven</id>
        <url>https://maven.jennifersoft.com/nexus/content/groups/public</url>
    </repository>
</repositories>
```

#### JENNIFER Extension 라이브러리

```xml
<dependencies>
    <!-- JENNIFER View Adapter Library (includes LogUtil) -->
    <dependency>
        <groupId>com.aries</groupId>
        <artifactId>extension</artifactId>
        <version>1.5.8</version>
        <type>pom</type>
    </dependency>

    <!-- JSON Processing (provided by JENNIFER) -->
    <dependency>
        <groupId>com.google.code.gson</groupId>
        <artifactId>gson</artifactId>
        <version>2.8.9</version>
        <scope>provided</scope>
    </dependency>
</dependencies>
```

#### 중요 사항

1. **extension 라이브러리**: `artifactId`를 `extension`으로, `type`을 `pom`으로 지정
   - extension 라이브러리에 LogUtil이 포함되어 있어 별도 로깅 라이브러리 불필요
2. **provided scope**: JENNIFER 서버에 이미 포함된 라이브러리는 반드시 `provided` 사용
   - gson (JSON 처리)
   - 기타 서버 기본 라이브러리
3. **maven-shade-plugin**: 외부 라이브러리 포함 시 서버 라이브러리 제외 설정

#### Maven Shade Plugin (외부 라이브러리 포함 시)

```xml
<build>
    <plugins>
        <plugin>
            <groupId>org.apache.maven.plugins</groupId>
            <artifactId>maven-shade-plugin</artifactId>
            <version>3.2.4</version>
            <executions>
                <execution>
                    <phase>package</phase>
                    <goals>
                        <goal>shade</goal>
                    </goals>
                    <configuration>
                        <artifactSet>
                            <excludes>
                                <!-- 제니퍼 서버에 이미 있는 라이브러리는 제외 -->
                                
                                <exclude>com.google.code.gson:*</exclude>
                                <exclude>com.aries:*</exclude>
                            </excludes>
                        </artifactSet>
                    </configuration>
                </execution>
            </executions>
        </plugin>
    </plugins>
</build>
```

---

## Event Adapter 개발

Event Adapter는 JENNIFER 이벤트 발생 시 외부 서비스로 알림을 전송합니다.

### 기본 구조

```java
package com.aries.slack;

import com.aries.extension.data.EventData;
import com.aries.extension.handler.EventHandler;
import com.aries.extension.util.PropertyUtil;
import com.aries.extension.util.LogUtil;


public class SlackAdapter implements EventHandler {

    private String adapterId;

    @Override
    public void setAdapterId(String adapterId) {
        this.adapterId = adapterId;
    }

    @Override
    public void on(EventData[] events) {
        // 배치 처리: 여러 이벤트를 한 번에 처리
        for (EventData eventData : events) {
            try {
                // 1. 옵션 가져오기
                String webhookUrl = PropertyUtil.getValue(adapterId, "webhook_url", "");
                if (webhookUrl.isEmpty()) {
                    LogUtil.error("webhook_url is not configured");
                    return;
                }

                // 2. 이벤트 데이터 추출
                String domainName = eventData.getDomainName();
                String instanceName = eventData.getInstanceName();
                String eventLevel = eventData.getEventLevel();
                String message = eventData.getMessage();

                // 3. 메시지 생성
                String slackMessage = buildMessage(eventData);

                // 4. 외부 서비스로 전송
                sendNotification(webhookUrl, slackMessage);

            } catch (Exception e) {
                LogUtil.error("Failed to send notification", e);
            }
        }
    }

    private String buildMessage(EventData eventData) {
        // 메시지 포맷 구현
        return "Event: " + eventData.getMessage();
    }

    private void sendNotification(String webhookUrl, String message) throws Exception {
        // HTTP POST 구현
    }
}
```

### EventData API

```java
// Domain Information
short getDomainId()                          // Domain ID (short type)
List<String> getDomainGroupHierarchy()       // Domain group hierarchy
String getDomainName()                       // Domain name
String getDomainDescription()                // Domain description
String getBusinessName()                     // Business name

// Instance Information
int getInstanceId()                          // Instance ID
String getInstanceName()                     // Instance name
String getInstanceDescription()              // Instance description
InstanceData getInstanceData()               // Detailed instance data (nested object)

// Event Details
long getTime()                               // Event timestamp (milliseconds)
String getErrorType()                        // Error type
String getMetricsName()                      // Metrics name
String getEventLevel()                       // Event severity (FATAL, WARNING, CRITICAL, INFO)
String getMessage()                          // Event message
double getValue()                            // Numeric value
String getOtype()                            // Object type
String getDetailMessage()                    // Detailed message
String getServiceName()                      // Service name
long getTxid()                               // Transaction ID
String getCustomMessage()                    // Custom message
```

#### InstanceData (Nested Object)

`EventData`와 `TransactionData`는 인프라 및 에이전트 상세 정보를 포함하는 `InstanceData` 객체를 내포하고 있습니다. 특히 1.5.8 버전부터 쿠버네티스 환경을 위한 메타데이터를 추가로 제공합니다:

```java
InstanceData instanceData = eventData.getInstanceData();

// InstanceData 주요 메서드
int getInstanceId()                          // 인스턴스 ID
String getVersion()                          // 에이전트 버전
String getDescription()                      // 인스턴스 설명
String getIpAddress()                        // IP 주소
String getPlatform()                         // 플랫폼 (Java, .NET 등)
String getHostName()                         // 호스트 이름
String getConfigFilePath()                   // 에이전트 설정 파일 경로
K8s getK8s()                                 // 쿠버네티스 메타데이터 (nullable)

// K8s 객체 주요 메서드
String getContainerIdHint()                  // 컨테이너 ID 힌트
String getPodUid()                           // Pod UID
String getContainerName()                    // 컨테이너 이름
String getNodeName()                         // 노드 이름
```

### PropertyUtil 사용법

```java
// 기본값과 함께 옵션 가져오기
String webhookUrl = PropertyUtil.getValue(adapterId, "webhook_url", "");
String jenniferUrl = PropertyUtil.getValue(adapterId, "jennifer_url", "");
boolean enabled = Boolean.parseBoolean(PropertyUtil.getValue(adapterId, "enabled", "true"));
int timeout = Integer.parseInt(PropertyUtil.getValue(adapterId, "timeout", "5000"));
```

### X-View 링크 생성

```java
private String buildXViewUrl(EventData eventData) {
    String jenniferUrl = PropertyUtil.getValue(adapterId, "jennifer_url", "");
    if (jenniferUrl.isEmpty()) {
        return null;
    }

    return String.format("%s/popup/xview?domainId=%d&time=%d",
        jenniferUrl,
        eventData.getDomainId(),
        eventData.getTime()
    );
}
```

### HTTP 클라이언트 패턴

#### HttpURLConnection (권장 - 기본)

```java
private void sendNotification(String webhookUrl, String jsonPayload) throws Exception {
    HttpURLConnection connection = null;
    try {
        URL url = new URL(webhookUrl);
        connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("POST");
        connection.setRequestProperty("Content-Type", "application/json");
        connection.setDoOutput(true);

        // 타임아웃 설정
        connection.setConnectTimeout(5000);
        connection.setReadTimeout(10000);

        try (OutputStream os = connection.getOutputStream()) {
            os.write(jsonPayload.getBytes(StandardCharsets.UTF_8));
        }

        int responseCode = connection.getResponseCode();
        if (responseCode < 200 || responseCode >= 300) {
            LogUtil.warn("Unexpected response code: " + responseCode);
        }

    } finally {
        if (connection != null) {
            connection.disconnect();
        }
    }
}
```

### 메시지 포맷 예제

#### Slack (Attachment)

```java
private String buildSlackMessage(EventData eventData) {
    JsonObject attachment = new JsonObject();
    attachment.addProperty("color", getColor(eventData.getEventLevel()));
    attachment.addProperty("title", "JENNIFER Event: " + eventData.getEventName());

    JsonArray fields = new JsonArray();
    fields.add(createField("Domain", eventData.getDomainName(), true));
    fields.add(createField("Instance", eventData.getInstanceName(), true));
    fields.add(createField("Level", eventData.getEventLevel(), true));

    attachment.add("fields", fields);

    JsonArray attachments = new JsonArray();
    attachments.add(attachment);

    JsonObject root = new JsonObject();
    root.add("attachments", attachments);

    return root.toString();
}

private String getColor(String eventLevel) {
    switch (eventLevel) {
        case "FATAL":
        case "CRITICAL":
            return "#FF0000";  // 빨간색
        case "WARNING":
            return "#FFA500";  // 주황색
        default:
            return "#36A64F";  // 초록색
    }
}
```

---

## Transaction Adapter 개발

Transaction Adapter는 X-View 실시간 트랜잭션 데이터를 처리합니다.

### 기본 구조

```java
package com.aries.xviewlog;

import com.aries.extension.data.TransactionData;
import com.aries.extension.handler.TransactionHandler;
import com.aries.extension.util.PropertyUtil;
import com.aries.extension.util.LogUtil;


public class LogAdapter implements TransactionHandler {

    private String adapterId;

    @Override
    public void setAdapterId(String adapterId) {
        this.adapterId = adapterId;
    }

    @Override
    public void on(TransactionData[] transactions) {
        // 배치 처리: 여러 트랜잭션을 한 번에 처리
        for (TransactionData txData : transactions) {
            try {
                // 1. 옵션 가져오기
                String fullPath = PropertyUtil.getValue(adapterId, "full_path", "");
                String pattern = PropertyUtil.getValue(adapterId, "pattern", DEFAULT_PATTERN);
                boolean rollingMode = Boolean.parseBoolean(PropertyUtil.getValue(adapterId, "rolling_mode", "true"));

                // 2. 로그 메시지 생성
                String logMessage = buildLogMessage(txData, pattern);

                // 3. 파일에 기록
                writeLog(fullPath, logMessage, rollingMode);

            } catch (Exception e) {
                LogUtil.error("Failed to write transaction log", e);
            }
        }
    }
}
```

### TransactionData API

```java
// Domain & Instance
short getDomainId()                    // Domain ID (short type)
String getDomainName()                 // Domain 이름
int getInstanceId()                    // Instance ID
String getInstanceName()               // Instance 이름
String getApplicationName()            // Application 이름

// Transaction ID
long getTxid()                         // Transaction ID (long type)
String getGuid()                       // Global unique identifier

// User Context
String getClientIp()                   // Client IP address
long getClientId()                     // Client identifier (long type)
String getUserId()                     // User identifier

// Timing Information (milliseconds)
int getNetworkTime()                   // 네트워크 시간
int getFrontendTime()                  // 프론트엔드 시간
long getStartTime()                    // 트랜잭션 시작 시간
long getEndTime()                      // 트랜잭션 종료 시간
long getCollectTime()                  // 데이터 수집 시간
int getResponseTime()                  // 총 응답 시간
int getCpuTime()                       // CPU 처리 시간
int getSqlTime()                       // SQL 실행 시간
int getFetchTime()                     // 데이터 fetch 시간
int getExternalcallTime()              // 외부 호출 시간

// Error Information
String getErrorType()                  // 에러 타입 (있는 경우)
```

### 파일 로깅 패턴

#### BufferedWriter (권장)

```java
private synchronized void writeLog(String logPath, String message) throws IOException {
    try (FileWriter fw = new FileWriter(logPath, true);
         BufferedWriter bw = new BufferedWriter(fw)) {
        bw.write(message);
        bw.newLine();
    }
}
```

#### 날짜 기반 롤링

```java
private String resolveDatePattern(String path) {
    if (!path.contains("%d{")) {
        return path;
    }

    int start = path.indexOf("%d{");
    int end = path.indexOf("}", start);

    String datePattern = path.substring(start + 3, end);
    SimpleDateFormat sdf = new SimpleDateFormat(datePattern);
    String dateStr = sdf.format(new Date());

    return path.substring(0, start) + dateStr + path.substring(end + 1);
}

// 사용 예시
// ../logs/xview.%d{yyyy-MM-dd_HH}.log → ../logs/xview.2025-11-10_14.log
```

### 로그 포맷 패턴

```java
private static final String DEFAULT_PATTERN =
    "[%startTime, %endTime] " +
    "Domain=%domainName, " +
    "Instance=%instanceName, " +
    "TXID=%txid, " +
    "Response Time=%responseTime ms";

private String buildLogMessage(TransactionData txData, String pattern) {
    SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");

    return pattern
        .replace("%startTime", sdf.format(new Date(txData.getStartTime())))
        .replace("%endTime", sdf.format(new Date(txData.getEndTime())))
        .replace("%domainName", nvl(txData.getDomainName()))
        .replace("%instanceName", nvl(txData.getInstanceName()))
        .replace("%txid", String.valueOf(txData.getTxid()))
        .replace("%responseTime", String.valueOf(txData.getResponseTime()));
}

private String nvl(String value) {
    return value != null ? value : "";
}
```

---

## Login Adapter 개발

Login Adapter는 외부 인증 시스템과 JENNIFER를 연동합니다.

### PAGE 타입 (LDAP 인증)

```java
package com.aries.login.ldap;

import com.aries.extension.handler.LoginHandler;
import com.aries.extension.data.UserData;
import com.aries.extension.util.PropertyUtil;
import com.aries.extension.util.LogUtil;

import javax.naming.Context;
import javax.naming.NamingException;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;
import java.util.Hashtable;

public class LdapLoginAdapter implements LoginHandler {

    private String adapterId;

    @Override
    public void setAdapterId(String adapterId) {
        this.adapterId = adapterId;
    }

    @Override
    public UserData preHandle(String id, String password) {
        try {
            // 1. LDAP 서버 연결
            String serverUrl = PropertyUtil.getValue(adapterId, "serverUrl", "ldap://localhost:389");
            String adminDn = PropertyUtil.getValue(adapterId, "adminDn", "");
            String adminPwd = PropertyUtil.getValue(adapterId, "adminPwd", "");

            LdapContext ctx = connectLdap(serverUrl, adminDn, adminPwd);

            // 2. 사용자 인증
            boolean authenticated = authenticateUser(ctx, id, password);

            if (!authenticated) {
                LogUtil.warn("LDAP authentication failed for user: " + id);
                return null;  // 인증 실패
            }

            // 3. 사용자 그룹 조회
            String groupId = getUserGroup(ctx, id);

            // 4. UserData 반환
            LogUtil.info("LDAP authentication successful for user: " + id);
            return new UserData(id, password, groupId);

        } catch (Exception e) {
            LogUtil.error("LDAP authentication error for user: " + id, e);
            return null;  // 인증 실패
        }
    }

    @Override
    public String redirect(String id, String password) {
        // 외부 인증 페이지로 리다이렉트가 필요한 경우 URL 반환
        // LDAP는 직접 인증하므로 null 반환
        return null;
    }

    private LdapContext connectLdap(String serverUrl, String adminDn, String adminPwd) throws NamingException {
        Hashtable<String, String> env = new Hashtable<>();
        env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
        env.put(Context.PROVIDER_URL, serverUrl);
        env.put(Context.SECURITY_AUTHENTICATION, "simple");
        env.put(Context.SECURITY_PRINCIPAL, adminDn);
        env.put(Context.SECURITY_CREDENTIALS, adminPwd);

        return new InitialLdapContext(env, null);
    }

    private boolean authenticateUser(LdapContext ctx, String userId, String password) {
        // LDAP 사용자 인증 로직 구현
        return true;
    }

    private String getUserGroup(LdapContext ctx, String userId) {
        // LDAP에서 사용자 그룹 조회
        return "Users";
    }
}
```

### SSO 타입 (Token 기반)

```java
package com.aries.login.sso;

import com.aries.extension.handler.SSOLoginHandler;
import com.aries.extension.data.UserData;
import com.aries.extension.util.PropertyUtil;
import com.aries.extension.util.LogUtil;

import javax.servlet.http.HttpServletRequest;

public class SsoLoginAdapter implements SSOLoginHandler {

    private String adapterId;

    @Override
    public void setAdapterId(String adapterId) {
        this.adapterId = adapterId;
    }

    @Override
    public UserData preHandle(HttpServletRequest request) {
        try {
            // 1. HTTP 요청에서 SSO 토큰 추출
            String ssoToken = request.getHeader("X-SSO-Token");
            if (ssoToken == null || ssoToken.isEmpty()) {
                LogUtil.warn("SSO token not found in request");
                return null;  // 인증 실패
            }

            // 2. SSO 토큰 검증
            String userId = validateSSOToken(ssoToken);
            if (userId == null) {
                LogUtil.warn("Invalid SSO token");
                return null;  // 인증 실패
            }

            // 3. JENNIFER 계정으로 매핑
            String jenniferUserId = PropertyUtil.getValue(adapterId, "JENNIFER_USER_ID", "guest");
            String jenniferPassword = PropertyUtil.getValue(adapterId, "JENNIFER_PASSWORD", "guest");

            // 4. UserData 반환
            LogUtil.info("SSO authentication successful for user: " + userId);
            return new UserData(jenniferUserId, jenniferPassword, "SSO-Users");

        } catch (Exception e) {
            LogUtil.error("SSO authentication error", e);
            return null;  // 인증 실패
        }
    }

    private String validateSSOToken(String token) {
        // SSO 토큰 검증 및 사용자 ID 추출 로직
        // 실제 구현: JWT 검증, OAuth2 토큰 검증 등
        return "user@example.com";
    }
}
```

### UserData 사용법

```java
// PAGE 타입 - 기본 인증 성공
@Override
public UserData preHandle(String id, String password) {
    if (authenticateLDAP(id, password)) {
        return new UserData(id, password, "Developers");
    }
    return null;  // 인증 실패
}

// SSO 타입 - 전체 정보 포함
@Override
public UserData preHandle(HttpServletRequest request) {
    String userId = extractFromSSOToken(request);
    if (userId != null) {
        return new UserData(userId, "auto-password", "SSO-Users",
                          "John Doe", "john@example.com", "ACME", "Engineering", "Developer", "010-1234-5678");
    }
    return null;  // 인증 실패
}
```

---

## System Event Adapter 개발

System Event Adapter는 JENNIFER 데이터 서버의 시스템 레벨 이벤트를 처리합니다.

### 기본 구조

```java
package com.aries.systemevent;

import com.aries.extension.data.SystemEventData;
import com.aries.extension.handler.SystemEventHandler;
import com.aries.extension.util.PropertyUtil;
import com.aries.extension.util.LogUtil;


public class SystemEventAdapter implements SystemEventHandler {

    private String adapterId;

    @Override
    public void setAdapterId(String adapterId) {
        this.adapterId = adapterId;
    }

    @Override
    public void on(SystemEventData[] events) {
        // 배치 처리: 여러 시스템 이벤트를 한 번에 처리
        for (SystemEventData event : events) {
            try {
                // 1. 시스템 이벤트 정보 추출
                String subject = event.getSubject();
                String message = event.getMessage();
                String dataServer = event.getDataServer();

                LogUtil.info("System Event - Server: " + dataServer +
                           ", Subject: " + subject +
                           ", Message: " + message);

                // 2. 알림 전송 또는 로깅
                handleSystemEvent(event);

            } catch (Exception e) {
                LogUtil.error("Failed to process system event", e);
            }
        }
    }

    private void handleSystemEvent(SystemEventData event) {
        // 시스템 이벤트 처리 로직
        // 예: 이메일 전송, 로그 파일 기록, 모니터링 시스템 연동 등
    }
}
```

### SystemEventData API

```java
String getSubject()        // 이벤트 제목/주제
String getMessage()        // 이벤트 메시지/설명
String getDataServer()     // 데이터 서버 식별자
```

### 사용 예시

#### 시스템 이벤트 로깅

```java
@Override
public void on(SystemEventData[] events) {
    String logPath = PropertyUtil.getValue(adapterId, "log_path", "./system_events.log");

    try (FileWriter fw = new FileWriter(logPath, true);
         BufferedWriter bw = new BufferedWriter(fw)) {

        for (SystemEventData event : events) {
            String logLine = String.format("[%s] %s - %s: %s",
                new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()),
                event.getDataServer(),
                event.getSubject(),
                event.getMessage()
            );

            bw.write(logLine);
            bw.newLine();
        }

    } catch (IOException e) {
        LogUtil.error("Failed to write system event log", e);
    }
}
```

#### 시스템 이벤트 이메일 알림

```java
@Override
public void on(SystemEventData[] events) {
    String smtpHost = PropertyUtil.getValue(adapterId, "smtp_host", "");
    String recipient = PropertyUtil.getValue(adapterId, "recipient", "");

    for (SystemEventData event : events) {
        try {
            String emailBody = buildEmailBody(event);
            sendEmail(smtpHost, recipient, event.getSubject(), emailBody);

            LogUtil.info("System event email sent for: " + event.getSubject());

        } catch (Exception e) {
            LogUtil.error("Failed to send system event email", e);
        }
    }
}

private String buildEmailBody(SystemEventData event) {
    return "Data Server: " + event.getDataServer() + "\n" +
           "Subject: " + event.getSubject() + "\n" +
           "Message: " + event.getMessage();
}
```

### EventData vs SystemEventData 비교

| 항목 | EventData | SystemEventData |
|------|-----------|-----------------|
| **용도** | 애플리케이션 성능 이벤트 | 시스템/인프라 이벤트 |
| **데이터 소스** | 모니터링 중인 애플리케이션 인스턴스 | JENNIFER 데이터 서버 |
| **복잡도** | 높음 (16+ 필드, nested object) | 낮음 (3개 필드) |
| **도메인 정보** | ✓ (domainId, domainName 등) | ✗ |
| **인스턴스 정보** | ✓ (instanceId, instanceData 등) | ✗ |
| **서버 정보** | ✗ | ✓ (dataServer) |
| **사용 사례** | 애플리케이션 에러 알림, 성능 이슈 | 서버 상태 알림, 인프라 모니터링 |

---

## 공통 패턴

### 에러 핸들링

```java
@Override
public void on(EventData eventData) {
    try {
        // 어댑터 로직
        sendNotification(...);

    } catch (java.net.SocketTimeoutException e) {
        LogUtil.warn("Timeout: " + e.getMessage());

    } catch (java.net.UnknownHostException e) {
        LogUtil.error("Unknown host: " + e.getMessage());

    } catch (Exception e) {
        LogUtil.error("Unexpected error", e);
    }
}
```

**핵심 원칙**: 어댑터의 에러는 절대 JENNIFER 서버의 동작을 멈추게 해서는 안 됩니다.

### 로깅 전략

```java
// DEBUG: 디버깅용
LogUtil.debug("Processing event: " + eventData.getEventName());

// INFO: 정상 동작
LogUtil.info("Notification sent successfully");

// WARN: 일시적 문제
LogUtil.warn("Timeout sending notification");

// ERROR: 심각한 오류
LogUtil.error("Failed to send notification", e);
```

### LogUtil 사용 가이드

JENNIFER는 로깅을 위해 `com.aries.extension.util.LogUtil`을 제공합니다.

#### 기본 사용법

```java
import com.aries.extension.util.LogUtil;

public class MyAdapter implements EventHandler {
    
    @Override
    public void on(EventData eventData) {
        // Logger 인스턴스 선언 불필요
        LogUtil.info("Processing event: " + eventData.getEventName());
        
        try {
            // 어댑터 로직
        } catch (Exception e) {
            LogUtil.error("Failed to process event", e);
        }
    }
}
```

#### 지원 메서드

| 메서드 | 설명 | 사용 시점 |
|--------|------|----------|
| `LogUtil.debug(String message)` | 디버깅 정보 | 개발/디버깅 시 상세 정보 |
| `LogUtil.info(String message)` | 일반 정보 | 정상 동작 로그 |
| `LogUtil.warn(String message)` | 경고 | 일시적 문제, 설정 누락 |
| `LogUtil.error(String message)` | 에러 | 심각한 오류 (스택 트레이스 없음) |
| `LogUtil.error(String message, Throwable e)` | 에러 + 예외 | 예외 발생 시 (스택 트레이스 포함) |

#### 파라미터 포맷

LogUtil은 문자열 연결 방식을 사용합니다:

```java
// ✅ 올바른 사용법
LogUtil.info("User " + userId + " logged in");
LogUtil.warn("Timeout after " + timeout + "ms");
LogUtil.error("Failed to connect to " + host + ":" + port);

// ❌ SLF4J 스타일 (사용 불가)
// LogUtil.info("User {} logged in", userId);  // 작동하지 않음
```

#### 로그 레벨 설정

JENNIFER 서버의 `logback.xml`에서 어댑터별 로그 레벨 설정:

```xml
<!-- $JENNIFER_HOME/conf/logback.xml -->
<logger name="com.aries.slack" level="DEBUG"/>
<logger name="com.aries.telegram" level="INFO"/>
```

#### LogUtil vs SLF4J 비교

| 항목 | LogUtil | SLF4J Logger |
|------|---------|--------------|
| **의존성** | extension 라이브러리 포함 | 별도 라이브러리 필요 |
| **인스턴스** | 불필요 (static 메서드) | 필요 (`LoggerFactory.getLogger()`) |
| **파라미터** | 문자열 연결 (`+`) | 플레이스홀더 (`{}`) |
| **JENNIFER 통합** | 완벽 지원 | provided scope 필요 |

#### 베스트 프랙티스

```java
// 1. 메시지는 명확하게
LogUtil.error("Failed to send webhook to Slack"); // ✅ 명확함
LogUtil.error("Error occurred");                  // ❌ 불명확함

// 2. 예외는 항상 포함
try {
    sendNotification(url, message);
} catch (Exception e) {
    LogUtil.error("Failed to send notification", e); // ✅ 스택 트레이스 포함
}

// 3. 민감 정보 제외
LogUtil.info("Connecting to " + host);           // ✅ 안전
LogUtil.info("Using password: " + password);     // ❌ 보안 위험

// 4. 적절한 레벨 사용
LogUtil.debug("Request body: " + jsonPayload);   // 디버깅용 상세 정보
LogUtil.info("Notification sent successfully");  // 정상 동작
LogUtil.warn("Retry attempt 3/3");               // 일시적 문제
LogUtil.error("Connection refused", e);          // 심각한 오류
```

---

## 배포 및 설정

### 1. 빌드

```bash
mvn clean package
```

생성된 JAR: `target/jennifer-view-adapter-{service}-1.0.0.jar`

### 2. JENNIFER 서버에 배포

```bash
cp target/jennifer-view-adapter-{service}-1.0.0.jar $JENNIFER_HOME/adapter/
```

### 3. JENNIFER 서버 재시작

```bash
$JENNIFER_HOME/bin/jennifer stop
$JENNIFER_HOME/bin/jennifer start
```

### 4. 관리 UI에서 어댑터 등록

1. JENNIFER 관리 UI 접속
2. **어댑터 관리** > **추가**
3. JAR 파일 선택
4. 어댑터 클래스 지정 (예: `com.aries.slack.SlackAdapter`)
5. 옵션 설정

### 5. 이벤트 정책에 연결

1. **이벤트 정책 관리**
2. 특정 정책 선택
3. 등록한 어댑터 체크

---

## API 레퍼런스

### EventData 메서드

#### Domain Information

| 메서드 | 반환 타입 | 설명 |
|--------|----------|------|
| getDomainId() | short | Domain ID (주의: short 타입) |
| getDomainGroupHierarchy() | List<String> | Domain 그룹 계층 구조 |
| getDomainName() | String | Domain 이름 |
| getDomainDescription() | String | Domain 설명 |
| getBusinessName() | String | 비즈니스 이름 |

#### Instance Information

| 메서드 | 반환 타입 | 설명 |
|--------|----------|------|
| getInstanceId() | int | Instance ID |
| getInstanceName() | String | Instance 이름 |
| getInstanceDescription() | String | Instance 설명 |
| getInstanceData() | InstanceData | 인스턴스 상세 정보 (nested object) |

#### Event Details

| 메서드 | 반환 타입 | 설명 |
|--------|----------|------|
| getTime() | long | 이벤트 발생 시간 (milliseconds) |
| getErrorType() | String | 에러 타입 |
| getMetricsName() | String | 메트릭 이름 |
| getEventLevel() | String | 이벤트 레벨 (FATAL, WARNING, CRITICAL, INFO) |
| getMessage() | String | 이벤트 메시지 |
| getValue() | double | 이벤트 값 (숫자) |
| getOtype() | String | 객체 타입 |
| getDetailMessage() | String | 상세 메시지 |
| getServiceName() | String | 서비스 이름 |
| getTxid() | long | 트랜잭션 ID |
| getCustomMessage() | String | 사용자 정의 메시지 |

#### InstanceData 메서드 (Nested Object)

| 메서드 | 반환 타입 | 설명 |
|--------|----------|------|
| getInstanceId() | int | Instance ID |
| getVersion() | String | 애플리케이션/에이전트 버전 |
| getDescription() | String | Instance 설명 |
| getIpAddress() | String | IP 주소 |
| getPlatform() | String | 플랫폼 (Java, .NET 등) |
| getHostName() | String | 호스트 이름 |
| getConfigFilePath() | String | 설정 파일 경로 |

### TransactionData 메서드

#### Domain & Instance

| 메서드 | 반환 타입 | 설명 |
|--------|----------|------|
| getDomainId() | short | Domain ID (주의: short 타입) |
| getDomainName() | String | Domain 이름 |
| getInstanceId() | int | Instance ID |
| getInstanceName() | String | Instance 이름 |
| getApplicationName() | String | Application 이름 |

#### Transaction ID

| 메서드 | 반환 타입 | 설명 |
|--------|----------|------|
| getTxid() | long | 트랜잭션 ID (주의: long 타입) |
| getGuid() | String | Global unique identifier |

#### User Context

| 메서드 | 반환 타입 | 설명 |
|--------|----------|------|
| getClientIp() | String | 클라이언트 IP 주소 |
| getClientId() | long | 클라이언트 ID (주의: long 타입) |
| getUserId() | String | 사용자 ID |

#### Timing Information (milliseconds)

| 메서드 | 반환 타입 | 설명 |
|--------|----------|------|
| getNetworkTime() | int | 네트워크 시간 (ms) |
| getFrontendTime() | int | 프론트엔드 시간 (ms) |
| getStartTime() | long | 트랜잭션 시작 시간 |
| getEndTime() | long | 트랜잭션 종료 시간 |
| getCollectTime() | long | 데이터 수집 시간 |
| getResponseTime() | int | 총 응답 시간 (ms) |
| getCpuTime() | int | CPU 처리 시간 (ms) |
| getSqlTime() | int | SQL 실행 시간 (ms) |
| getFetchTime() | int | 데이터 fetch 시간 (ms) |
| getExternalcallTime() | int | 외부 호출 시간 (ms) |

#### Error Information

| 메서드 | 반환 타입 | 설명 |
|--------|----------|------|
| getErrorType() | String | 에러 타입 (에러 발생 시) |

### SystemEventData 메서드

| 메서드 | 반환 타입 | 설명 |
|--------|----------|------|
| getSubject() | String | 이벤트 제목/주제 |
| getMessage() | String | 이벤트 메시지/설명 |
| getDataServer() | String | 데이터 서버 식별자 |

**특징**:
- 애플리케이션 이벤트(EventData)보다 단순한 구조
- JENNIFER 데이터 서버의 시스템 레벨 이벤트 전용
- 도메인/인스턴스 정보 없음

### UserData 클래스

Login Adapter는 인증 성공 시 `UserData` 객체를 반환합니다. 인증 실패 시에는 `null`을 반환합니다.

#### 생성자

UserData는 3가지 생성자를 제공합니다:

```java
// 1. 기본 생성자 (ID와 Password만)
UserData userData = new UserData(id, password);

// 2. Group ID 포함 생성자
UserData userData = new UserData(id, password, groupId);

// 3. 전체 정보 생성자
UserData userData = new UserData(id, password, groupId, name, email, company, dept, jobTitle, cellphone);
```

#### 필드

| 필드 | 타입 | 필수 | 설명 |
|------|------|------|------|
| id | String | ✓ | 사용자 ID |
| password | String | ✓ | 비밀번호 |
| groupId | String |  | 사용자 그룹 ID |
| name | String |  | 사용자 전체 이름 |
| email | String |  | 이메일 주소 |
| company | String |  | 회사명 |
| dept | String |  | 부서 |
| jobTitle | String |  | 직책 |
| cellphone | String |  | 전화번호 |

#### 사용 예시

```java
// PAGE 타입 - 기본 인증
@Override
public UserData preHandle(String id, String password) {
    if (authenticateLDAP(id, password)) {
        return new UserData(id, password, "Developers");
    }
    return null;  // 인증 실패
}

// SSO 타입 - 전체 정보 포함
@Override
public UserData preHandle(HttpServletRequest request) {
    String userId = extractFromSSOToken(request);
    if (userId != null) {
        return new UserData(
            userId,
            "auto-generated-password",
            "SSO-Users",
            "John Doe",
            "john@example.com",
            "ACME Corp",
            "Engineering",
            "Senior Developer",
            "010-1234-5678"
        );
    }
    return null;  // 인증 실패
}
```

### PropertyUtil 유틸리티

```java
// 옵션 값 가져오기 (기본값 포함)
String value = PropertyUtil.getValue(adapterId, "option_key", "default_value");

// Boolean 옵션
boolean enabled = Boolean.parseBoolean(PropertyUtil.getValue(adapterId, "enabled", "true"));

// Integer 옵션
int timeout = Integer.parseInt(PropertyUtil.getValue(adapterId, "timeout", "5000"));

// Long 옵션
long maxSize = Long.parseLong(PropertyUtil.getValue(adapterId, "max_size", "10000000"));
```

---

## 트러블슈팅

### 일반적인 문제

#### 1. 어댑터가 로드되지 않음

**증상**:
```
JENNIFER 서버 로그에 어댑터 로드 에러
```

**원인 및 해결**:
- JAR 파일이 `$JENNIFER_HOME/adapter/` 디렉토리에 없음
- 클래스 경로 오류 → 패키지명과 클래스명 확인
- JENNIFER 서버 재시작 필요

#### 2. ClassNotFoundException

**증상**:
```
java.lang.ClassNotFoundException: com.aries.slack.SlackAdapter
```

**원인 및 해결**:
- 패키지명과 클래스명이 일치하지 않음
- JAR 파일 내부 구조 확인: `jar tf jennifer-view-adapter-slack-1.0.0.jar`

#### 3. NoClassDefFoundError

**증상**:
```
java.lang.NoClassDefFoundError: org/apache/http/client/HttpClient
```

**원인 및 해결**:
- 외부 라이브러리가 JAR에 포함되지 않음
- maven-shade-plugin 설정 확인
- 해당 라이브러리를 shade plugin으로 포함

#### 4. 이벤트가 전송되지 않음

**증상**:
- 이벤트 발생했으나 외부 서비스로 알림 없음

**원인 및 해결**:
- JENNIFER 로그 확인: `$JENNIFER_HOME/logs/jennifer.log`
- webhook_url 등 필수 옵션 설정 확인
- 방화벽에서 외부 서비스 접근 허용 확인
- HTTP 응답 코드 로깅 추가하여 디버깅

#### 5. LDAP 연결 실패

**증상**:
```
javax.naming.CommunicationException
```

**원인 및 해결**:
- LDAP 서버 주소 확인
- 방화벽에서 LDAP 포트 (389, 636) 허용 확인
- LDAP admin 계정 및 비밀번호 확인

#### 6. SSL 인증서 오류

**증상**:
```
javax.net.ssl.SSLHandshakeException
```

**원인 및 해결**:
- Java Keystore에 SSL 인증서 추가:
  ```bash
  keytool -import -alias ldap-cert -file ldap.crt -keystore $JAVA_HOME/lib/security/cacerts
  ```

### 디버깅 팁

#### 1. 로그 레벨 변경

`$JENNIFER_HOME/conf/logback.xml`:
```xml
<logger name="com.aries.slack" level="DEBUG"/>
```

#### 2. JAR 파일 내용 확인

```bash
jar tf target/jennifer-view-adapter-slack-1.0.0.jar
```

#### 3. 의존성 트리 확인

```bash
mvn dependency:tree
```

#### 4. HTTP 요청 디버깅

```java
LogUtil.debug("Sending POST to: " + webhookUrl);
LogUtil.debug("Payload: " + jsonPayload);
LogUtil.debug("Response code: " + responseCode);
```

### LogUtil 관련 문제

#### LogUtil.error()가 로그에 출력되지 않음

**증상**:
```
어댑터에서 LogUtil.error() 호출했으나 로그 파일에 기록되지 않음
```

**원인 및 해결**:
1. 로그 레벨이 너무 높게 설정됨
   ```xml
   <!-- $JENNIFER_HOME/conf/logback.xml -->
   <logger name="com.aries.slack" level="ERROR"/>  <!-- ERROR 이상만 출력 -->
   ```

2. **해결**: 로그 레벨을 DEBUG 또는 INFO로 변경
   ```xml
   <logger name="com.aries.slack" level="DEBUG"/>
   ```

3. JENNIFER 서버 재시작
   ```bash
   $JENNIFER_HOME/bin/jennifer restart
   ```

#### LogUtil 클래스를 찾을 수 없음

**증상**:
```
java.lang.NoClassDefFoundError: com/aries/extension/util/LogUtil
```

**원인 및 해결**:
- extension 라이브러리가 올바르게 포함되지 않음
- pom.xml 확인:
  ```xml
  <dependency>
      <groupId>com.aries</groupId>
      <artifactId>extension</artifactId>
      <version>1.5.8</version>
      <type>pom</type>  <!-- type=pom 필수! -->
  </dependency>
  ```

#### 로그 파일 위치

JENNIFER 어댑터 로그 위치:
```bash
# 메인 로그
$JENNIFER_HOME/logs/jennifer.log

# 실시간 모니터링
tail -f $JENNIFER_HOME/logs/jennifer.log | grep -i "your_adapter_name"
```

---

## 성능 고려사항

### Event Adapter 성능 최적화

#### 1. 비동기 처리 (고부하 환경)

대량의 이벤트 발생 시 비동기 처리 권장:

```java
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class AsyncEventAdapter implements EventHandler {
    private static final ExecutorService executor = Executors.newFixedThreadPool(10);

    @Override
    public void on(EventData[] events) {
        // 배치로 받은 이벤트를 비동기로 처리
        for (EventData eventData : events) {
            executor.submit(() -> {
                try {
                    sendNotification(eventData);
                } catch (Exception e) {
                    LogUtil.error("Async notification failed", e);
                }
            });
        }
    }
}
```

**주의사항**:
- 스레드 풀 크기 적절히 조정 (기본 10-20)
- 어댑터 종료 시 executor.shutdown() 필요

#### 2. HTTP 클라이언트 재사용

HttpClient 인스턴스를 재사용하여 연결 풀링:

```java
// ❌ 나쁜 예: 매번 새 클라이언트 생성
public void on(EventData eventData) {
    CloseableHttpClient client = HttpClients.createDefault();
    // ... 사용 ...
    client.close();
}

// ✅ 좋은 예: 클래스 레벨에서 재사용
private static final CloseableHttpClient HTTP_CLIENT = HttpClients.createDefault();

public void on(EventData eventData) {
    // HTTP_CLIENT 재사용
}
```

#### 3. 타임아웃 설정 필수

외부 API 호출 시 반드시 타임아웃 설정:

```java
connection.setConnectTimeout(5000);  // 연결 타임아웃: 5초
connection.setReadTimeout(10000);     // 읽기 타임아웃: 10초
```

**권장 값**:
- 연결 타임아웃: 5초
- 읽기 타임아웃: 10초
- 재시도 횟수: 3회

### Transaction Adapter 성능 최적화

#### 1. 배치 쓰기

여러 트랜잭션을 모아서 한 번에 처리:

```java
private List<ProfileData> buffer = new ArrayList<>();
private static final int BATCH_SIZE = 100;

@Override
public synchronized void on(ProfileData txData) {
    buffer.add(txData);
    
    if (buffer.size() >= BATCH_SIZE) {
        flushBuffer();
    }
}

private void flushBuffer() {
    // 배치로 한 번에 처리
    writeToDatabase(buffer);
    buffer.clear();
}
```

#### 2. 파일 I/O 최적화

BufferedWriter 사용 및 적절한 버퍼 크기:

```java
// 버퍼 크기 8KB (기본값)
try (BufferedWriter bw = new BufferedWriter(new FileWriter(path, true), 8192)) {
    bw.write(message);
    bw.newLine();
}
```

#### 3. TPS별 권장 패턴

| TPS | 권장 패턴 | 설명 |
|-----|----------|------|
| < 1,000 | 동기 + BufferedWriter | 간단하고 안정적 |
| 1,000 - 5,000 | 배치 쓰기 | 버퍼링으로 I/O 최적화 |
| > 5,000 | 비동기 + 큐 | 별도 스레드에서 처리 |

### 메모리 관리

#### 1. String concatenation 최적화

```java
// ❌ 나쁜 예: 많은 String 연결
String msg = "Event: " + name + ", Level: " + level + ", Domain: " + domain;

// ✅ 좋은 예: StringBuilder 사용
StringBuilder sb = new StringBuilder();
sb.append("Event: ").append(name);
sb.append(", Level: ").append(level);
sb.append(", Domain: ").append(domain);
String msg = sb.toString();
```

#### 2. 대용량 데이터 처리

```java
// JSON 파싱 시 스트림 사용
JsonReader reader = new JsonReader(new InputStreamReader(inputStream));
// ... 처리 ...
reader.close();
```

---

## 어댑터 테스트 가이드

### 로컬 테스트 (JENNIFER 서버 불필요)

#### 1. 단위 테스트 작성

```java
public class SlackAdapterTest {
    
    public static void main(String[] args) {
        // 1. 어댑터 인스턴스 생성
        SlackAdapter adapter = new SlackAdapter();
        adapter.setAdapterId("test-adapter");
        
        // 2. Mock EventData 생성
        EventData mockEvent = createMockEvent();
        
        // 3. 어댑터 실행
        adapter.on(mockEvent);
        
        System.out.println("Test completed - Check Slack channel");
    }
    
    private static EventData createMockEvent() {
        // EventData는 인터페이스이므로 Mock 객체 필요
        return new EventData() {
            public String getDomainName() { return "TestDomain"; }
            public String getInstanceName() { return "TestInstance"; }
            public String getEventLevel() { return "CRITICAL"; }
            public String getEventName() { return "Test Event"; }
            public long getTime() { return System.currentTimeMillis(); }
            // ... 나머지 메서드 구현 ...
        };
    }
}
```

#### 2. PropertyUtil Mock

테스트 시 PropertyUtil.getValue() 사용:

```java
// 환경변수 또는 시스템 속성으로 설정
System.setProperty("webhook_url", "https://hooks.slack.com/...");
```

### 통합 테스트 (JENNIFER 서버 사용)

#### 1. 테스트 이벤트 발생

```bash
# JENNIFER View Server에서 테스트 이벤트 수동 발생
# Management > Event > Manual Trigger
```

#### 2. 로그 모니터링

```bash
# 실시간 로그 확인
tail -f $JENNIFER_HOME/logs/jennifer.log | grep -i "SlackAdapter"

# 에러만 필터링
tail -f $JENNIFER_HOME/logs/jennifer.log | grep -i "error"
```

#### 3. 성능 테스트

```bash
# 대량 이벤트 발생 시 어댑터 성능 모니터링
# JMX 또는 VisualVM 사용
jconsole <jennifer_pid>
```

### HTTP 요청 디버깅 도구

#### 1. Webhook.site 사용

1. https://webhook.site 접속
2. 생성된 URL을 `webhook_url`에 설정
3. 전송된 데이터 실시간 확인

#### 2. RequestBin 사용

1. https://requestbin.com 접속
2. Endpoint 생성
3. 요청 내용 상세 확인

#### 3. curl로 직접 테스트

```bash
# Slack webhook 테스트
curl -X POST \
  https://hooks.slack.com/services/... \
  -H 'Content-Type: application/json' \
  -d '{"text":"Test from JENNIFER"}'
```

### 체크리스트

테스트 전 확인사항:

- [ ] pom.xml 의존성 올바른지 확인
- [ ] JAR 파일이 $JENNIFER_HOME/adapter/에 복사됨
- [ ] JENNIFER 서버 재시작됨
- [ ] 어댑터 설정 (webhook_url 등) 올바른지 확인
- [ ] 방화벽/네트워크 설정 확인
- [ ] 로그 레벨 DEBUG로 설정
- [ ] 테스트 이벤트 발생 확인

---

## 베스트 프랙티스

### 성능 고려사항

1. **비동기 처리**: 외부 API 호출은 별도 스레드에서 처리
2. **타임아웃 설정**: HTTP 클라이언트 타임아웃 필수 (5-10초 권장)
3. **에러 핸들링**: 어댑터 에러가 JENNIFER 서버에 영향을 주지 않도록
4. **연결 풀링**: Apache HttpClient 또는 OkHttp 사용 시 공유 인스턴스 활용

### 보안

1. **민감 정보**: API 키, 토큰은 PropertyUtil로 관리
2. **입력 검증**: 외부 입력 데이터 검증
3. **HTTPS 사용**: 가능한 한 HTTPS 통신
4. **패스워드 로깅 금지**: 절대 패스워드를 로그에 기록하지 않기

### 의존성 관리

1. **Java 버전**: JENNIFER 5.5부터 최소 Java 17 필수
   - maven.compiler.source: 17
   - maven.compiler.target: 17
   - IDE 및 빌드 환경도 Java 17 이상 설정

2. **사설 저장소**: JenniferSoft Nexus 저장소 필수 추가

3. **extension 라이브러리**: type을 `pom`으로 지정하여 어댑터 API 사용

4. **provided scope 필수**: JENNIFER 서버에 포함된 라이브러리는 반드시 provided

   - com.google.code.gson (JSON)
   - 기타 서버 기본 라이브러리

5. **shade plugin 설정**: 외부 라이브러리 포함 시 서버 라이브러리 제외 설정

6. **버전 관리**: 서버 버전과 호환되는 라이브러리 버전 사용

### 로깅

1. **적절한 로그 레벨**: DEBUG, INFO, WARN, ERROR
2. **성능 영향 최소화**: 로깅 오버헤드 고려
3. **민감 정보 제외**: 로그에 API 키 등 포함하지 않기

### 코드 품질

1. **Null Safety**: 모든 외부 입력은 null 체크
2. **Thread-safe**: synchronized 또는 concurrent 자료구조 사용
3. **리소스 관리**: try-with-resources 사용
4. **예외 처리**: 구체적인 예외 타입별 처리

---

## 참고 자료

### 공식 문서

- JENNIFER View Server 개발자 가이드
- JENNIFER Adapter Library API 문서

### GitHub 저장소

#### Event Adapters

- [jennifer-view-adapter-tutorial](https://github.com/jennifersoft/jennifer-view-adapter-tutorial) - 기본 튜토리얼
- [jennifer-view-adapter-slack](https://github.com/jennifersoft/jennifer-view-adapter-slack) - Slack 연동
- [jennifer-view-adapter-teams](https://github.com/jennifersoft/jennifer-view-adapter-teams) - Microsoft Teams 연동
- [jennifer-view-adapter-telegram](https://github.com/jennifersoft/jennifer-view-adapter-telegram) - Telegram 연동
- [jennifer-view-adapter-line](https://github.com/jennifersoft/jennifer-view-adapter-line) - LINE 연동
- [jennifer-view-adapter-eventlog](https://github.com/jennifersoft/jennifer-view-adapter-eventlog) - 파일 로깅
- [jennifer-view-adapter-snmp](https://github.com/jennifersoft/jennifer-view-adapter-snmp) - SNMP Trap

#### Transaction Adapters

- [jennifer-view-adapter-xviewlog](https://github.com/jennifersoft/jennifer-view-adapter-xviewlog) - X-View 트랜잭션 로깅

#### Login Adapters

- [jennifer-view-login-ldap](https://github.com/jennifersoft/jennifer-view-login-ldap) - LDAP 인증
- [jennifer-view-kb-sso](https://github.com/jennifersoft/jennifer-view-kb-sso) - SSO 인증

### 외부 API 문서

- [Slack Incoming Webhooks](https://api.slack.com/messaging/webhooks)
- [Microsoft Teams Incoming Webhooks](https://docs.microsoft.com/en-us/microsoftteams/platform/webhooks-and-connectors/how-to/add-incoming-webhook)
- [Telegram Bot API](https://core.telegram.org/bots/api)
- [Discord Webhooks](https://discord.com/developers/docs/resources/webhook)
- [LINE Messaging API](https://developers.line.biz/en/docs/messaging-api/)

---

## 자주 묻는 질문 (FAQ)

### Q1. Java 8을 사용할 수 있나요?

JENNIFER 5.5 이상에서는 Java 17이 필수입니다. JENNIFER 5.4 이하 버전에서는 Java 8 사용 가능합니다.

### Q2. 여러 외부 서비스로 동시에 알림을 보낼 수 있나요?

네, 각 서비스마다 별도의 어댑터를 만들고, 이벤트 정책에서 여러 어댑터를 동시에 체크하면 됩니다.

### Q3. 어댑터에서 데이터베이스에 직접 연결할 수 있나요?

가능합니다. JDBC 드라이버를 pom.xml에 추가하고, shade plugin으로 JAR에 포함시키면 됩니다.

### Q4. 비동기로 처리해야 하나요?

대부분의 경우 동기 처리로 충분합니다. 다만, 대량의 이벤트 발생 또는 외부 API 응답이 느린 경우 비동기 처리를 고려하세요.

### Q5. 어댑터 업데이트 시 JENNIFER 서버 재시작이 필요한가요?

네, JAR 파일을 교체한 후 JENNIFER 서버를 재시작해야 새 버전이 로드됩니다.

### Q6. Event Adapter에서 트랜잭션 데이터를 받을 수 있나요?

Event Adapter는 이벤트 데이터만 받습니다. 트랜잭션 데이터가 필요하면 Transaction Adapter (ProfileDataHandler)를 구현하세요.

### Q7. 로그인 실패 시 재시도가 가능한가요?

Login Adapter는 한 번의 인증 시도만 처리합니다. 재시도는 JENNIFER 로그인 페이지에서 사용자가 수동으로 진행합니다.

### Q8. JENNIFER 버전별 호환성은 어떻게 되나요?

- Extension Library 1.5.8은 JENNIFER 5.5 이상에서 사용
- 하위 버전은 해당 버전의 Extension Library 사용 필요
- 자세한 내용은 JenniferSoft 기술 지원팀에 문의하세요.

---

## 버전 정보

- **작성일**: 2025-11-10
- **업데이트**: 2026-06-15
- **기반 JENNIFER 버전**: 5.6.5
- **최소 Java 버전**: 17 (JENNIFER 5.5부터 필수)
- **Extension 라이브러리**: 1.5.8
- **참조 어댑터 수**: 10개 (Event: 7개, Transaction: 1개, Login: 2개)
- **지원 어댑터 유형**: Event, Transaction, Login (PAGE/SSO), System Event (총 4가지)
- **Kotlin 지원**: 1.9.22

---

## 맺음말

이 가이드는 JENNIFER5 Adapter 개발을 위한 종합 문서입니다. 템플릿과 패턴을 활용하여 빠르고 안정적인 어댑터를 개발하세요.

추가 질문이나 기술 지원이 필요한 경우 JenniferSoft 기술 지원팀에 문의하시기 바랍니다.

- **웹사이트**: https://www.jennifersoft.com
- **기술 지원**: support@jennifersoft.com
- **GitHub**: https://github.com/jennifersoft

