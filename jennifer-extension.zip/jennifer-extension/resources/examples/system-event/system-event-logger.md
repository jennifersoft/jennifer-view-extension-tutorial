# System Event Logger Adapter 예제

JENNIFER 데이터 서버의 시스템 레벨 이벤트를 파일로 로깅하는 어댑터입니다.

## 개요

System Event Adapter는 JENNIFER 데이터 서버에서 발생하는 시스템 레벨 이벤트를 처리합니다. 일반 Event Adapter와 달리 더 간단한 데이터 구조(subject, message, dataServer)를 가지며, 주로 시스템 관리 및 모니터링 목적으로 사용됩니다.

## 사용 사례

- 데이터 서버 시작/중지 이벤트 로깅
- 시스템 오류 및 경고 모니터링
- 데이터 서버 상태 변경 추적
- 인프라 이벤트 통합 로깅

## 프로젝트 구조

```
jennifer-system-event-logger/
├── pom.xml
└── src/main/java/com/aries/systemlog/
    └── SystemEventLoggerAdapter.java
```

## pom.xml

```xml
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0
         http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <groupId>com.aries</groupId>
    <artifactId>jennifer-system-event-logger</artifactId>
    <version>1.0.0</version>
    <packaging>jar</packaging>

    <name>JENNIFER System Event Logger</name>
    <description>System event logging adapter for JENNIFER data server events</description>

    <properties>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
        <maven.compiler.source>17</maven.compiler.source>
        <maven.compiler.target>17</maven.compiler.target>
    </properties>

    <repositories>
        <repository>
            <id>central</id>
            <url>https://maven.jennifersoft.com/nexus/content/groups/public</url>
        </repository>
    </repositories>

    <dependencies>
        <!-- JENNIFER Extension Library -->
        <dependency>
            <groupId>com.aries</groupId>
            <artifactId>extension</artifactId>
            <version>1.5.8</version>
            <type>pom</type>
        </dependency>
    </dependencies>

    <build>
        <plugins>
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-compiler-plugin</artifactId>
                <version>3.8.1</version>
                <configuration>
                    <source>17</source>
                    <target>17</target>
                </configuration>
            </plugin>

            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-shade-plugin</artifactId>
                <version>3.2.4</version>
                <executions>
                    <execution>
                        <phase>package</phase>
                        <goals>
                            <goal>shade</goal>
                        </goals>
                        <configuration>
                            <artifactSet>
                                <excludes>
                                    <exclude>com.aries:*</exclude>
                                </excludes>
                            </artifactSet>
                        </configuration>
                    </execution>
                </executions>
            </plugin>
        </plugins>
    </build>
</project>
```

## SystemEventLoggerAdapter.java

```java
package com.aries.systemlog;

import com.aries.extension.data.SystemEventData;
import com.aries.extension.handler.SystemEventHandler;
import com.aries.extension.util.PropertyUtil;
import com.aries.extension.util.LogUtil;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * JENNIFER System Event Logger Adapter
 *
 * Logs JENNIFER data server system events to file.
 *
 * Required Options:
 * - log_path: Log file path (supports date pattern)
 *
 * Optional Options:
 * - date_format: Date format for log entries (default: yyyy-MM-dd HH:mm:ss)
 * - log_pattern: Log message pattern (default: provided pattern)
 *
 * @author JenniferSoft
 * @version 1.0.0
 */
public class SystemEventLoggerAdapter implements SystemEventHandler {

    private static final String DEFAULT_LOG_PATTERN =
        "[%timestamp] DataServer=%dataServer, Subject=%subject, Message=%message";

    private String adapterId;

    @Override
    public void setAdapterId(String adapterId) {
        this.adapterId = adapterId;
        LogUtil.info("SystemEventLoggerAdapter initialized with ID: " + adapterId);
    }

    @Override
    public void on(SystemEventData[] events) {
        for (SystemEventData event : events) {
            try {
                // 1. Get configuration
                String logPath = PropertyUtil.getValue(adapterId, "log_path", "../logs/system-events.%d{yyyy-MM-dd}.log");
                String dateFormat = PropertyUtil.getValue(adapterId, "date_format", "yyyy-MM-dd HH:mm:ss");
                String logPattern = PropertyUtil.getValue(adapterId, "log_pattern", DEFAULT_LOG_PATTERN);

                // 2. Resolve date pattern in path
                String actualPath = resolveDatePattern(logPath);

                // 3. Build log message
                String logMessage = buildLogMessage(event, logPattern, dateFormat);

                // 4. Write to file
                writeLog(actualPath, logMessage);

            } catch (Exception e) {
                LogUtil.error("Failed to log system event", e);
            }
        }
    }

    /**
     * Build log message from system event data
     */
    private String buildLogMessage(SystemEventData event, String pattern, String dateFormat) {
        SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
        String timestamp = sdf.format(new Date());

        return pattern
            .replace("%timestamp", timestamp)
            .replace("%dataServer", nvl(event.getDataServer()))
            .replace("%subject", nvl(event.getSubject()))
            .replace("%message", nvl(event.getMessage()));
    }

    /**
     * Resolve date pattern in file path
     * Example: ../logs/system-events.%d{yyyy-MM-dd}.log → ../logs/system-events.2025-11-11.log
     */
    private String resolveDatePattern(String path) {
        if (!path.contains("%d{")) {
            return path;
        }

        try {
            int start = path.indexOf("%d{");
            int end = path.indexOf("}", start);

            if (start == -1 || end == -1) {
                return path;
            }

            String datePattern = path.substring(start + 3, end);
            SimpleDateFormat sdf = new SimpleDateFormat(datePattern);
            String dateStr = sdf.format(new Date());

            return path.substring(0, start) + dateStr + path.substring(end + 1);

        } catch (Exception e) {
            LogUtil.warn("Failed to resolve date pattern in path: " + path, e);
            return path;
        }
    }

    /**
     * Write log message to file (thread-safe)
     */
    private synchronized void writeLog(String logPath, String message) throws IOException {
        // Ensure parent directory exists
        File logFile = new File(logPath);
        File parentDir = logFile.getParentFile();
        if (parentDir != null && !parentDir.exists()) {
            parentDir.mkdirs();
        }

        // Append to file
        try (FileWriter fw = new FileWriter(logPath, true);
             BufferedWriter bw = new BufferedWriter(fw)) {
            bw.write(message);
            bw.newLine();
        }
    }

    /**
     * Null-safe string conversion
     */
    private String nvl(String value) {
        return value != null ? value : "";
    }
}
```

## adapter_view.conf 설정

```properties
# System Event Logger Adapter Configuration
SYSTEM_EVENT_LOGGER_ID=system-event-logger
SYSTEM_EVENT_LOGGER_CLASS=com.aries.systemlog.SystemEventLoggerAdapter
SYSTEM_EVENT_LOGGER_JAR=system-event-logger.jar

# Log file path (supports date pattern)
SYSTEM_EVENT_LOGGER_log_path=../logs/jennifer-system-events.%d{yyyy-MM-dd}.log

# Date format for timestamps in log entries
SYSTEM_EVENT_LOGGER_date_format=yyyy-MM-dd HH:mm:ss

# Log message pattern
SYSTEM_EVENT_LOGGER_log_pattern=[%timestamp] DataServer=%dataServer, Subject=%subject, Message=%message
```

## 빌드 및 배포

### 1. 빌드

```bash
cd jennifer-system-event-logger
mvn clean package
```

### 2. 배포

```bash
# JAR 파일을 JENNIFER Server의 adapter 디렉토리로 복사
cp target/jennifer-system-event-logger-1.0.0.jar $JENNIFER_HOME/adapter/

# 또는 이름 변경하여 복사
cp target/jennifer-system-event-logger-1.0.0.jar $JENNIFER_HOME/adapter/system-event-logger.jar
```

### 3. 설정

`$JENNIFER_HOME/conf/adapter_view.conf`에 설정 추가:

```properties
SYSTEM_EVENT_LOGGER_ID=system-event-logger
SYSTEM_EVENT_LOGGER_CLASS=com.aries.systemlog.SystemEventLoggerAdapter
SYSTEM_EVENT_LOGGER_JAR=system-event-logger.jar
SYSTEM_EVENT_LOGGER_log_path=../logs/jennifer-system-events.%d{yyyy-MM-dd}.log
```

### 4. JENNIFER 서버 재시작

```bash
$JENNIFER_HOME/bin/shutdown.sh
$JENNIFER_HOME/bin/startup.sh
```

## 로그 예시

```
[2025-11-11 10:30:15] DataServer=jennifer-data-01, Subject=Server Started, Message=JENNIFER data server has been started successfully
[2025-11-11 10:35:22] DataServer=jennifer-data-01, Subject=Configuration Reloaded, Message=Server configuration has been reloaded
[2025-11-11 11:00:00] DataServer=jennifer-data-01, Subject=Health Check, Message=All systems operational
[2025-11-11 14:23:45] DataServer=jennifer-data-01, Subject=Warning, Message=High memory usage detected: 85%
[2025-11-11 18:00:00] DataServer=jennifer-data-01, Subject=Server Shutdown, Message=JENNIFER data server is shutting down
```

## 커스터마이징

### 1. 로그 포맷 변경

```properties
# JSON 형식
SYSTEM_EVENT_LOGGER_log_pattern={"timestamp":"%timestamp","dataServer":"%dataServer","subject":"%subject","message":"%message"}

# 심플 포맷
SYSTEM_EVENT_LOGGER_log_pattern=%timestamp | %dataServer | %subject | %message

# 상세 포맷
SYSTEM_EVENT_LOGGER_log_pattern=[%timestamp] [%dataServer] [%subject] %message
```

### 2. 날짜 패턴 변경

```properties
# 시간별 롤링
SYSTEM_EVENT_LOGGER_log_path=../logs/system-events.%d{yyyy-MM-dd_HH}.log

# 월별 롤링
SYSTEM_EVENT_LOGGER_log_path=../logs/system-events.%d{yyyy-MM}.log

# 주별 롤링
SYSTEM_EVENT_LOGGER_log_path=../logs/system-events.%d{yyyy-ww}.log
```

### 3. 필터링 추가

코드에서 특정 이벤트만 로깅:

```java
@Override
public void on(SystemEventData[] events) {
    for (SystemEventData event : events) {
        try {
            // 특정 subject만 로깅
            String subject = event.getSubject();
            if (subject == null || (!subject.contains("Error") && !subject.contains("Warning"))) {
                continue;  // Error/Warning이 아니면 건너뛰기
            }

            // ... 로깅 로직
        } catch (Exception e) {
            LogUtil.error("Failed to log system event", e);
        }
    }
}
```

## 트러블슈팅

### 로그 파일이 생성되지 않는 경우

1. 디렉토리 권한 확인:
```bash
ls -ld $JENNIFER_HOME/logs
```

2. 설정 확인:
```bash
grep SYSTEM_EVENT_LOGGER $JENNIFER_HOME/conf/adapter_view.conf
```

3. JENNIFER 로그 확인:
```bash
tail -f $JENNIFER_HOME/logs/jennifer.log | grep SystemEventLogger
```

### 로그가 기록되지 않는 경우

어댑터가 정상 로드되었는지 확인:
```bash
# JENNIFER 서버 시작 로그 확인
grep "SystemEventLoggerAdapter initialized" $JENNIFER_HOME/logs/jennifer.log
```

### 디스크 공간 부족

자동 로그 삭제 스크립트:
```bash
#!/bin/bash
# 30일 이상 된 로그 파일 삭제
find $JENNIFER_HOME/logs -name "jennifer-system-events.*.log" -mtime +30 -delete
```

## 베스트 프랙티스

1. **날짜 기반 롤링**: 로그 관리를 위해 일별 또는 시간별 롤링 사용
2. **디스크 모니터링**: 로그 파일이 디스크를 가득 채우지 않도록 주기적 삭제
3. **에러 핸들링**: 파일 쓰기 실패 시에도 JENNIFER 서버는 정상 동작해야 함
4. **성능**: BufferedWriter 사용으로 I/O 성능 최적화
5. **Thread Safety**: synchronized 메서드로 동시 쓰기 방지

## System Event와 Event의 차이점

| 항목 | System Event | Event |
|------|--------------|-------|
| **목적** | 데이터 서버 시스템 이벤트 | 애플리케이션 이벤트 |
| **데이터 구조** | 간단 (3개 필드) | 복잡 (20+ 필드) |
| **발생 빈도** | 낮음 | 높음 |
| **처리 우선순위** | 높음 (시스템 중요) | 중간 |
| **사용 사례** | 인프라 관리, 시스템 모니터링 | 알림, 이벤트 전파 |

## 참고 자료

- [JENNIFER5 Adapter Development Guide](../../../jennifer5-adapter.md)
- [System Event Handler API](../../../jennifer5-adapter.md#system-event-adapter)
- [Error Handling Patterns](../../../patterns/error-handling.md)
- [File Logging Patterns](../../../patterns/file-logging.md)
