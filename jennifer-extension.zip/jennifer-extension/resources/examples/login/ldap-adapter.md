# LDAP Login Adapter 완전 구현 예제

Active Directory 또는 OpenLDAP를 사용하여 JENNIFER 로그인 인증을 수행하는 어댑터입니다.

## 프로젝트 구조

```
jennifer-view-login-ldap/
├── pom.xml
└── src/main/java/com/aries/login/ldap/
    └── LdapLoginAdapter.java
```

## pom.xml

```xml
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0
                             http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <groupId>com.aries</groupId>
    <artifactId>jennifer-view-login-ldap</artifactId>
    <version>1.0.0</version>
    <packaging>jar</packaging>

    <name>JENNIFER LDAP Login Adapter</name>
    <description>LDAP/AD Login Adapter for JENNIFER</description>

    <properties>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
        <maven.compiler.source>17</maven.compiler.source>
        <maven.compiler.target>17</maven.compiler.target>
    </properties>

    <repositories>
        <repository>
            <id>central</id>
            <url>https://maven.jennifersoft.com/nexus/content/groups/public</url>
        </repository>
    </repositories>

    <dependencies>
        <!-- JENNIFER View Adapter Library -->
        <dependency>
            <groupId>com.aries</groupId>
            <artifactId>extension</artifactId>
            <version>1.5.8</version>
            <type>pom</type>
        </dependency>
    </dependencies>

    <build>
        <plugins>
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-compiler-plugin</artifactId>
                <version>3.8.1</version>
                <configuration>
                    <source>17</source>
                    <target>17</target>
                </configuration>
            </plugin>
        </plugins>
    </build>
</project>
```

## LdapLoginAdapter.java

```java
package com.aries.login.ldap;

import com.aries.extension.handler.PageLoginAdapter;
import com.aries.extension.data.LoginResult;
import com.aries.extension.util.PropertyUtil;
import com.aries.extension.util.LogUtil;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.*;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

/**
 * LDAP/Active Directory Login Adapter for JENNIFER
 *
 * Authenticates users against LDAP server and retrieves group memberships.
 *
 * Required Options:
 * - serverUrl: LDAP server URL (e.g., ldap://ldap.example.com:389)
 * - baseRdn: Base RDN (e.g., dc=example,dc=com)
 * - adminId: LDAP admin DN (e.g., cn=admin)
 * - adminPwd: LDAP admin password
 *
 * Optional Options:
 * - baseOu: Base OU for user search (default: Users)
 * - groupPrefix: Group name prefix filter (e.g., JENNIFER*,APP*)
 * - fixedGroup: Fixed group assignment (overrides LDAP groups)
 * - useSsl: Use SSL/TLS (default: false)
 * - userDnPattern: User DN pattern (e.g., uid={0},ou=Users)
 *
 * @author JenniferSoft
 * @version 1.0.0
 */
public class LdapLoginAdapter implements LoginHandler {

    private String adapterId;

    @Override
    public void setAdapterId(String adapterId) {
        this.adapterId = adapterId;
    }

    @Override
    public LoginResult authenticate(String userId, String password) {
        LdapContext ctx = null;
        
        try {
            // 1. Get LDAP configuration
            String serverUrl = PropertyUtil.getValue(adapterId, "serverUrl", "");
            String baseRdn = PropertyUtil.getValue(adapterId, "baseRdn", "");
            String adminId = PropertyUtil.getValue(adapterId, "adminId", "");
            String adminPwd = PropertyUtil.getValue(adapterId, "adminPwd", "");
            String baseOu = PropertyUtil.getValue(adapterId, "baseOu", "Users");
            String groupPrefix = PropertyUtil.getValue(adapterId, "groupPrefix", "");
            String fixedGroup = PropertyUtil.getValue(adapterId, "fixedGroup", "");
            boolean useSsl = Boolean.parseBoolean(PropertyUtil.getValue(adapterId, "useSsl", "false"));
            String userDnPattern = PropertyUtil.getValue(adapterId, "userDnPattern", "");

            // Validate configuration
            if (serverUrl.isEmpty() || baseRdn.isEmpty()) {
                LogUtil.error("LDAP serverUrl or baseRdn not configured");
                return LoginResult.failure("LDAP configuration error");
            }

            LogUtil.debug("Attempting LDAP authentication for user: " + userId);

            // 2. Connect to LDAP as admin
            ctx = connectLdap(serverUrl, baseRdn, adminId, adminPwd, useSsl);

            // 3. Authenticate user
            boolean authenticated;
            if (!userDnPattern.isEmpty()) {
                // Direct bind with DN pattern
                authenticated = authenticateWithDnPattern(userId, password, userDnPattern, baseRdn, serverUrl, useSsl);
            } else {
                // Search and bind
                authenticated = authenticateUser(ctx, userId, password, baseOu, baseRdn, serverUrl, useSsl);
            }

            if (!authenticated) {
                LogUtil.warn("LDAP authentication failed for user: " + userId);
                return LoginResult.failure("Invalid credentials");
            }

            // 4. Get user groups
            List<String> groups;
            if (!fixedGroup.isEmpty()) {
                // Use fixed group
                groups = new ArrayList<>();
                for (String group : fixedGroup.split(",")) {
                    groups.add(group.trim());
                }
                LogUtil.info("Using fixed groups for user " + userId + ": " + groups);
            } else {
                // Retrieve from LDAP
                groups = getUserGroups(ctx, userId, baseOu, baseRdn, groupPrefix);
                LogUtil.info("Retrieved " + groups.size() + " groups for user: " + userId);
            }

            // 5. Return success
            LogUtil.info("LDAP login successful for user: " + userId);
            return LoginResult.success(userId, groups);

        } catch (NamingException e) {
            LogUtil.error("LDAP naming exception for user: " + userId, e);
            return LoginResult.failure("LDAP error: " + e.getMessage());
        } catch (Exception e) {
            LogUtil.error("LDAP authentication failed for user: " + userId, e);
            return LoginResult.failure("Authentication error: " + e.getMessage());
        } finally {
            // Close LDAP connection
            if (ctx != null) {
                try {
                    ctx.close();
                } catch (NamingException e) {
                    LogUtil.warn("Failed to close LDAP connection", e);
                }
            }
        }
    }

    /**
     * Connect to LDAP server as admin
     */
    private LdapContext connectLdap(String serverUrl, String baseRdn,
                                     String adminId, String adminPwd,
                                     boolean useSsl) throws NamingException {
        Hashtable<String, String> env = new Hashtable<>();
        env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
        env.put(Context.PROVIDER_URL, serverUrl);
        env.put(Context.SECURITY_AUTHENTICATION, "simple");
        
        // Admin credentials
        String adminDn = adminId.contains("=") ? adminId : adminId + "," + baseRdn;
        env.put(Context.SECURITY_PRINCIPAL, adminDn);
        env.put(Context.SECURITY_CREDENTIALS, adminPwd);

        // SSL configuration
        if (useSsl) {
            env.put(Context.SECURITY_PROTOCOL, "ssl");
        }

        // Connection timeout (10 seconds)
        env.put("com.sun.jndi.ldap.connect.timeout", "10000");
        env.put("com.sun.jndi.ldap.read.timeout", "10000");

        return new InitialLdapContext(env, null);
    }

    /**
     * Authenticate user with DN pattern (faster)
     */
    private boolean authenticateWithDnPattern(String userId, String password,
                                               String dnPattern, String baseRdn,
                                               String serverUrl, boolean useSsl) {
        try {
            // Build user DN from pattern
            String userDn = dnPattern.replace("{0}", userId);
            if (!userDn.contains(baseRdn)) {
                userDn = userDn + "," + baseRdn;
            }

            // Try to bind with user credentials
            Hashtable<String, String> env = new Hashtable<>();
            env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
            env.put(Context.PROVIDER_URL, serverUrl);
            env.put(Context.SECURITY_AUTHENTICATION, "simple");
            env.put(Context.SECURITY_PRINCIPAL, userDn);
            env.put(Context.SECURITY_CREDENTIALS, password);

            if (useSsl) {
                env.put(Context.SECURITY_PROTOCOL, "ssl");
            }

            DirContext userCtx = new InitialDirContext(env);
            userCtx.close();
            
            LogUtil.debug("User authenticated with DN: " + userDn);
            return true;

        } catch (NamingException e) {
            LogUtil.debug("DN pattern authentication failed: " + e.getMessage());
            return false;
        }
    }

    /**
     * Authenticate user credentials (search and bind)
     */
    private boolean authenticateUser(LdapContext ctx, String userId, String password,
                                      String baseOu, String baseRdn,
                                      String serverUrl, boolean useSsl) {
        try {
            // Search for user
            String searchBase = "ou=" + baseOu + "," + baseRdn;
            String searchFilter = "(|(uid=" + userId + ")(sAMAccountName=" + userId + ")(cn=" + userId + "))";

            SearchControls searchControls = new SearchControls();
            searchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
            searchControls.setReturningAttributes(new String[]{"dn"});

            NamingEnumeration<SearchResult> results = ctx.search(searchBase, searchFilter, searchControls);

            if (!results.hasMore()) {
                LogUtil.warn("User not found in LDAP: " + userId);
                return false;
            }

            SearchResult searchResult = results.next();
            String userDn = searchResult.getNameInNamespace();
            
            LogUtil.debug("Found user DN: " + userDn);

            // Try to bind with user credentials
            Hashtable<String, String> userEnv = new Hashtable<>();
            userEnv.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
            userEnv.put(Context.PROVIDER_URL, serverUrl);
            userEnv.put(Context.SECURITY_AUTHENTICATION, "simple");
            userEnv.put(Context.SECURITY_PRINCIPAL, userDn);
            userEnv.put(Context.SECURITY_CREDENTIALS, password);

            if (useSsl) {
                userEnv.put(Context.SECURITY_PROTOCOL, "ssl");
            }

            DirContext userCtx = new InitialDirContext(userEnv);
            userCtx.close();

            return true;

        } catch (NamingException e) {
            LogUtil.debug("Authentication failed: " + e.getMessage());
            return false;
        }
    }

    /**
     * Retrieve user's group memberships
     */
    private List<String> getUserGroups(LdapContext ctx, String userId,
                                        String baseOu, String baseRdn,
                                        String groupPrefix) {
        List<String> groups = new ArrayList<>();

        try {
            // Search for user
            String searchBase = "ou=" + baseOu + "," + baseRdn;
            String searchFilter = "(|(uid=" + userId + ")(sAMAccountName=" + userId + ")(cn=" + userId + "))";

            SearchControls searchControls = new SearchControls();
            searchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
            searchControls.setReturningAttributes(new String[]{"memberOf"});

            NamingEnumeration<SearchResult> results = ctx.search(searchBase, searchFilter, searchControls);

            if (results.hasMore()) {
                SearchResult searchResult = results.next();
                Attribute memberOf = searchResult.getAttributes().get("memberOf");

                if (memberOf != null) {
                    NamingEnumeration<?> groupEnum = memberOf.getAll();
                    while (groupEnum.hasMore()) {
                        String groupDn = (String) groupEnum.next();
                        String groupName = extractGroupName(groupDn);

                        // Apply group prefix filter
                        if (matchesGroupPrefix(groupName, groupPrefix)) {
                            groups.add(groupName);
                            LogUtil.debug("Added group: " + groupName);
                        }
                    }
                }
            }

        } catch (Exception e) {
            LogUtil.warn("Failed to retrieve groups for user: " + userId, e);
        }

        return groups;
    }

    /**
     * Extract group name from DN (e.g., cn=Admins,ou=Groups,dc=company,dc=com → Admins)
     */
    private String extractGroupName(String groupDn) {
        if (groupDn == null || groupDn.isEmpty()) {
            return "";
        }
        
        if (groupDn.startsWith("CN=") || groupDn.startsWith("cn=")) {
            int start = 3;
            int end = groupDn.indexOf(",");
            if (end > start) {
                return groupDn.substring(start, end);
            }
        }
        
        return groupDn;
    }

    /**
     * Check if group name matches prefix filter
     * Example: groupPrefix = "JENNIFER*,APP*"
     */
    private boolean matchesGroupPrefix(String groupName, String groupPrefix) {
        if (groupPrefix == null || groupPrefix.isEmpty()) {
            return true;  // No filter
        }

        String[] prefixes = groupPrefix.split(",");
        for (String prefix : prefixes) {
            String pattern = prefix.trim();
            if (pattern.endsWith("*")) {
                pattern = pattern.substring(0, pattern.length() - 1);
                if (groupName.startsWith(pattern)) {
                    return true;
                }
            } else if (groupName.equals(pattern)) {
                return true;
            }
        }

        return false;
    }
}
```

## JENNIFER 설정 예시

### Active Directory 연동

```properties
# Active Directory 설정
serverUrl = ldap://ad.company.com:389
baseRdn = dc=company,dc=com
adminId = cn=admin
adminPwd = admin_password

# 사용자 검색 OU
baseOu = Users

# 그룹 필터 (JENNIFER로 시작하는 그룹만)
groupPrefix = JENNIFER*

# SSL 사용 (권장)
useSsl = false

# DN 패턴 (선택 - 성능 향상)
userDnPattern = cn={0},ou=Users
```

### OpenLDAP 연동

```properties
# OpenLDAP 설정
serverUrl = ldap://ldap.company.com:389
baseRdn = dc=company,dc=com
adminId = cn=admin,dc=company,dc=com
adminPwd = admin_password

# 사용자 검색 설정
baseOu = people

# 고정 그룹 사용 (모든 사용자 동일)
fixedGroup = Users,Developers

# SSL 사용
useSsl = false
```

## 빌드 및 배포

```bash
# 빌드
mvn clean package

# JAR 파일 복사
cp target/jennifer-view-login-ldap-1.0.0.jar $JENNIFER_HOME/adapter/

# JENNIFER 서버 재시작
$JENNIFER_HOME/bin/jennifer restart
```

## 트러블슈팅

### 1. LDAP 연결 실패

```
javax.naming.CommunicationException: ldap.company.com:389
```

**해결책**:
- LDAP 서버 주소/포트 확인
- 방화벽에서 LDAP 포트 (389, 636) 허용
- `telnet ldap.company.com 389`로 연결 테스트

### 2. 인증 실패

```
LoginResult.failure("Invalid credentials")
```

**해결책**:
- Admin 계정 DN 확인 (예: `cn=admin,dc=company,dc=com`)
- Admin 비밀번호 확인
- `userDnPattern` 확인 (Active Directory: `cn={0}`, OpenLDAP: `uid={0}`)

### 3. 그룹이 조회되지 않음

**해결책**:
- `memberOf` 속성 지원 확인
- `baseOu` 설정 확인
- `groupPrefix` 필터 확인
- LDAP 브라우저 도구로 그룹 구조 확인

### 4. SSL 인증서 오류

```
javax.net.ssl.SSLHandshakeException
```

**해결책**:
```bash
# 인증서를 Java keystore에 추가
keytool -import -alias ldap-cert \
  -file ldap.crt \
  -keystore $JAVA_HOME/lib/security/cacerts \
  -storepass changeit
```

## 테스트 방법

### LDAP 연결 테스트

```bash
# ldapsearch로 연결 테스트
ldapsearch -x -H ldap://ldap.company.com:389 \
  -D "cn=admin,dc=company,dc=com" \
  -w admin_password \
  -b "dc=company,dc=com" \
  "(uid=testuser)"
```

### 로그 확인

```bash
# JENNIFER 로그 실시간 모니터링
tail -f $JENNIFER_HOME/logs/jennifer.log | grep -i ldap
```

## 보안 권장사항

1. **SSL/TLS 사용**: 운영 환경에서는 반드시 SSL 사용
2. **Admin 계정 권한 최소화**: Read-only 권한만 부여
3. **비밀번호 암호화**: JENNIFER 설정에서 비밀번호 암호화 사용
4. **연결 타임아웃 설정**: 기본 10초 설정

## 참고 자료

- [LDAP Java Tutorial](https://docs.oracle.com/javase/tutorial/jndi/ldap/index.html)
- [Active Directory LDAP](https://docs.microsoft.com/en-us/windows/win32/adsi/active-directory-ldap)
- [OpenLDAP Admin Guide](https://www.openldap.org/doc/admin24/)
