# Telegram Adapter 완전 구현 예제

Telegram Bot API를 사용하여 JENNIFER 이벤트를 Telegram 채팅으로 전송하는 어댑터입니다.

## 주요 특징

- Markdown 포맷 지원
- Inline 버튼 (X-View 링크)
- 간단한 설정 (Bot Token, Chat ID)

## SlackAdapter와의 주요 차이점

1. **API 엔드포인트**: Webhook이 아닌 Bot API 사용
2. **인증**: Bot Token 필요
3. **메시지 포맷**: Markdown 또는 HTML

## TelegramAdapter.java (핵심 부분만)

```java
package com.aries.telegram;

import com.aries.extension.data.EventData;
import com.aries.extension.handler.EventAdapter;
import com.aries.extension.util.PropertyUtil;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.aries.extension.util.LogUtil;


import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * JENNIFER Event Adapter for Telegram
 */
public class TelegramAdapter implements EventHandler {

    private String adapterId;

    @Override
    public void setAdapterId(String adapterId) {
        this.adapterId = adapterId;
    }

    @Override
    public void on(EventData[] events) {
        for (EventData eventData : events) {
            try {
                // 1. Get configuration
                String botToken = PropertyUtil.getValue(adapterId, "bot_token", "");
                String chatId = PropertyUtil.getValue(adapterId, "chat_id", "");

                if (botToken.isEmpty() || chatId.isEmpty()) {
                    LogUtil.error("bot_token or chat_id is not configured");
                    continue;
                }

                // 2. Build message
                String message = buildTelegramMessage(eventData);

                // 3. Send to Telegram
                String apiUrl = String.format("https://api.telegram.org/bot%s/sendMessage", botToken);
                sendToTelegram(apiUrl, message);

            } catch (Exception e) {
                LogUtil.error("Failed to send Telegram notification", e);
            }
        }
    }

    /**
     * Build Telegram message with Markdown format
     */
    private String buildTelegramMessage(EventData eventData) {
        // Build Markdown text
        StringBuilder text = new StringBuilder();
        text.append("🔔 *JENNIFER Event*\\n\\n");
        text.append("*Event:* ").append(escapeTelegramMarkdown(eventData.getEventName())).append("\\n");
        text.append("*Domain:* ").append(escapeTelegramMarkdown(eventData.getDomainName())).append("\\n");
        text.append("*Instance:* ").append(escapeTelegramMarkdown(eventData.getInstanceName())).append("\\n");
        text.append("*Level:* ").append(getLevelEmoji(eventData.getEventLevel()))
                   .append(" ").append(eventData.getEventLevel()).append("\\n");
        text.append("*Time:* ").append(formatTime(eventData.getTime())).append("\\n");

        // Message (if available)
        String eventMessage = eventData.getMessage();
        if (eventMessage != null && !eventMessage.isEmpty()) {
            text.append("\\n").append(escapeTelegramMarkdown(eventMessage));
        }

        // Build JSON payload
        JsonObject root = new JsonObject();
        root.addProperty("chat_id", PropertyUtil.getValue(adapterId, "chat_id", ""));
        root.addProperty("text", text.toString());
        root.addProperty("parse_mode", "Markdown");

        // X-View link button (inline keyboard)
        String xviewUrl = buildXViewUrl(eventData);
        if (xviewUrl != null) {
            JsonObject replyMarkup = new JsonObject();
            JsonArray inlineKeyboard = new JsonArray();
            JsonArray row = new JsonArray();

            JsonObject button = new JsonObject();
            button.addProperty("text", "View X-View");
            button.addProperty("url", xviewUrl);

            row.add(button);
            inlineKeyboard.add(row);
            replyMarkup.add("inline_keyboard", inlineKeyboard);

            root.add("reply_markup", replyMarkup);
        }

        return root.toString();
    }

    /**
     * Get emoji based on event level
     */
    private String getLevelEmoji(String eventLevel) {
        if (eventLevel == null) return "ℹ️";

        switch (eventLevel) {
            case "FATAL":
            case "CRITICAL":
                return "🔴";
            case "WARNING":
                return "🟠";
            case "INFO":
            default:
                return "🟢";
        }
    }

    /**
     * Escape special characters for Telegram Markdown
     */
    private String escapeTelegramMarkdown(String text) {
        if (text == null) return "";
        return text.replace("_", "\\_")
                   .replace("*", "\\*")
                   .replace("[", "\\[")
                   .replace("`", "\\`");
    }

    /**
     * Build X-View URL
     */
    private String buildXViewUrl(EventData eventData) {
        String jenniferUrl = PropertyUtil.getValue(adapterId, "jennifer_url", "");
        if (jenniferUrl.isEmpty()) {
            return null;
        }

        return String.format("%s/popup/xview?domainId=%d&time=%d",
            jenniferUrl,
            eventData.getDomainId(),
            eventData.getTime()
        );
    }

    /**
     * Format timestamp
     */
    private String formatTime(long timestamp) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return sdf.format(new Date(timestamp));
    }

    /**
     * Send HTTP POST to Telegram Bot API
     */
    private void sendToTelegram(String apiUrl, String jsonPayload) throws Exception {
        HttpURLConnection connection = null;
        try {
            URL url = new URL(apiUrl);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setDoOutput(true);

            connection.setConnectTimeout(5000);
            connection.setReadTimeout(10000);

            try (OutputStream os = connection.getOutputStream()) {
                os.write(jsonPayload.getBytes(StandardCharsets.UTF_8));
            }

            int responseCode = connection.getResponseCode();
            if (responseCode != 200) {
                LogUtil.warn("Telegram API returned code: {}", responseCode);
            }

        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
    }
}
```

## 설정 방법

### 1. Telegram Bot 생성

1. Telegram에서 `@BotFather` 검색
2. `/newbot` 명령어 입력
3. 봇 이름 및 username 설정
4. Bot Token 복사 (예: `123456789:ABCdefGHIjklMNOpqrsTUVwxyz`)

### 2. Chat ID 확인

#### 개인 채팅
1. Bot과 대화 시작
2. `https://api.telegram.org/bot<BOT_TOKEN>/getUpdates` 접속
3. `chat.id` 값 복사

#### 그룹 채팅
1. 그룹에 Bot 초대
2. 그룹에서 메시지 전송
3. getUpdates에서 `chat.id` 확인 (음수 값)

### 3. JENNIFER 설정

#### 필수 옵션

| 옵션 | 예시 | 설명 |
|------|------|------|
| bot_token | `123456789:ABC...` | Telegram Bot Token |
| chat_id | `123456789` 또는 `-987654321` | 개인 또는 그룹 Chat ID |

#### 선택 옵션

| 옵션 | 설명 |
|------|------|
| jennifer_url | X-View 링크용 JENNIFER URL |

## 예상 메시지 모습

```
🔔 JENNIFER Event

Event: CPU Usage Critical
Domain: production
Instance: server-01
Level: 🔴 CRITICAL
Time: 2025-11-10 14:30:15

CPU usage exceeded 90% (current: 95%)

[View X-View]
```

## Slack vs. Telegram 비교

| 특징 | Slack | Telegram |
|------|-------|----------|
| 설정 복잡도 | 낮음 (Webhook만) | 중간 (Bot + Chat ID) |
| 메시지 포맷 | Attachment/Block Kit | Markdown/HTML |
| 색상 지원 | ✅ | ❌ (이모지로 대체) |
| 버튼 지원 | ✅ | ✅ |
| 모바일 알림 | ✅ | ✅ |
| 무료 사용 | 제한적 | 무제한 |

## 참고 자료

- [Telegram Bot API](https://core.telegram.org/bots/api)
- [Telegram Markdown Formatting](https://core.telegram.org/bots/api#markdown-style)
- [GitHub: jennifer-view-adapter-telegram](https://github.com/jennifersoft/jennifer-view-adapter-telegram)
