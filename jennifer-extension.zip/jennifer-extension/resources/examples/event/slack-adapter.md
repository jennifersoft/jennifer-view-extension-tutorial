# Slack Adapter 완전 구현 예제

Slack Incoming Webhook을 사용하여 JENNIFER 이벤트를 Slack 채널로 전송하는 어댑터입니다.

## 프로젝트 구조

```
jennifer-view-adapter-slack/
├── pom.xml
└── src/main/java/com/aries/slack/
    └── SlackAdapter.java
```

## pom.xml

```xml
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0
         http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <groupId>com.aries</groupId>
    <artifactId>jennifer-view-adapter-slack</artifactId>
    <version>1.0.0</version>
    <packaging>jar</packaging>

    <name>JENNIFER View Adapter for Slack</name>
    <description>Event adapter for sending JENNIFER notifications to Slack</description>

    <properties>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
        <maven.compiler.source>17</maven.compiler.source>
        <maven.compiler.target>17</maven.compiler.target>
    </properties>

    <repositories>
        <repository>
            <id>central</id>
            <url>https://maven.jennifersoft.com/nexus/content/groups/public</url>
        </repository>
    </repositories>

    <dependencies>
        <!-- JENNIFER View Adapter Library -->
        <dependency>
            <groupId>com.aries</groupId>
            <artifactId>extension</artifactId>
            <version>1.5.8</version>
            <type>pom</type>
        </dependency>

        <!-- Logging (provided by JENNIFER) -->
        <dependency>
            <groupId>org.slf4j</groupId>
            <artifactId>slf4j-api</artifactId>
            <version>1.7.32</version>
            <scope>provided</scope>
        </dependency>

        <!-- JSON Processing (provided by JENNIFER) -->
        <dependency>
            <groupId>com.google.code.gson</groupId>
            <artifactId>gson</artifactId>
            <version>2.8.9</version>
            <scope>provided</scope>
        </dependency>
    </dependencies>

    <build>
        <plugins>
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-compiler-plugin</artifactId>
                <version>3.8.1</version>
                <configuration>
                    <source>17</source>
                    <target>17</target>
                </configuration>
            </plugin>

            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-shade-plugin</artifactId>
                <version>3.2.4</version>
                <executions>
                    <execution>
                        <phase>package</phase>
                        <goals>
                            <goal>shade</goal>
                        </goals>
                        <configuration>
                            <artifactSet>
                                <excludes>
                                    <exclude>org.slf4j:*</exclude>
                                    <exclude>com.google.code.gson:*</exclude>
                                    <exclude>com.aries:*</exclude>
                                </excludes>
                            </artifactSet>
                        </configuration>
                    </execution>
                </executions>
            </plugin>
        </plugins>
    </build>
</project>
```

## SlackAdapter.java

```java
package com.aries.slack;

import com.aries.extension.data.EventData;
import com.aries.extension.handler.EventHandler;
import com.aries.extension.util.PropertyUtil;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.aries.extension.util.LogUtil;


import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * JENNIFER Event Adapter for Slack
 *
 * Sends JENNIFER event notifications to Slack channels via Incoming Webhooks.
 *
 * Required Options:
 * - webhook_url: Slack Incoming Webhook URL
 *
 * Optional Options:
 * - jennifer_url: JENNIFER View Server URL for X-View links
 * - username: Bot username (default: JENNIFER)
 * - icon_emoji: Bot icon emoji (default: :bell:)
 * - channel: Override default channel (e.g., #monitoring)
 *
 * @author JenniferSoft
 * @version 1.0
 */
public class SlackAdapter implements EventHandler {

    private String adapterId;

    @Override
    public void setAdapterId(String adapterId) {
        this.adapterId = adapterId;
    }

    @Override
    public void on(EventData[] events) {
        for (EventData eventData : events) {
            try {
                // 1. Get configuration
                String webhookUrl = PropertyUtil.getValue(adapterId, "webhook_url", "");
                if (webhookUrl.isEmpty()) {
                    LogUtil.error("webhook_url is not configured");
                    continue;
                }

                // 2. Build Slack message
                String message = buildSlackMessage(eventData);

                // 3. Send to Slack
                sendToSlack(webhookUrl, message);

            } catch (Exception e) {
                LogUtil.error("Failed to send Slack notification", e);
            }
        }
    }

    /**
     * Build Slack message with Attachment format
     */
    private String buildSlackMessage(EventData eventData) {
        JsonObject root = new JsonObject();

        // Optional overrides
        String username = PropertyUtil.getValue(adapterId, "username", "JENNIFER");
        String iconEmoji = PropertyUtil.getValue(adapterId, "icon_emoji", ":bell:");
        String channel = PropertyUtil.getValue(adapterId, "channel", "");

        if (!username.isEmpty()) {
            root.addProperty("username", username);
        }
        if (!iconEmoji.isEmpty()) {
            root.addProperty("icon_emoji", iconEmoji);
        }
        if (!channel.isEmpty()) {
            root.addProperty("channel", channel);
        }

        // Create attachment
        JsonObject attachment = new JsonObject();

        // Color based on event level
        attachment.addProperty("color", getSlackColor(eventData.getEventLevel()));

        // Title
        attachment.addProperty("title", "JENNIFER Event: " + eventData.getEventName());

        // Pretext (fallback text for notifications)
        attachment.addProperty("fallback", String.format(
            "JENNIFER Event [%s] %s - %s",
            eventData.getEventLevel(),
            eventData.getDomainName(),
            eventData.getEventName()
        ));

        // Fields
        JsonArray fields = new JsonArray();

        fields.add(createField("Domain", eventData.getDomainName(), true));
        fields.add(createField("Instance", eventData.getInstanceName(), true));
        fields.add(createField("Level", eventData.getEventLevel(), true));
        fields.add(createField("Time", formatTime(eventData.getTime()), true));

        // Message (if available)
        String eventMessage = eventData.getMessage();
        if (eventMessage != null && !eventMessage.isEmpty()) {
            fields.add(createField("Message", eventMessage, false));
        }

        // Value (if available)
        Object value = eventData.getValue();
        if (value != null) {
            fields.add(createField("Value", value.toString(), true));
        }

        attachment.add("fields", fields);

        // X-View link button
        String xviewUrl = buildXViewUrl(eventData);
        if (xviewUrl != null) {
            JsonArray actions = new JsonArray();
            JsonObject button = new JsonObject();
            button.addProperty("type", "button");
            button.addProperty("text", "View X-View");
            button.addProperty("url", xviewUrl);
            actions.add(button);
            attachment.add("actions", actions);
        }

        // Footer
        attachment.addProperty("footer", "JENNIFER APM");
        attachment.addProperty("ts", eventData.getTime() / 1000);  // Unix timestamp in seconds

        // Add attachment to root
        JsonArray attachments = new JsonArray();
        attachments.add(attachment);
        root.add("attachments", attachments);

        return root.toString();
    }

    /**
     * Create Slack field object
     */
    private JsonObject createField(String title, String value, boolean isShort) {
        JsonObject field = new JsonObject();
        field.addProperty("title", title);
        field.addProperty("value", value);
        field.addProperty("short", isShort);
        return field;
    }

    /**
     * Get Slack attachment color based on event level
     */
    private String getSlackColor(String eventLevel) {
        if (eventLevel == null) {
            return "#36A64F";  // Green (default)
        }

        switch (eventLevel) {
            case "FATAL":
            case "CRITICAL":
                return "#FF0000";  // Red
            case "WARNING":
                return "#FFA500";  // Orange
            case "INFO":
            default:
                return "#36A64F";  // Green
        }
    }

    /**
     * Build X-View URL for viewing transaction details
     */
    private String buildXViewUrl(EventData eventData) {
        String jenniferUrl = PropertyUtil.getValue(adapterId, "jennifer_url", "");
        if (jenniferUrl.isEmpty()) {
            return null;
        }

        return String.format("%s/popup/xview?domainId=%d&time=%d",
            jenniferUrl,
            eventData.getDomainId(),
            eventData.getTime()
        );
    }

    /**
     * Format timestamp to readable string
     */
    private String formatTime(long timestamp) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return sdf.format(new Date(timestamp));
    }

    /**
     * Send HTTP POST request to Slack webhook
     */
    private void sendToSlack(String webhookUrl, String jsonPayload) throws Exception {
        HttpURLConnection connection = null;
        try {
            URL url = new URL(webhookUrl);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setDoOutput(true);

            // Set timeouts
            connection.setConnectTimeout(5000);
            connection.setReadTimeout(10000);

            // Write payload
            try (OutputStream os = connection.getOutputStream()) {
                os.write(jsonPayload.getBytes(StandardCharsets.UTF_8));
            }

            // Check response
            int responseCode = connection.getResponseCode();
            if (responseCode != 200) {
                LogUtil.warn("Slack webhook returned unexpected code: {}", responseCode);
            } else {
                LogUtil.debug("Slack notification sent successfully");
            }

        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
    }
}
```

## 빌드 및 배포

### 1. 빌드

```bash
mvn clean package
```

생성된 JAR: `target/jennifer-view-adapter-slack-1.0.0.jar`

### 2. JENNIFER 서버에 배포

```bash
cp target/jennifer-view-adapter-slack-1.0.0.jar $JENNIFER_HOME/adapter/
```

### 3. JENNIFER 서버 재시작

```bash
$JENNIFER_HOME/bin/jennifer stop
$JENNIFER_HOME/bin/jennifer start
```

## JENNIFER 관리 UI 설정

### 1. Slack Incoming Webhook 생성

1. Slack 워크스페이스에서 "앱 관리" 접속
2. "Incoming Webhooks" 검색 및 추가
3. 알림을 받을 채널 선택
4. Webhook URL 복사 (예: `https://hooks.slack.com/services/T00000000/B00000000/XXXXXXXXXXXXXXXXXXXX`)

### 2. 어댑터 등록 (JENNIFER 관리 UI)

1. 어댑터 관리 > 추가
2. 어댑터 JAR 파일 선택: `jennifer-view-adapter-slack-1.0.0.jar`
3. 어댑터 클래스: `com.aries.slack.SlackAdapter`

### 3. 옵션 설정

#### 필수 옵션

| 옵션 | 값 | 설명 |
|------|-----|------|
| webhook_url | `https://hooks.slack.com/services/...` | Slack Incoming Webhook URL |

#### 선택 옵션

| 옵션 | 기본값 | 설명 |
|------|--------|------|
| jennifer_url | (비어있음) | JENNIFER View Server URL (예: `http://jennifer.company.com:7900`) |
| username | JENNIFER | Slack 봇 사용자 이름 |
| icon_emoji | :bell: | Slack 봇 아이콘 (예: `:warning:`, `:fire:`) |
| channel | (비어있음) | 채널 오버라이드 (예: `#critical-alerts`) |

### 4. 이벤트 정책에 어댑터 연결

1. 이벤트 정책 관리
2. 특정 정책 선택 (예: CPU 과부하 경고)
3. "Slack Adapter" 체크

## 예상 Slack 메시지 모습

```
JENNIFER                                      오후 2:30

JENNIFER Event: CPU Usage Critical
────────────────────────────────────
Domain           Instance
production       server-01

Level            Time
CRITICAL         2025-11-10 14:30:15

Message
CPU usage exceeded 90% (current: 95%)

[View X-View]

JENNIFER APM | 14:30:15
```

## 트러블슈팅

### 메시지가 전송되지 않음

1. JENNIFER 서버 로그 확인: `$JENNIFER_HOME/logs/jennifer.log`
2. Webhook URL이 올바른지 확인
3. 방화벽에서 `https://hooks.slack.com` 접근 허용 확인

### 색상이 표시되지 않음

- Slack의 Attachment API는 일부 클라이언트에서 색상을 지원하지 않을 수 있습니다.
- Block Kit으로 전환하면 더 나은 호환성을 얻을 수 있습니다.

### X-View 링크가 작동하지 않음

- `jennifer_url` 옵션이 설정되어 있는지 확인
- URL이 JENNIFER View Server의 실제 주소인지 확인
- 포트 번호 포함 여부 확인 (예: `:7900`)

## 참고 자료

- [Slack Incoming Webhooks](https://api.slack.com/messaging/webhooks)
- [Slack Message Attachments](https://api.slack.com/reference/messaging/attachments)
- [JENNIFER Adapter Development Guide](https://github.com/jennifersoft/jennifer-view-adapter-tutorial)
