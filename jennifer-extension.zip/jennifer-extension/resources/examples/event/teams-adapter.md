# Microsoft Teams Adapter 완전 구현 예제

Microsoft Teams Incoming Webhook을 사용하여 JENNIFER 이벤트를 Teams 채널로 전송하는 어댑터입니다.

## 프로젝트 구조

```
jennifer-view-adapter-teams/
├── pom.xml
└── src/main/java/com/aries/teams/
    └── TeamsAdapter.java
```

## pom.xml

```xml
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0
                             http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <groupId>com.aries</groupId>
    <artifactId>jennifer-view-adapter-teams</artifactId>
    <version>1.0.0</version>
    <packaging>jar</packaging>

    <name>JENNIFER Teams Adapter</name>
    <description>JENNIFER Event Adapter for Microsoft Teams</description>

    <properties>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
        <maven.compiler.source>17</maven.compiler.source>
        <maven.compiler.target>17</maven.compiler.target>
    </properties>

    <repositories>
        <repository>
            <id>central</id>
            <url>https://maven.jennifersoft.com/nexus/content/groups/public</url>
        </repository>
    </repositories>

    <dependencies>
        <!-- JENNIFER View Adapter Library -->
        <dependency>
            <groupId>com.aries</groupId>
            <artifactId>extension</artifactId>
            <version>1.5.8</version>
            <type>pom</type>
        </dependency>

        <!-- JSON Processing (provided by JENNIFER) -->
        <dependency>
            <groupId>com.google.code.gson</groupId>
            <artifactId>gson</artifactId>
            <version>2.8.9</version>
            <scope>provided</scope>
        </dependency>
    </dependencies>

    <build>
        <plugins>
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-compiler-plugin</artifactId>
                <version>3.8.1</version>
                <configuration>
                    <source>17</source>
                    <target>17</target>
                </configuration>
            </plugin>
        </plugins>
    </build>
</project>
```

## TeamsAdapter.java

```java
package com.aries.teams;

import com.aries.extension.data.EventData;
import com.aries.extension.handler.EventAdapter;
import com.aries.extension.util.PropertyUtil;
import com.aries.extension.util.LogUtil;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Microsoft Teams Event Adapter for JENNIFER
 *
 * Sends JENNIFER event notifications to Microsoft Teams channels via Incoming Webhook.
 *
 * Required Options:
 * - webhook_url: Teams Incoming Webhook URL
 *
 * Optional Options:
 * - jennifer_url: JENNIFER View Server URL for X-View links
 * - theme_color: Card theme color (default: based on event level)
 * - mention_users: Users to mention (@user@domain.com)
 *
 * @author JenniferSoft
 * @version 1.0.0
 */
public class TeamsAdapter implements EventHandler {

    private String adapterId;

    @Override
    public void setAdapterId(String adapterId) {
        this.adapterId = adapterId;
    }

    @Override
    public void on(EventData[] events) {
        for (EventData eventData : events) {
            try {
                // 1. Get configuration
                String webhookUrl = PropertyUtil.getValue(adapterId, "webhook_url", "");
                if (webhookUrl.isEmpty()) {
                    LogUtil.error("webhook_url is not configured");
                    continue;
                }

                String jenniferUrl = PropertyUtil.getValue(adapterId, "jennifer_url", "");
                String themeColor = PropertyUtil.getValue(adapterId, "theme_color", "");
                String mentionUsers = PropertyUtil.getValue(adapterId, "mention_users", "");

                // 2. Build Teams message card
                String messageCard = buildTeamsMessageCard(eventData, jenniferUrl, themeColor, mentionUsers);

                // 3. Send to Teams
                sendToTeams(webhookUrl, messageCard);

                LogUtil.info("Teams notification sent for event: " + eventData.getEventName());

            } catch (Exception e) {
                LogUtil.error("Failed to send Teams notification", e);
            }
        }
    }

    /**
     * Build Microsoft Teams MessageCard format (Adaptive Card)
     */
    private String buildTeamsMessageCard(EventData eventData, String jenniferUrl, 
                                          String themeColor, String mentionUsers) {
        JsonObject card = new JsonObject();
        
        // MessageCard type
        card.addProperty("@type", "MessageCard");
        card.addProperty("@context", "https://schema.org/extensions");
        
        // Theme color based on event level
        if (themeColor.isEmpty()) {
            themeColor = getThemeColor(eventData.getEventLevel());
        }
        card.addProperty("themeColor", themeColor);
        
        // Title
        card.addProperty("title", "🔔 JENNIFER Event Alert");
        
        // Summary (for notifications)
        card.addProperty("summary", eventData.getEventName());
        
        // Sections
        JsonArray sections = new JsonArray();
        
        // Main section with event details
        JsonObject mainSection = new JsonObject();
        mainSection.addProperty("activityTitle", "**" + eventData.getEventName() + "**");
        mainSection.addProperty("activitySubtitle", formatEventTime(eventData.getTime()));
        mainSection.addProperty("activityImage", getEventLevelIcon(eventData.getEventLevel()));
        
        // Facts (key-value pairs)
        JsonArray facts = new JsonArray();
        facts.add(createFact("Event Level", eventData.getEventLevel()));
        facts.add(createFact("Domain", eventData.getDomainName()));
        facts.add(createFact("Instance", eventData.getInstanceName()));
        
        if (eventData.getMessage() != null && !eventData.getMessage().isEmpty()) {
            facts.add(createFact("Message", eventData.getMessage()));
        }
        
        mainSection.add("facts", facts);
        sections.add(mainSection);
        
        // Mention users if specified
        if (!mentionUsers.isEmpty()) {
            JsonObject mentionSection = new JsonObject();
            mentionSection.addProperty("text", buildMentionText(mentionUsers));
            sections.add(mentionSection);
        }
        
        card.add("sections", sections);
        
        // Potential Actions (buttons)
        if (!jenniferUrl.isEmpty()) {
            JsonArray actions = new JsonArray();
            JsonObject xviewAction = new JsonObject();
            xviewAction.addProperty("@type", "OpenUri");
            xviewAction.addProperty("name", "View X-View Details");
            
            JsonArray targets = new JsonArray();
            JsonObject target = new JsonObject();
            target.addProperty("os", "default");
            target.addProperty("uri", buildXViewUrl(eventData, jenniferUrl));
            targets.add(target);
            
            xviewAction.add("targets", targets);
            actions.add(xviewAction);
            card.add("potentialAction", actions);
        }
        
        return card.toString();
    }

    /**
     * Create a fact (key-value pair) for Teams card
     */
    private JsonObject createFact(String name, String value) {
        JsonObject fact = new JsonObject();
        fact.addProperty("name", name);
        fact.addProperty("value", value != null ? value : "N/A");
        return fact;
    }

    /**
     * Get theme color based on event level
     */
    private String getThemeColor(String eventLevel) {
        if (eventLevel == null) {
            return "0078D4"; // Default blue
        }
        
        switch (eventLevel) {
            case "FATAL":
                return "C00000"; // Dark red
            case "CRITICAL":
                return "FF0000"; // Red
            case "WARNING":
                return "FFA500"; // Orange
            case "INFO":
                return "0078D4"; // Blue
            default:
                return "808080"; // Gray
        }
    }

    /**
     * Get event level icon URL
     */
    private String getEventLevelIcon(String eventLevel) {
        // You can host your own icons or use public CDN
        String baseUrl = "https://raw.githubusercontent.com/jennifersoft/assets/main/icons/";
        
        switch (eventLevel) {
            case "FATAL":
            case "CRITICAL":
                return baseUrl + "error.png";
            case "WARNING":
                return baseUrl + "warning.png";
            case "INFO":
                return baseUrl + "info.png";
            default:
                return baseUrl + "default.png";
        }
    }

    /**
     * Build mention text for users
     */
    private String buildMentionText(String mentionUsers) {
        String[] users = mentionUsers.split(",");
        StringBuilder mentions = new StringBuilder();
        
        for (String user : users) {
            user = user.trim();
            if (!user.isEmpty()) {
                mentions.append("<at>").append(user).append("</at> ");
            }
        }
        
        return mentions.toString();
    }

    /**
     * Format event time
     */
    private String formatEventTime(long timestamp) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return sdf.format(new Date(timestamp));
    }

    /**
     * Build X-View URL
     */
    private String buildXViewUrl(EventData eventData, String jenniferUrl) {
        return String.format("%s/popup/xview?domainId=%d&time=%d",
            jenniferUrl,
            eventData.getDomainId(),
            eventData.getTime()
        );
    }

    /**
     * Send message card to Microsoft Teams
     */
    private void sendToTeams(String webhookUrl, String messageCard) throws Exception {
        HttpURLConnection connection = null;
        try {
            URL url = new URL(webhookUrl);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            connection.setDoOutput(true);
            
            // Timeout settings
            connection.setConnectTimeout(5000);
            connection.setReadTimeout(10000);
            
            // Send request
            try (OutputStream os = connection.getOutputStream()) {
                os.write(messageCard.getBytes(StandardCharsets.UTF_8));
                os.flush();
            }
            
            // Check response
            int responseCode = connection.getResponseCode();
            if (responseCode != 200) {
                LogUtil.warn("Teams webhook returned non-200 status: " + responseCode);
            }
            
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
    }
}
```

## Teams Webhook 설정

### 1. Teams에서 Incoming Webhook 추가

1. Teams 채널 선택
2. **⋯** (More options) → **Connectors** 클릭
3. **Incoming Webhook** 검색 및 추가
4. Webhook 이름 입력 (예: "JENNIFER Alerts")
5. Webhook URL 복사

### 2. JENNIFER 어댑터 설정

```properties
# 필수 옵션
webhook_url = https://outlook.office.com/webhook/...

# 선택 옵션
jennifer_url = http://jennifer-server:7900
theme_color = FF6600
mention_users = user1@company.com,user2@company.com
```

## 빌드 및 배포

```bash
# 빌드
mvn clean package

# JAR 파일 복사
cp target/jennifer-view-adapter-teams-1.0.0.jar $JENNIFER_HOME/adapter/

# JENNIFER 서버 재시작
$JENNIFER_HOME/bin/jennifer restart
```

## Teams 메시지 예시

Teams 채널에 다음과 같은 카드 형식으로 메시지가 전송됩니다:

```
┌─────────────────────────────────────────┐
│ 🔔 JENNIFER Event Alert                 │
│ ─────────────────────────────────────── │
│ **Response Time Critical**              │
│ 2025-11-10 14:30:25                     │
│                                         │
│ Event Level:    CRITICAL                │
│ Domain:         Production              │
│ Instance:       web-server-01           │
│ Message:        Response time > 5000ms  │
│                                         │
│ @admin@company.com                      │
│                                         │
│ [View X-View Details]                   │
└─────────────────────────────────────────┘
```

## 참고 자료

- [Microsoft Teams Incoming Webhooks](https://docs.microsoft.com/en-us/microsoftteams/platform/webhooks-and-connectors/how-to/add-incoming-webhook)
- [MessageCard Reference](https://docs.microsoft.com/en-us/outlook/actionable-messages/message-card-reference)
- [Adaptive Cards](https://adaptivecards.io/)

## 트러블슈팅

### Teams에 메시지가 표시되지 않음

1. Webhook URL이 올바른지 확인
2. JSON 포맷이 유효한지 확인
3. JENNIFER 로그에서 에러 메시지 확인:
   ```bash
   tail -f $JENNIFER_HOME/logs/jennifer.log | grep Teams
   ```

### 한글이 깨짐

`UTF-8` 인코딩이 올바르게 설정되었는지 확인:
```java
connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
```

### X-View 링크가 작동하지 않음

`jennifer_url` 옵션이 외부에서 접근 가능한 URL인지 확인
