# XViewLog Adapter 완전 구현 예제

X-View 실시간 트랜잭션 데이터를 파일로 저장하는 어댑터입니다.

## 주요 특징

- 커스터마이징 가능한 로그 포맷 (패턴 기반)
- 시간 기반 자동 롤링 (시간/일/주 단위)
- 고성능 BufferedWriter
- Thread-safe 구현

## LogAdapter.java (핵심 구현)

```java
package com.aries.xviewlog;

import com.aries.extension.data.ProfileData;
import com.aries.extension.handler.ProfileDataHandler;
import com.aries.extension.util.PropertyUtil;
import com.aries.extension.util.LogUtil;


import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class LogAdapter implements TransactionHandler {

    private static final String DEFAULT_PATTERN =
        "[%startTime, %endTime, %collectTime] " +
        "Domain=%domainName(%domainId), " +
        "Instance=%instanceName(%instanceId), " +
        "TXID=%txid, " +
        "Client IP=%clientIp, " +
        "User ID=%userId, " +
        "Response Time=%responseTime, " +
        "SQL Time=%sqlTime, " +
        "ERROR=%error";

    private String adapterId;

    @Override
    public void setAdapterId(String adapterId) {
        this.adapterId = adapterId;
    }

    @Override
    public void on(TransactionData[] transactions) {
        for (TransactionData txData : transactions) {
            try {
                // 1. Get options
                String pattern = PropertyUtil.getValue(adapterId, "pattern", DEFAULT_PATTERN);
                String dateFormat = PropertyUtil.getValue(adapterId, "date_format", "HH:mm:ss");
                String fullPath = PropertyUtil.getValue(adapterId, "full_path", "../logs/xviewlog.%d{yyyy-MM-dd_HH}.log");
                boolean rollingMode = Boolean.parseBoolean(PropertyUtil.getValue(adapterId, "rolling_mode", "true"));

                // 2. Build log message
                String logMessage = buildLogMessage(txData, pattern, dateFormat);

                // 3. Write to file
                writeLog(fullPath, logMessage, rollingMode);

            } catch (Exception e) {
                LogUtil.error("Failed to write transaction log", e);
            }
        }
    }

    private String buildLogMessage(TransactionData txData, String pattern, String dateFormat) {
        SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);

        return pattern
            .replace("%startTime", sdf.format(new Date(txData.getStartTime())))
            .replace("%endTime", sdf.format(new Date(txData.getEndTime())))
            .replace("%collectTime", sdf.format(new Date(txData.getCollectTime())))
            .replace("%domainName", nvl(txData.getDomainName()))
            .replace("%domainId", String.valueOf(txData.getDomainId()))
            .replace("%instanceName", nvl(txData.getInstanceName()))
            .replace("%instanceId", String.valueOf(txData.getInstanceId()))
            .replace("%txid", String.valueOf(txData.getTxid()))
            .replace("%clientIp", nvl(txData.getClientIp()))
            .replace("%userId", nvl(txData.getUserId()))
            .replace("%responseTime", String.valueOf(txData.getResponseTime()))
            .replace("%sqlTime", String.valueOf(txData.getSqlTime()))
            .replace("%error", nvl(txData.getError()));
    }

    private String nvl(String value) {
        return value != null ? value : "";
    }

    private synchronized void writeLog(String fullPath, String message, boolean rollingMode) throws IOException {
        String actualPath = fullPath;
        if (rollingMode) {
            actualPath = resolveDatePattern(fullPath);
        }

        try (FileWriter fw = new FileWriter(actualPath, true);
             BufferedWriter bw = new BufferedWriter(fw)) {
            bw.write(message);
            bw.newLine();
        }
    }

    private String resolveDatePattern(String path) {
        if (!path.contains("%d{")) {
            return path;
        }

        int start = path.indexOf("%d{");
        int end = path.indexOf("}", start);

        if (start == -1 || end == -1) {
            return path;
        }

        String datePattern = path.substring(start + 3, end);
        SimpleDateFormat sdf = new SimpleDateFormat(datePattern);
        String dateStr = sdf.format(new Date());

        return path.substring(0, start) + dateStr + path.substring(end + 1);
    }
}
```

## 설정 예시

### 기본 설정 (시간별 롤링)

| 옵션 | 값 |
|------|-----|
| full_path | `../logs/xviewlog.%d{yyyy-MM-dd_HH}.log` |
| rolling_mode | `true` |
| pattern | (기본 패턴 사용) |
| date_format | `HH:mm:ss` |

**결과 파일**: `xviewlog.2025-11-10_14.log`, `xviewlog.2025-11-10_15.log`, ...

### 일별 롤링

| 옵션 | 값 |
|------|-----|
| full_path | `../logs/xviewlog.%d{yyyy-MM-dd}.log` |

**결과 파일**: `xviewlog.2025-11-10.log`, `xviewlog.2025-11-11.log`, ...

### 커스텀 패턴

```
pattern = [%startTime] TXID=%txid, Response=%responseTime ms, SQL=%sqlTime ms, Error=%error
```

**결과 로그**:
```
[14:30:15] TXID=TX123456, Response=250 ms, SQL=45 ms, Error=
[14:30:16] TXID=TX123457, Response=180 ms, SQL=32 ms, Error=
```

## 로그 출력 예시

### 기본 패턴

```
[14:30:15, 14:30:15, 14:30:20] Domain=production(1), Instance=server-01(101), TXID=TX123456, Client IP=192.168.1.100, User ID=user@company.com, Response Time=250, SQL Time=45, ERROR=
[14:30:16, 14:30:16, 14:30:21] Domain=production(1), Instance=server-01(101), TXID=TX123457, Client IP=192.168.1.101, User ID=admin@company.com, Response Time=180, SQL Time=32, ERROR=
```

### 에러 발생 시

```
[14:35:20, 14:35:23, 14:35:28] Domain=production(1), Instance=server-02(102), TXID=TX123500, Client IP=192.168.1.150, User ID=user@company.com, Response Time=3250, SQL Time=0, ERROR=java.sql.SQLException: Connection timeout
```

## 성능 특성

- **TPS**: ~2,000 (BufferedWriter 사용)
- **메모리**: 낮음 (버퍼링만)
- **디스크 I/O**: 최적화됨
- **Thread-safe**: `synchronized` 사용

## 참고 자료

- [GitHub: jennifer-view-adapter-xviewlog](https://github.com/jennifersoft/jennifer-view-adapter-xviewlog)
- [파일 로깅 패턴](../../patterns/file-logging.md)
