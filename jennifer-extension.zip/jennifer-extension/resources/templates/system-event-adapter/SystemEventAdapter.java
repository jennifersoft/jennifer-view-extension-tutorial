package com.aries.{SERVICE_LOWER};

import com.aries.extension.data.SystemEventData;
import com.aries.extension.handler.SystemEventHandler;
import com.aries.extension.util.PropertyUtil;
import com.aries.extension.util.LogUtil;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * System Event Adapter for JENNIFER
 *
 * Handles system-level events from JENNIFER data servers.
 * Unlike EventData (application performance events), SystemEventData
 * contains infrastructure/operations events from JENNIFER servers.
 *
 * Required Options:
 * - log_path: Path to system event log file
 * - enabled: Enable/disable adapter (default: true)
 *
 * Optional Options:
 * - date_pattern: Date format for timestamps (default: yyyy-MM-dd HH:mm:ss)
 * - alert_keywords: Comma-separated keywords for alerts (e.g., "ERROR,CRITICAL")
 *
 * @author {AUTHOR_NAME}
 * @version 1.0
 */
public class {SERVICE_CLASS}Adapter implements SystemEventHandler {

    private String adapterId;

    @Override
    public void setAdapterId(String adapterId) {
        this.adapterId = adapterId;
    }

    @Override
    public void on(SystemEventData[] events) {
        // Batch processing: Handle multiple system events at once
        for (SystemEventData event : events) {
            try {
                // 1. Check if adapter is enabled
                boolean enabled = Boolean.parseBoolean(
                    PropertyUtil.getValue(adapterId, "enabled", "true")
                );

                if (!enabled) {
                    LogUtil.debug("System Event Adapter is disabled");
                    return;
                }

                // 2. Extract system event data
                String subject = event.getSubject();
                String message = event.getMessage();
                String dataServer = event.getDataServer();

                LogUtil.info("System Event from " + dataServer + ": " + subject);

                // 3. Process system event
                processSystemEvent(event);

            } catch (Exception e) {
                LogUtil.error("Failed to process system event", e);
            }
        }
    }

    /**
     * Process individual system event
     *
     * Customize this method based on your requirements:
     * - Log to file
     * - Send email alerts
     * - Forward to monitoring systems
     * - Trigger automation scripts
     */
    private void processSystemEvent(SystemEventData event) throws Exception {
        // Get configuration
        String logPath = PropertyUtil.getValue(adapterId, "log_path", "./system_events.log");
        String datePattern = PropertyUtil.getValue(adapterId, "date_pattern", "yyyy-MM-dd HH:mm:ss");
        String alertKeywords = PropertyUtil.getValue(adapterId, "alert_keywords", "");

        // Format log message
        SimpleDateFormat sdf = new SimpleDateFormat(datePattern);
        String timestamp = sdf.format(new Date());

        String logMessage = String.format("[%s] [%s] %s - %s",
            timestamp,
            event.getDataServer(),
            event.getSubject(),
            event.getMessage()
        );

        // Write to log file
        writeToLog(logPath, logMessage);

        // Check if alert is needed
        if (!alertKeywords.isEmpty()) {
            String[] keywords = alertKeywords.split(",");
            for (String keyword : keywords) {
                if (event.getSubject().contains(keyword.trim()) ||
                    event.getMessage().contains(keyword.trim())) {

                    sendAlert(event);
                    break;
                }
            }
        }
    }

    /**
     * Write system event to log file
     */
    private void writeToLog(String logPath, String message) throws IOException {
        try (FileWriter fw = new FileWriter(logPath, true);
             BufferedWriter bw = new BufferedWriter(fw)) {

            bw.write(message);
            bw.newLine();
            bw.flush();

            LogUtil.debug("System event logged to: " + logPath);
        }
    }

    /**
     * Send alert for critical system events
     *
     * Implement alert mechanism based on your requirements:
     * - Email notification
     * - Slack/Teams message
     * - SMS alert
     * - PagerDuty integration
     */
    private void sendAlert(SystemEventData event) {
        // TODO: Implement alert mechanism

        LogUtil.warn("ALERT: System event requires attention - " +
                   event.getSubject() + ": " + event.getMessage());

        // Example: Send email alert
        /*
        String smtpHost = PropertyUtil.getValue(adapterId, "smtp_host", "");
        String recipient = PropertyUtil.getValue(adapterId, "alert_email", "");

        if (!smtpHost.isEmpty() && !recipient.isEmpty()) {
            String emailBody = buildEmailBody(event);
            sendEmail(smtpHost, recipient, "System Alert: " + event.getSubject(), emailBody);
        }
        */
    }

    /**
     * Build email body for alert
     */
    private String buildEmailBody(SystemEventData event) {
        StringBuilder body = new StringBuilder();
        body.append("JENNIFER System Event Alert\n\n");
        body.append("Data Server: ").append(event.getDataServer()).append("\n");
        body.append("Subject: ").append(event.getSubject()).append("\n");
        body.append("Message: ").append(event.getMessage()).append("\n");
        body.append("\nTimestamp: ").append(new Date()).append("\n");

        return body.toString();
    }
}
