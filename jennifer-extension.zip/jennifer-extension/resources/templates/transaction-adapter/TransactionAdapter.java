package com.aries.{SERVICE_LOWER};

import com.aries.extension.data.TransactionData;
import com.aries.extension.handler.TransactionHandler;
import com.aries.extension.util.PropertyUtil;
import com.aries.extension.util.LogUtil;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * JENNIFER Transaction Adapter for {SERVICE_NAME}
 *
 * This adapter processes real-time X-View transaction data from JENNIFER.
 *
 * Required Options:
 * - full_path: Log file path (supports date pattern, e.g., ../logs/xview.%d{yyyy-MM-dd_HH}.log)
 *
 * Optional Options:
 * - pattern: Log format pattern (default: see DEFAULT_PATTERN)
 * - date_format: Date format for timestamps (default: HH:mm:ss)
 * - rolling_mode: Enable file rolling based on date pattern (default: true)
 *
 * @author {AUTHOR_NAME}
 * @version 1.0
 */
public class {SERVICE_CLASS}Adapter implements TransactionHandler {

    private String adapterId;

    /**
     * Default log pattern
     * Variables: %startTime, %endTime, %txid, %domainName, %instanceName, %responseTime, etc.
     */
    private static final String DEFAULT_PATTERN =
        "[%startTime, %endTime, %collectTime] " +
        "Domain=%domainName(%domainId), " +
        "Instance=%instanceName(%instanceId), " +
        "TXID=%txid, " +
        "Client IP=%clientIp, " +
        "User ID=%userId, " +
        "Response Time=%responseTime, " +
        "SQL Time=%sqlTime, " +
        "ERROR=%error";

    @Override
    public void setAdapterId(String adapterId) {
        this.adapterId = adapterId;
    }

    @Override
    public void on(TransactionData[] transactions) {
        // Batch processing: Handle multiple transactions at once
        for (TransactionData txData : transactions) {
            try {
                // 1. Get configuration
                String fullPath = PropertyUtil.getValue(adapterId, "full_path", "");
                if (fullPath.isEmpty()) {
                    LogUtil.error("full_path is not configured");
                    return;
                }

                String pattern = PropertyUtil.getValue(adapterId, "pattern", DEFAULT_PATTERN);
                String dateFormat = PropertyUtil.getValue(adapterId, "date_format", "HH:mm:ss");
                boolean rollingMode = Boolean.parseBoolean(PropertyUtil.getValue(adapterId, "rolling_mode", "true"));

                // 2. Build log message
                String logMessage = buildLogMessage(txData, pattern, dateFormat);

                // 3. Write to file
                writeLog(fullPath, logMessage, rollingMode);

            } catch (Exception e) {
                LogUtil.error("Failed to write transaction log", e);
            }
        }
    }

    /**
     * Build log message from transaction data using pattern
     */
    private String buildLogMessage(TransactionData txData, String pattern, String dateFormat) {
        SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);

        String message = pattern
            // Time fields
            .replace("%startTime", formatTime(sdf, txData.getStartTime()))
            .replace("%endTime", formatTime(sdf, txData.getEndTime()))
            .replace("%collectTime", formatTime(sdf, txData.getCollectTime()))

            // Domain & Instance
            .replace("%domainId", String.valueOf(txData.getDomainId()))
            .replace("%domainName", nvl(txData.getDomainName()))
            .replace("%instanceId", String.valueOf(txData.getInstanceId()))
            .replace("%instanceName", nvl(txData.getInstanceName()))

            // Transaction Info
            .replace("%txid", nvl(txData.getTxid()))
            .replace("%clientIp", nvl(txData.getClientIp()))
            .replace("%clientId", nvl(txData.getClientId()))
            .replace("%userId", nvl(txData.getUserId()))
            .replace("%application", nvl(txData.getApplication()))

            // Performance Metrics
            .replace("%responseTime", String.valueOf(txData.getResponseTime()))
            .replace("%frontendTime", String.valueOf(txData.getFrontendTime()))
            .replace("%networkTime", String.valueOf(txData.getNetworkTime()))
            .replace("%sqlTime", String.valueOf(txData.getSqlTime()))
            .replace("%fetchTime", String.valueOf(txData.getFetchTime()))
            .replace("%cpuTime", String.valueOf(txData.getCpuTime()))
            .replace("%externalcallTime", String.valueOf(txData.getExternalcallTime()))

            // Error
            .replace("%error", nvl(txData.getError()));

        return message;
    }

    /**
     * Null-safe string converter
     */
    private String nvl(String value) {
        return value != null ? value : "";
    }

    /**
     * Format timestamp
     */
    private String formatTime(SimpleDateFormat sdf, long timestamp) {
        return sdf.format(new Date(timestamp));
    }

    /**
     * Write log to file (with optional rolling support)
     */
    private synchronized void writeLog(String fullPath, String message, boolean rollingMode) throws IOException {
        // Resolve date pattern if rolling mode is enabled
        String actualPath = fullPath;
        if (rollingMode) {
            actualPath = resolveDatePattern(fullPath);
        }

        // Write to file (append mode)
        try (FileWriter fw = new FileWriter(actualPath, true);
             BufferedWriter bw = new BufferedWriter(fw)) {
            bw.write(message);
            bw.newLine();
        }
    }

    /**
     * Resolve date pattern in file path
     * Example: ../logs/xview.%d{yyyy-MM-dd_HH}.log → ../logs/xview.2025-11-10_14.log
     */
    private String resolveDatePattern(String path) {
        if (!path.contains("%d{")) {
            return path;
        }

        // Find pattern
        int start = path.indexOf("%d{");
        int end = path.indexOf("}", start);

        if (start == -1 || end == -1) {
            return path;
        }

        // Extract date format
        String datePattern = path.substring(start + 3, end);
        SimpleDateFormat sdf = new SimpleDateFormat(datePattern);
        String dateStr = sdf.format(new Date());

        // Replace pattern with actual date
        return path.substring(0, start) + dateStr + path.substring(end + 1);
    }
}
