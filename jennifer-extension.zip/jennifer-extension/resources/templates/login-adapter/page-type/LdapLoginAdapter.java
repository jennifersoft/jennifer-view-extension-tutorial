package com.aries.login.ldap;

import com.aries.extension.handler.LoginHandler;
import com.aries.extension.data.UserData;
import com.aries.extension.util.PropertyUtil;
import com.aries.extension.util.LogUtil;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.*;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

/**
 * LDAP Login Adapter for JENNIFER
 *
 * Authenticates users against an LDAP server (Active Directory, OpenLDAP, etc.)
 * and retrieves their group memberships.
 *
 * Required Options:
 * - serverUrl: LDAP server URL (e.g., ldap://127.0.0.1:389)
 * - baseRdn: Base RDN (e.g., dc=company,dc=com)
 * - adminId: LDAP admin user DN (e.g., cn=admin)
 * - adminPwd: LDAP admin password
 *
 * Optional Options:
 * - baseOu: Base OU for user search (default: Users)
 * - groupPrefix: Group name prefix filter (e.g., JENNIFER*,APP*)
 * - fixedGroup: Fixed group assignment (overrides LDAP groups)
 * - useSsl: Use SSL/TLS (default: false)
 *
 * @author {AUTHOR_NAME}
 * @version 1.0
 */
public class LdapLoginAdapter implements LoginHandler {

    private String adapterId;

    @Override
    public void setAdapterId(String adapterId) {
        this.adapterId = adapterId;
    }

    @Override
    public UserData preHandle(String userId, String password) {
        try {
            // 1. Get LDAP configuration
            String serverUrl = PropertyUtil.getValue(adapterId, "serverUrl", "");
            String baseRdn = PropertyUtil.getValue(adapterId, "baseRdn", "");
            String adminId = PropertyUtil.getValue(adapterId, "adminId", "");
            String adminPwd = PropertyUtil.getValue(adapterId, "adminPwd", "");
            String baseOu = PropertyUtil.getValue(adapterId, "baseOu", "Users");
            String groupPrefix = PropertyUtil.getValue(adapterId, "groupPrefix", "");
            String fixedGroup = PropertyUtil.getValue(adapterId, "fixedGroup", "");
            boolean useSsl = Boolean.parseBoolean(PropertyUtil.getValue(adapterId, "useSsl", "false"));

            if (serverUrl.isEmpty() || baseRdn.isEmpty()) {
                LogUtil.error("LDAP serverUrl or baseRdn not configured");
                return null;  // Authentication failed
            }

            // 2. Connect to LDAP as admin
            LdapContext ctx = connectLdap(serverUrl, baseRdn, adminId, adminPwd, useSsl);

            // 3. Authenticate user
            boolean authenticated = authenticateUser(ctx, userId, password, baseOu, baseRdn);

            if (!authenticated) {
                ctx.close();
                LogUtil.warn("LDAP authentication failed - invalid credentials for user: " + userId);
                return null;  // Authentication failed
            }

            // 4. Get user group
            String groupId;
            if (!fixedGroup.isEmpty()) {
                // Use fixed group
                groupId = fixedGroup;
            } else {
                // Retrieve from LDAP (first group only for UserData)
                List<String> groups = getUserGroups(ctx, userId, baseOu, groupPrefix);
                groupId = groups.isEmpty() ? "Users" : groups.get(0);
            }

            ctx.close();

            // 5. Return UserData for successful authentication
            LogUtil.info("LDAP authentication successful for user: " + userId);
            return new UserData(userId, password, groupId);

        } catch (Exception e) {
            LogUtil.error("LDAP authentication error for user: " + userId, e);
            return null;  // Authentication failed
        }
    }

    @Override
    public String redirect(String id, String password) {
        // LDAP uses direct authentication, no redirect needed
        return null;
    }

    /**
     * Connect to LDAP server as admin
     */
    private LdapContext connectLdap(String serverUrl, String baseRdn,
                                     String adminId, String adminPwd,
                                     boolean useSsl) throws NamingException {
        Hashtable<String, String> env = new Hashtable<>();
        env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
        env.put(Context.PROVIDER_URL, serverUrl);
        env.put(Context.SECURITY_AUTHENTICATION, "simple");
        env.put(Context.SECURITY_PRINCIPAL, adminId + "," + baseRdn);
        env.put(Context.SECURITY_CREDENTIALS, adminPwd);

        if (useSsl) {
            env.put(Context.SECURITY_PROTOCOL, "ssl");
        }

        return new InitialLdapContext(env, null);
    }

    /**
     * Authenticate user credentials
     */
    private boolean authenticateUser(LdapContext ctx, String userId, String password,
                                      String baseOu, String baseRdn) {
        try {
            // Search for user
            String searchBase = "ou=" + baseOu + "," + baseRdn;
            String searchFilter = "(uid=" + userId + ")";

            SearchControls searchControls = new SearchControls();
            searchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);

            NamingEnumeration<SearchResult> results = ctx.search(searchBase, searchFilter, searchControls);

            if (!results.hasMore()) {
                LogUtil.warn("User not found in LDAP: " + userId);
                return false;
            }

            SearchResult searchResult = results.next();
            String userDn = searchResult.getNameInNamespace();

            // Try to bind with user credentials
            Hashtable<String, String> userEnv = new Hashtable<>();
            userEnv.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
            userEnv.put(Context.PROVIDER_URL, ctx.getEnvironment().get(Context.PROVIDER_URL).toString());
            userEnv.put(Context.SECURITY_AUTHENTICATION, "simple");
            userEnv.put(Context.SECURITY_PRINCIPAL, userDn);
            userEnv.put(Context.SECURITY_CREDENTIALS, password);

            DirContext userCtx = new InitialDirContext(userEnv);
            userCtx.close();

            return true;

        } catch (NamingException e) {
            LogUtil.debug("Authentication failed for user: " + userId);
            return false;
        }
    }

    /**
     * Retrieve user's group memberships
     */
    private List<String> getUserGroups(LdapContext ctx, String userId,
                                        String baseOu, String groupPrefix) {
        List<String> groups = new ArrayList<>();

        try {
            String searchBase = "ou=" + baseOu + "," + ctx.getEnvironment().get("java.naming.provider.url").toString().split("//")[1].split("/")[1];
            String searchFilter = "(uid=" + userId + ")";

            SearchControls searchControls = new SearchControls();
            searchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
            searchControls.setReturningAttributes(new String[]{"memberOf"});

            NamingEnumeration<SearchResult> results = ctx.search(searchBase, searchFilter, searchControls);

            if (results.hasMore()) {
                SearchResult searchResult = results.next();
                Attribute memberOf = searchResult.getAttributes().get("memberOf");

                if (memberOf != null) {
                    NamingEnumeration<?> groupEnum = memberOf.getAll();
                    while (groupEnum.hasMore()) {
                        String groupDn = (String) groupEnum.next();
                        String groupName = extractGroupName(groupDn);

                        // Apply group prefix filter
                        if (matchesGroupPrefix(groupName, groupPrefix)) {
                            groups.add(groupName);
                        }
                    }
                }
            }

        } catch (Exception e) {
            LogUtil.warn("Failed to retrieve groups for user: " + userId, e);
        }

        return groups;
    }

    /**
     * Extract group name from DN (e.g., cn=Admins,ou=Groups,dc=company,dc=com → Admins)
     */
    private String extractGroupName(String groupDn) {
        if (groupDn.startsWith("cn=")) {
            int end = groupDn.indexOf(",");
            if (end > 3) {
                return groupDn.substring(3, end);
            }
        }
        return groupDn;
    }

    /**
     * Check if group name matches prefix filter
     * Example: groupPrefix = "JENNIFER*,APP*"
     */
    private boolean matchesGroupPrefix(String groupName, String groupPrefix) {
        if (groupPrefix.isEmpty()) {
            return true;  // No filter
        }

        String[] prefixes = groupPrefix.split(",");
        for (String prefix : prefixes) {
            String pattern = prefix.trim().replace("*", "");
            if (groupName.startsWith(pattern)) {
                return true;
            }
        }

        return false;
    }
}
