# Event Adapter Template

JENNIFER5 Event Adapter 기본 템플릿입니다.

## 사용 방법

### 1. 프로젝트 생성

```bash
mkdir jennifer-view-adapter-{service}
cd jennifer-view-adapter-{service}
```

### 2. 템플릿 파일 복사

- `pom.xml`: Maven 설정 파일
- `EventAdapter.java`: 메인 어댑터 클래스
- `HttpClientPatterns.java`: HTTP 클라이언트 패턴 참조

### 3. 플레이스홀더 치환

#### pom.xml
- `{SERVICE}`: 서비스 이름 (소문자, 예: slack, teams, discord)

#### EventAdapter.java
- `{SERVICE_LOWER}`: 패키지명 (소문자, 예: slack)
- `{SERVICE_NAME}`: 서비스 이름 (표시용, 예: Slack, Microsoft Teams)
- `{SERVICE_CLASS}`: 클래스명 (PascalCase, 예: Slack, Teams, Discord)
- `{AUTHOR_NAME}`: 작성자 이름
- `{OTHER_OPTIONS}`: 추가 옵션 설명

### 4. buildMessage() 커스터마이징

각 서비스의 메시지 포맷에 맞게 `buildMessage()` 메서드를 수정하세요.

#### Slack 예제 (Attachment)

```java
private String buildMessage(EventData eventData) {
    JsonObject attachment = new JsonObject();
    attachment.addProperty("color", getColor(eventData.getEventLevel()));
    attachment.addProperty("title", "JENNIFER Event: " + eventData.getEventName());
    attachment.addProperty("text", String.format(
        "Domain: %s\\nInstance: %s\\nLevel: %s",
        eventData.getDomainName(),
        eventData.getInstanceName(),
        eventData.getEventLevel()
    ));

    JsonArray attachments = new JsonArray();
    attachments.add(attachment);

    JsonObject message = new JsonObject();
    message.add("attachments", attachments);

    return message.toString();
}
```

#### Microsoft Teams 예제 (Adaptive Card)

```java
private String buildMessage(EventData eventData) {
    String cardJson = String.format(
        "{\"type\":\"message\",\"attachments\":[{" +
        "\"contentType\":\"application/vnd.microsoft.card.adaptive\"," +
        "\"content\":{" +
        "\"type\":\"AdaptiveCard\"," +
        "\"body\":[" +
        "{\"type\":\"TextBlock\",\"text\":\"JENNIFER Event\",\"weight\":\"Bolder\",\"size\":\"Large\"}," +
        "{\"type\":\"TextBlock\",\"text\":\"Domain: %s\"}," +
        "{\"type\":\"TextBlock\",\"text\":\"Instance: %s\"}," +
        "{\"type\":\"TextBlock\",\"text\":\"Event: %s\"}" +
        "]}}]}",
        eventData.getDomainName(),
        eventData.getInstanceName(),
        eventData.getEventName()
    );
    return cardJson;
}
```

#### Telegram 예제 (Markdown)

```java
private String buildMessage(EventData eventData) {
    String text = String.format(
        "*JENNIFER Event*\\n" +
        "*Domain:* %s\\n" +
        "*Instance:* %s\\n" +
        "*Level:* %s\\n" +
        "*Event:* %s",
        eventData.getDomainName(),
        eventData.getInstanceName(),
        eventData.getEventLevel(),
        eventData.getEventName()
    );

    JsonObject message = new JsonObject();
    message.addProperty("chat_id", PropertyUtil.getValue(adapterId, "chat_id", ""));
    message.addProperty("text", text);
    message.addProperty("parse_mode", "Markdown");

    return message.toString();
}
```

### 5. 빌드

```bash
mvn clean package
```

생성된 JAR 파일: `target/jennifer-view-adapter-{service}-1.0.0.jar`

### 6. 배포

```bash
# JENNIFER 서버의 adapter 디렉토리에 복사
cp target/jennifer-view-adapter-{service}-1.0.0.jar $JENNIFER_HOME/adapter/
```

### 7. JENNIFER 관리 UI에서 설정

1. **어댑터 등록**
   - 어댑터 관리 > 추가
   - 타입: Event Adapter
   - JAR 파일 선택

2. **옵션 설정**
   - `webhook_url`: 외부 서비스 Webhook URL (필수)
   - `jennifer_url`: JENNIFER View Server URL (선택, X-View 링크용)

## HTTP 클라이언트 선택 가이드

### HttpURLConnection (권장 - 기본)
- Java 표준 라이브러리
- 외부 의존성 불필요
- 간단한 POST 요청에 최적
- **Slack, Teams, Telegram 등 대부분의 웹훅 어댑터에 적합**

### Apache HttpClient
- 복잡한 인증 필요시 (OAuth, Bearer Token)
- 연결 풀링 필요시
- pom.xml에 의존성 추가:
  ```xml
  <dependency>
      <groupId>org.apache.httpcomponents</groupId>
      <artifactId>httpclient</artifactId>
      <version>4.5.13</version>
  </dependency>
  ```

### OkHttp
- 비동기 처리 필요시
- HTTP/2 지원 필요시
- pom.xml에 의존성 추가:
  ```xml
  <dependency>
      <groupId>com.squareup.okhttp3</groupId>
      <artifactId>okhttp</artifactId>
      <version>4.9.3</version>
  </dependency>
  ```

## EventData API

### 주요 메서드

```java
// Domain & Instance
int getDomainId()
String getDomainName()
int getInstanceId()
String getInstanceName()

// Event Information
String getEventLevel()      // FATAL, WARNING, CRITICAL, INFO
String getEventName()
Object getValue()
long getTime()              // Event occurrence time (Unix timestamp)

// Additional Data
String getMessage()
Map<String, Object> getAdditionalData()
```

## PropertyUtil 사용법

```java
// 기본값과 함께 옵션 가져오기
String webhookUrl = PropertyUtil.getValue(adapterId, "webhook_url", "");
String jenniferUrl = PropertyUtil.getValue(adapterId, "jennifer_url", "");
boolean enabled = Boolean.parseBoolean(PropertyUtil.getValue(adapterId, "enabled", "true"));
int timeout = Integer.parseInt(PropertyUtil.getValue(adapterId, "timeout", "5000"));
```

## 베스트 프랙티스

1. **에러 핸들링**: 모든 예외는 try-catch로 처리하고 로깅
2. **타임아웃 설정**: HTTP 연결 타임아웃 필수 (5-10초 권장)
3. **로깅**: SLF4J Logger 사용 (JENNIFER 서버에 포함)
4. **Null 체크**: eventData 필드는 null일 수 있음
5. **provided scope**: JENNIFER 서버에 포함된 라이브러리는 provided 사용

## 참고 예제

- [Slack Adapter](../../examples/event/slack-adapter.md)
- [Teams Adapter](../../examples/event/teams-adapter.md)
- [Telegram Adapter](../../examples/event/telegram-adapter.md)
- [EventLog Adapter](../../examples/event/eventlog-adapter.md)
