package com.aries.{SERVICE_LOWER};

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * HTTP 클라이언트 패턴 모음
 *
 * 3가지 주요 HTTP 클라이언트 구현 패턴:
 * 1. HttpURLConnection (경량, 외부 의존성 없음)
 * 2. Apache HttpClient (고급 기능, 재사용 가능)
 * 3. OkHttp (현대적 API, 비동기 지원)
 */
public class HttpClientPatterns {

    /**
     * Pattern 1: HttpURLConnection (경량)
     *
     * 장점:
     * - Java 표준 라이브러리 (외부 의존성 불필요)
     * - 가볍고 빠름
     * - 간단한 요청에 최적
     *
     * 단점:
     * - 저수준 API
     * - 연결 풀링 수동 관리
     * - 타임아웃 설정 복잡
     */
    public static void sendWithHttpURLConnection(String webhookUrl, String jsonPayload) throws Exception {
        HttpURLConnection connection = null;
        try {
            URL url = new URL(webhookUrl);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setRequestProperty("User-Agent", "JENNIFER-Adapter/1.0");
            connection.setDoOutput(true);

            // 타임아웃 설정
            connection.setConnectTimeout(5000);  // 5초
            connection.setReadTimeout(10000);    // 10초

            try (OutputStream os = connection.getOutputStream()) {
                os.write(jsonPayload.getBytes(StandardCharsets.UTF_8));
            }

            int responseCode = connection.getResponseCode();
            if (responseCode < 200 || responseCode >= 300) {
                throw new Exception("HTTP request failed with code: " + responseCode);
            }

        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
    }

    /**
     * Pattern 2: Apache HttpClient (고급)
     *
     * 장점:
     * - 풍부한 기능 (인증, 프록시, 쿠키 등)
     * - 자동 연결 풀링
     * - 재사용 가능한 클라이언트 인스턴스
     *
     * 단점:
     * - 외부 의존성 필요 (httpclient 라이브러리)
     * - 더 많은 메모리 사용
     *
     * pom.xml에 추가 필요:
     * <dependency>
     *     <groupId>org.apache.httpcomponents</groupId>
     *     <artifactId>httpclient</artifactId>
     *     <version>4.5.13</version>
     * </dependency>
     */
    public static void sendWithApacheHttpClient(String webhookUrl, String jsonPayload) throws Exception {
        CloseableHttpClient httpClient = HttpClients.createDefault();
        try {
            HttpPost httpPost = new HttpPost(webhookUrl);
            httpPost.setHeader("Content-Type", "application/json");
            httpPost.setHeader("User-Agent", "JENNIFER-Adapter/1.0");
            httpPost.setEntity(new StringEntity(jsonPayload, ContentType.APPLICATION_JSON));

            CloseableHttpResponse response = httpClient.execute(httpPost);
            try {
                int statusCode = response.getStatusLine().getStatusCode();
                if (statusCode < 200 || statusCode >= 300) {
                    throw new Exception("HTTP request failed with code: " + statusCode);
                }
            } finally {
                response.close();
            }
        } finally {
            httpClient.close();
        }
    }

    /**
     * Pattern 2-1: Apache HttpClient (재사용 가능한 인스턴스)
     *
     * 성능 최적화:
     * - HttpClient 인스턴스를 클래스 레벨에서 재사용
     * - 연결 풀링 자동 관리
     * - 멀티스레드 환경에서 안전
     */
    private static final CloseableHttpClient SHARED_HTTP_CLIENT = HttpClients.createDefault();

    public static void sendWithSharedHttpClient(String webhookUrl, String jsonPayload) throws Exception {
        HttpPost httpPost = new HttpPost(webhookUrl);
        httpPost.setHeader("Content-Type", "application/json");
        httpPost.setEntity(new StringEntity(jsonPayload, ContentType.APPLICATION_JSON));

        try (CloseableHttpResponse response = SHARED_HTTP_CLIENT.execute(httpPost)) {
            int statusCode = response.getStatusLine().getStatusCode();
            if (statusCode < 200 || statusCode >= 300) {
                throw new Exception("HTTP request failed with code: " + statusCode);
            }
        }
    }

    /**
     * Pattern 3: OkHttp (현대적)
     *
     * 장점:
     * - 현대적이고 직관적인 API
     * - 비동기 요청 지원
     * - HTTP/2 지원
     * - 자동 재시도 및 리다이렉트
     *
     * 단점:
     * - 외부 의존성 필요 (okhttp 라이브러리)
     *
     * pom.xml에 추가 필요:
     * <dependency>
     *     <groupId>com.squareup.okhttp3</groupId>
     *     <artifactId>okhttp</artifactId>
     *     <version>4.9.3</version>
     * </dependency>
     */
    /*
    public static void sendWithOkHttp(String webhookUrl, String jsonPayload) throws Exception {
        OkHttpClient client = new OkHttpClient.Builder()
            .connectTimeout(5, TimeUnit.SECONDS)
            .writeTimeout(10, TimeUnit.SECONDS)
            .readTimeout(10, TimeUnit.SECONDS)
            .build();

        MediaType JSON = MediaType.get("application/json; charset=utf-8");
        RequestBody body = RequestBody.create(jsonPayload, JSON);

        Request request = new Request.Builder()
            .url(webhookUrl)
            .post(body)
            .addHeader("User-Agent", "JENNIFER-Adapter/1.0")
            .build();

        try (Response response = client.newCall(request).execute()) {
            if (!response.isSuccessful()) {
                throw new Exception("HTTP request failed with code: " + response.code());
            }
        }
    }
    */

    /**
     * 권장 사항:
     *
     * 1. 간단한 어댑터 (Slack, Teams 등):
     *    → HttpURLConnection 사용 (외부 의존성 불필요)
     *
     * 2. 복잡한 인증이 필요한 경우 (OAuth, Bearer Token):
     *    → Apache HttpClient 사용
     *
     * 3. 대량의 이벤트 처리:
     *    → 공유 HttpClient 인스턴스 사용 (연결 풀링)
     *
     * 4. 비동기 처리가 필요한 경우:
     *    → OkHttp 사용
     */
}
