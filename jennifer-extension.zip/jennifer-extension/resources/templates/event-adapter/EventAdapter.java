package com.aries.{SERVICE_LOWER};

import com.aries.extension.data.EventData;
import com.aries.extension.handler.EventHandler;
import com.aries.extension.util.PropertyUtil;
import com.aries.extension.util.LogUtil;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * JENNIFER Event Adapter for {SERVICE_NAME}
 *
 * This adapter sends JENNIFER event notifications to {SERVICE_NAME}.
 *
 * Required Options:
 * - webhook_url: {SERVICE_NAME} webhook URL
 *
 * Optional Options:
 * - jennifer_url: JENNIFER View Server URL for X-View links
 * - {OTHER_OPTIONS}
 *
 * @author {AUTHOR_NAME}
 * @version 1.0
 */
public class {SERVICE_CLASS}Adapter implements EventHandler {

    private String adapterId;

    @Override
    public void setAdapterId(String adapterId) {
        this.adapterId = adapterId;
    }

    @Override
    public void on(EventData[] events) {
        // Batch processing: Handle multiple events at once
        for (EventData eventData : events) {
            try {
                // 1. Get configuration options
            String webhookUrl = PropertyUtil.getValue(adapterId, "webhook_url", "");
            if (webhookUrl.isEmpty()) {
                LogUtil.error("webhook_url is not configured");
                return;
            }

            // 2. Extract event data
            String domainName = eventData.getDomainName();
            String instanceName = eventData.getInstanceName();
            String eventLevel = eventData.getEventLevel();
            String eventName = eventData.getEventName();
            Object value = eventData.getValue();

            // 3. Build message
            String message = buildMessage(eventData);

            // 4. Send to external service
            sendNotification(webhookUrl, message);

            } catch (Exception e) {
                LogUtil.error("Failed to send notification", e);
            }
        }
    }

    /**
     * Build message payload for {SERVICE_NAME}
     */
    private String buildMessage(EventData eventData) {
        StringBuilder sb = new StringBuilder();
        sb.append("{");
        sb.append("\"domain\":\"").append(eventData.getDomainName()).append("\",");
        sb.append("\"instance\":\"").append(eventData.getInstanceName()).append("\",");
        sb.append("\"level\":\"").append(eventData.getEventLevel()).append("\",");
        sb.append("\"event\":\"").append(eventData.getEventName()).append("\"");

        // Add X-View link if jennifer_url is configured
        String xviewUrl = buildXViewUrl(eventData);
        if (xviewUrl != null) {
            sb.append(",\"xview_url\":\"").append(xviewUrl).append("\"");
        }

        sb.append("}");
        return sb.toString();
    }

    /**
     * Build X-View URL for viewing transaction details
     */
    private String buildXViewUrl(EventData eventData) {
        String jenniferUrl = PropertyUtil.getValue(adapterId, "jennifer_url", "");
        if (jenniferUrl.isEmpty()) {
            return null;
        }

        return String.format("%s/popup/xview?domainId=%d&time=%d",
            jenniferUrl,
            eventData.getDomainId(),
            eventData.getTime()
        );
    }

    /**
     * Send HTTP POST request to {SERVICE_NAME}
     */
    private void sendNotification(String webhookUrl, String jsonPayload) throws Exception {
        HttpURLConnection connection = null;
        try {
            URL url = new URL(webhookUrl);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setDoOutput(true);

            try (OutputStream os = connection.getOutputStream()) {
                os.write(jsonPayload.getBytes(StandardCharsets.UTF_8));
            }

            int responseCode = connection.getResponseCode();
            if (responseCode != 200 && responseCode != 201 && responseCode != 204) {
                LogUtil.warn("Unexpected response code: " + responseCode);
            }

        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
    }
}
