# 메시지 포맷 패턴

각 외부 서비스에 맞는 메시지 포맷 패턴 모음입니다.

## 1. Slack

### Attachment 방식 (권장)

Slack은 Attachment를 사용하면 색상, 필드, 버튼 등 풍부한 포맷을 지원합니다.

```java
private String buildSlackMessage(EventData eventData) {
    StringBuilder sb = new StringBuilder();
    sb.append("{");
    sb.append("\"attachments\":[{");

    // 색상 (이벤트 레벨에 따라)
    sb.append("\"color\":\"").append(getSlackColor(eventData.getEventLevel())).append("\",");

    // 제목
    sb.append("\"title\":\"JENNIFER Event: ").append(escapeJson(eventData.getEventName())).append("\",");

    // 본문
    sb.append("\"text\":\"").append(escapeJson(eventData.getMessage())).append("\",");

    // 필드 (Domain, Instance, Level)
    sb.append("\"fields\":[");
    sb.append("{\"title\":\"Domain\",\"value\":\"").append(escapeJson(eventData.getDomainName())).append("\",\"short\":true},");
    sb.append("{\"title\":\"Instance\",\"value\":\"").append(escapeJson(eventData.getInstanceName())).append("\",\"short\":true},");
    sb.append("{\"title\":\"Level\",\"value\":\"").append(eventData.getEventLevel()).append("\",\"short\":true},");
    sb.append("{\"title\":\"Time\",\"value\":\"").append(formatTime(eventData.getTime())).append("\",\"short\":true}");
    sb.append("],");

    // X-View 링크 버튼 (선택)
    String xviewUrl = buildXViewUrl(eventData);
    if (xviewUrl != null) {
        sb.append("\"actions\":[{");
        sb.append("\"type\":\"button\",");
        sb.append("\"text\":\"View X-View\",");
        sb.append("\"url\":\"").append(xviewUrl).append("\"");
        sb.append("}]");
    }

    sb.append("}]}");
    return sb.toString();
}

private String getSlackColor(String eventLevel) {
    switch (eventLevel) {
        case "FATAL":
        case "CRITICAL":
            return "#FF0000";  // 빨간색
        case "WARNING":
            return "#FFA500";  // 주황색
        case "INFO":
        default:
            return "#36A64F";  // 초록색
    }
}
```

### Block Kit 방식 (현대적)

```java
private String buildSlackBlockMessage(EventData eventData) {
    StringBuilder sb = new StringBuilder();
    sb.append("{\"blocks\":[");

    // Header
    sb.append("{\"type\":\"header\",\"text\":{\"type\":\"plain_text\",\"text\":\"JENNIFER Event\"}},");

    // Section with fields
    sb.append("{\"type\":\"section\",\"fields\":[");
    sb.append("{\"type\":\"mrkdwn\",\"text\":\"*Event:*\\n").append(eventData.getEventName()).append("\"},");
    sb.append("{\"type\":\"mrkdwn\",\"text\":\"*Level:*\\n").append(eventData.getEventLevel()).append("\"},");
    sb.append("{\"type\":\"mrkdwn\",\"text\":\"*Domain:*\\n").append(eventData.getDomainName()).append("\"},");
    sb.append("{\"type\":\"mrkdwn\",\"text\":\"*Instance:*\\n").append(eventData.getInstanceName()).append("\"}");
    sb.append("]},");

    // Context (시간 정보)
    sb.append("{\"type\":\"context\",\"elements\":[{\"type\":\"mrkdwn\",\"text\":\"");
    sb.append(formatTime(eventData.getTime())).append("\"}]}");

    sb.append("]}");
    return sb.toString();
}
```

---

## 2. Microsoft Teams

### Adaptive Card 방식

Teams는 Adaptive Card 포맷을 사용합니다.

```java
private String buildTeamsMessage(EventData eventData) {
    StringBuilder sb = new StringBuilder();
    sb.append("{");
    sb.append("\"type\":\"message\",");
    sb.append("\"attachments\":[{");
    sb.append("\"contentType\":\"application/vnd.microsoft.card.adaptive\",");
    sb.append("\"content\":{");
    sb.append("\"type\":\"AdaptiveCard\",");
    sb.append("\"version\":\"1.2\",");

    // Body
    sb.append("\"body\":[");

    // 제목
    sb.append("{\"type\":\"TextBlock\",\"text\":\"JENNIFER Event\",\"weight\":\"Bolder\",\"size\":\"Large\"},");

    // 이벤트 이름
    sb.append("{\"type\":\"TextBlock\",\"text\":\"").append(escapeJson(eventData.getEventName())).append("\",\"size\":\"Medium\",\"color\":\"Accent\"},");

    // FactSet (필드 목록)
    sb.append("{\"type\":\"FactSet\",\"facts\":[");
    sb.append("{\"title\":\"Domain\",\"value\":\"").append(escapeJson(eventData.getDomainName())).append("\"},");
    sb.append("{\"title\":\"Instance\",\"value\":\"").append(escapeJson(eventData.getInstanceName())).append("\"},");
    sb.append("{\"title\":\"Level\",\"value\":\"").append(eventData.getEventLevel()).append("\"},");
    sb.append("{\"title\":\"Time\",\"value\":\"").append(formatTime(eventData.getTime())).append("\"}");
    sb.append("]}");

    sb.append("],");

    // Actions (X-View 링크)
    String xviewUrl = buildXViewUrl(eventData);
    if (xviewUrl != null) {
        sb.append("\"actions\":[{");
        sb.append("\"type\":\"Action.OpenUrl\",");
        sb.append("\"title\":\"View X-View\",");
        sb.append("\"url\":\"").append(xviewUrl).append("\"");
        sb.append("}]");
    }

    sb.append("}");  // content
    sb.append("}]");  // attachments
    sb.append("}");   // root

    return sb.toString();
}
```

### 색상 테마 적용

```java
private String buildTeamsMessageWithTheme(EventData eventData) {
    String themeColor = getTeamsColor(eventData.getEventLevel());

    StringBuilder sb = new StringBuilder();
    sb.append("{");
    sb.append("\"@type\":\"MessageCard\",");
    sb.append("\"@context\":\"https://schema.org/extensions\",");
    sb.append("\"themeColor\":\"").append(themeColor).append("\",");
    sb.append("\"summary\":\"JENNIFER Event\",");
    sb.append("\"title\":\"").append(escapeJson(eventData.getEventName())).append("\",");
    sb.append("\"sections\":[{");
    sb.append("\"facts\":[");
    sb.append("{\"name\":\"Domain\",\"value\":\"").append(escapeJson(eventData.getDomainName())).append("\"},");
    sb.append("{\"name\":\"Instance\",\"value\":\"").append(escapeJson(eventData.getInstanceName())).append("\"},");
    sb.append("{\"name\":\"Level\",\"value\":\"").append(eventData.getEventLevel()).append("\"}");
    sb.append("]}]}");

    return sb.toString();
}

private String getTeamsColor(String eventLevel) {
    switch (eventLevel) {
        case "FATAL":
        case "CRITICAL":
            return "FF0000";  // 빨간색
        case "WARNING":
            return "FFA500";  // 주황색
        case "INFO":
        default:
            return "0078D7";  // Teams 파란색
    }
}
```

---

## 3. Telegram

### Markdown 방식

Telegram은 Markdown 또는 HTML 포맷을 지원합니다.

```java
private String buildTelegramMessage(EventData eventData) {
    String chatId = PropertyUtil.getValue(adapterId, "chat_id", "");

    // Markdown 텍스트 생성
    StringBuilder text = new StringBuilder();
    text.append("🔔 *JENNIFER Event*\\n\\n");
    text.append("*Event:* ").append(escapeTelegramMarkdown(eventData.getEventName())).append("\\n");
    text.append("*Domain:* ").append(escapeTelegramMarkdown(eventData.getDomainName())).append("\\n");
    text.append("*Instance:* ").append(escapeTelegramMarkdown(eventData.getInstanceName())).append("\\n");
    text.append("*Level:* ").append(eventData.getEventLevel()).append("\\n");
    text.append("*Time:* ").append(formatTime(eventData.getTime())).append("\\n");

    // 메시지 객체
    StringBuilder sb = new StringBuilder();
    sb.append("{");
    sb.append("\"chat_id\":\"").append(chatId).append("\",");
    sb.append("\"text\":\"").append(escapeJson(text.toString())).append("\",");
    sb.append("\"parse_mode\":\"Markdown\"");

    // X-View 링크 버튼 (선택)
    String xviewUrl = buildXViewUrl(eventData);
    if (xviewUrl != null) {
        sb.append(",\"reply_markup\":{");
        sb.append("\"inline_keyboard\":[[{");
        sb.append("\"text\":\"View X-View\",");
        sb.append("\"url\":\"").append(xviewUrl).append("\"");
        sb.append("}]]");
        sb.append("}");
    }

    sb.append("}");
    return sb.toString();
}

private String escapeTelegramMarkdown(String text) {
    if (text == null) return "";
    return text.replace("_", "\\_")
               .replace("*", "\\*")
               .replace("[", "\\[")
               .replace("`", "\\`");
}
```

### HTML 방식

```java
private String buildTelegramHtmlMessage(EventData eventData) {
    String chatId = PropertyUtil.getValue(adapterId, "chat_id", "");

    StringBuilder text = new StringBuilder();
    text.append("<b>🔔 JENNIFER Event</b>\\n\\n");
    text.append("<b>Event:</b> ").append(escapeHtml(eventData.getEventName())).append("\\n");
    text.append("<b>Domain:</b> ").append(escapeHtml(eventData.getDomainName())).append("\\n");
    text.append("<b>Instance:</b> ").append(escapeHtml(eventData.getInstanceName())).append("\\n");
    text.append("<b>Level:</b> ").append(eventData.getEventLevel()).append("\\n");

    StringBuilder sb = new StringBuilder();
    sb.append("{");
    sb.append("\"chat_id\":\"").append(chatId).append("\",");
    sb.append("\"text\":\"").append(escapeJson(text.toString())).append("\",");
    sb.append("\"parse_mode\":\"HTML\"");
    sb.append("}");
    return sb.toString();
}
```

---

## 4. LINE

### Flex Message 방식

LINE은 Flex Message를 사용하면 복잡한 레이아웃을 구성할 수 있습니다.

```java
private String buildLineMessage(EventData eventData) {
    StringBuilder sb = new StringBuilder();
    sb.append("{");
    sb.append("\"to\":\"").append(PropertyUtil.getValue(adapterId, "user_id", "")).append("\",");
    sb.append("\"messages\":[{");
    sb.append("\"type\":\"flex\",");
    sb.append("\"altText\":\"JENNIFER Event\",");
    sb.append("\"contents\":{");
    sb.append("\"type\":\"bubble\",");

    // Header
    sb.append("\"header\":{");
    sb.append("\"type\":\"box\",");
    sb.append("\"layout\":\"vertical\",");
    sb.append("\"contents\":[{");
    sb.append("\"type\":\"text\",");
    sb.append("\"text\":\"JENNIFER Event\",");
    sb.append("\"weight\":\"bold\",");
    sb.append("\"size\":\"lg\"");
    sb.append("}]");
    sb.append("},");

    // Body
    sb.append("\"body\":{");
    sb.append("\"type\":\"box\",");
    sb.append("\"layout\":\"vertical\",");
    sb.append("\"contents\":[");
    sb.append("{\"type\":\"text\",\"text\":\"Event: ").append(escapeJson(eventData.getEventName())).append("\"},");
    sb.append("{\"type\":\"text\",\"text\":\"Domain: ").append(escapeJson(eventData.getDomainName())).append("\"},");
    sb.append("{\"type\":\"text\",\"text\":\"Instance: ").append(escapeJson(eventData.getInstanceName())).append("\"},");
    sb.append("{\"type\":\"text\",\"text\":\"Level: ").append(eventData.getEventLevel()).append("\"}");
    sb.append("]");
    sb.append("}");

    sb.append("}");  // contents
    sb.append("}]");  // messages
    sb.append("}");   // root

    return sb.toString();
}
```

---

## 5. Discord

### Embed 방식

Discord는 Embed 객체를 사용하면 풍부한 포맷을 지원합니다.

```java
private String buildDiscordMessage(EventData eventData) {
    StringBuilder sb = new StringBuilder();
    sb.append("{\"embeds\":[{");

    // 제목
    sb.append("\"title\":\"JENNIFER Event\",");
    sb.append("\"description\":\"").append(escapeJson(eventData.getEventName())).append("\",");

    // 색상 (이벤트 레벨에 따라)
    sb.append("\"color\":").append(getDiscordColor(eventData.getEventLevel())).append(",");

    // 필드
    sb.append("\"fields\":[");
    sb.append("{\"name\":\"Domain\",\"value\":\"").append(escapeJson(eventData.getDomainName())).append("\",\"inline\":true},");
    sb.append("{\"name\":\"Instance\",\"value\":\"").append(escapeJson(eventData.getInstanceName())).append("\",\"inline\":true},");
    sb.append("{\"name\":\"Level\",\"value\":\"").append(eventData.getEventLevel()).append("\",\"inline\":true}");
    sb.append("],");

    // 타임스탬프
    sb.append("\"timestamp\":\"").append(formatIso8601(eventData.getTime())).append("\"");

    sb.append("}]}");
    return sb.toString();
}

private int getDiscordColor(String eventLevel) {
    switch (eventLevel) {
        case "FATAL":
        case "CRITICAL":
            return 0xFF0000;  // 빨간색
        case "WARNING":
            return 0xFFA500;  // 주황색
        case "INFO":
        default:
            return 0x00FF00;  // 초록색
    }
}
```

---

## 공통 유틸리티 메서드

### JSON 문자열 이스케이프

```java
private String escapeJson(String text) {
    if (text == null) return "";
    return text.replace("\\", "\\\\")
               .replace("\"", "\\\"")
               .replace("\n", "\\n")
               .replace("\r", "\\r")
               .replace("\t", "\\t");
}
```

### HTML 문자열 이스케이프

```java
private String escapeHtml(String text) {
    if (text == null) return "";
    return text.replace("&", "&amp;")
               .replace("<", "&lt;")
               .replace(">", "&gt;")
               .replace("\"", "&quot;");
}
```

### 시간 포맷팅

```java
import java.text.SimpleDateFormat;
import java.util.Date;

private String formatTime(long timestamp) {
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    return sdf.format(new Date(timestamp));
}

private String formatIso8601(long timestamp) {
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
    return sdf.format(new Date(timestamp));
}
```

---

## 메시지 포맷 비교표

| 서비스 | 포맷 | 색상 | 필드 | 버튼 | 복잡도 |
|-------|------|-----|-----|-----|-------|
| Slack | Attachment / Block Kit | ✅ | ✅ | ✅ | 중간 |
| Teams | Adaptive Card | ✅ | ✅ | ✅ | 높음 |
| Telegram | Markdown / HTML | ❌ | ❌ | ✅ | 낮음 |
| LINE | Flex Message | ✅ | ✅ | ✅ | 높음 |
| Discord | Embed | ✅ | ✅ | ❌ | 중간 |

## 베스트 프랙티스

1. **이스케이프 필수**: 모든 사용자 입력 데이터는 이스케이프 처리
2. **색상 활용**: 이벤트 레벨에 따라 색상 구분 (FATAL=빨강, WARNING=주황, INFO=초록)
3. **X-View 링크**: jennifer_url 설정 시 X-View 링크 버튼 추가
4. **간결함 유지**: 너무 많은 정보는 가독성 저하
5. **타임스탬프**: 이벤트 발생 시간 포함
6. **에러 메시지**: 메시지 생성 실패 시에도 기본 텍스트 전송
