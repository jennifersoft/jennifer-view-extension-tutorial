# HTTP 클라이언트 패턴

JENNIFER Event Adapter에서 외부 서비스로 HTTP 요청을 보내는 3가지 주요 패턴입니다.

## Pattern 1: HttpURLConnection (권장 - 기본)

### 특징
- ✅ Java 표준 라이브러리 (외부 의존성 불필요)
- ✅ 가볍고 빠름
- ✅ 간단한 POST 요청에 최적
- ❌ 저수준 API
- ❌ 연결 풀링 수동 관리

### 사용 예제

```java
private void sendNotification(String webhookUrl, String jsonPayload) throws Exception {
    HttpURLConnection connection = null;
    try {
        URL url = new URL(webhookUrl);
        connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("POST");
        connection.setRequestProperty("Content-Type", "application/json");
        connection.setRequestProperty("User-Agent", "JENNIFER-Adapter/1.0");
        connection.setDoOutput(true);

        // 타임아웃 설정 (필수)
        connection.setConnectTimeout(5000);  // 5초
        connection.setReadTimeout(10000);    // 10초

        try (OutputStream os = connection.getOutputStream()) {
            os.write(jsonPayload.getBytes(StandardCharsets.UTF_8));
        }

        int responseCode = connection.getResponseCode();
        if (responseCode < 200 || responseCode >= 300) {
            LogUtil.warn("HTTP request failed with code: " + responseCode);
        }

    } finally {
        if (connection != null) {
            connection.disconnect();
        }
    }
}
```

### 권장 사용 사례
- Slack, Teams, Telegram 등 웹훅 어댑터
- Discord, LINE 등 간단한 REST API
- 외부 의존성을 최소화하고 싶은 경우

---

## Pattern 2: Apache HttpClient (고급)

### 특징
- ✅ 풍부한 기능 (인증, 프록시, 쿠키 등)
- ✅ 자동 연결 풀링
- ✅ 재사용 가능한 클라이언트 인스턴스
- ❌ 외부 의존성 필요
- ❌ 더 많은 메모리 사용

### pom.xml 의존성

```xml
<dependency>
    <groupId>org.apache.httpcomponents</groupId>
    <artifactId>httpclient</artifactId>
    <version>4.5.13</version>
</dependency>
```

### 기본 사용 예제

```java
private void sendNotification(String webhookUrl, String jsonPayload) throws Exception {
    CloseableHttpClient httpClient = HttpClients.createDefault();
    try {
        HttpPost httpPost = new HttpPost(webhookUrl);
        httpPost.setHeader("Content-Type", "application/json");
        httpPost.setHeader("User-Agent", "JENNIFER-Adapter/1.0");
        httpPost.setEntity(new StringEntity(jsonPayload, ContentType.APPLICATION_JSON));

        CloseableHttpResponse response = httpClient.execute(httpPost);
        try {
            int statusCode = response.getStatusLine().getStatusCode();
            if (statusCode < 200 || statusCode >= 300) {
                LogUtil.warn("HTTP request failed with code: " + statusCode);
            }
        } finally {
            response.close();
        }
    } finally {
        httpClient.close();
    }
}
```

### 재사용 가능한 인스턴스 (성능 최적화)

```java
public class MyAdapter implements EventHandler {

    // 클래스 레벨에서 HttpClient 재사용 (연결 풀링)
    private static final CloseableHttpClient HTTP_CLIENT = HttpClients.createDefault();

    @Override
    public void on(EventData[] events) {
        for (EventData eventData : events) {
            try {
                String webhookUrl = PropertyUtil.getValue(adapterId, "webhook_url", "");
                String message = buildMessage(eventData);

                HttpPost httpPost = new HttpPost(webhookUrl);
                httpPost.setHeader("Content-Type", "application/json");
                httpPost.setEntity(new StringEntity(message, ContentType.APPLICATION_JSON));

                try (CloseableHttpResponse response = HTTP_CLIENT.execute(httpPost)) {
                    int statusCode = response.getStatusLine().getStatusCode();
                    if (statusCode < 200 || statusCode >= 300) {
                        LogUtil.warn("HTTP request failed with code: " + statusCode);
                    }
                }
            } catch (Exception e) {
                LogUtil.error("Failed to send notification", e);
            }
        }
    }
}
```

### 타임아웃 및 리트라이 설정

```java
import org.apache.http.client.config.RequestConfig;
import org.apache.http.impl.client.HttpClientBuilder;

private static final CloseableHttpClient HTTP_CLIENT = HttpClientBuilder.create()
    .setDefaultRequestConfig(RequestConfig.custom()
        .setConnectTimeout(5000)           // 연결 타임아웃: 5초
        .setConnectionRequestTimeout(5000) // 연결 요청 타임아웃: 5초
        .setSocketTimeout(10000)           // 소켓 읽기 타임아웃: 10초
        .build())
    .setRetryHandler((exception, executionCount, context) -> {
        return executionCount < 3;  // 최대 3번 재시도
    })
    .build();
```

### Bearer Token 인증 예제

```java
private void sendWithBearerToken(String apiUrl, String jsonPayload, String token) throws Exception {
    HttpPost httpPost = new HttpPost(apiUrl);
    httpPost.setHeader("Content-Type", "application/json");
    httpPost.setHeader("Authorization", "Bearer " + token);
    httpPost.setEntity(new StringEntity(jsonPayload, ContentType.APPLICATION_JSON));

    try (CloseableHttpResponse response = HTTP_CLIENT.execute(httpPost)) {
        int statusCode = response.getStatusLine().getStatusCode();
        if (statusCode != 200) {
            LogUtil.warn("API request failed with code: " + statusCode);
        }
    }
}
```

### 권장 사용 사례
- OAuth, Bearer Token 등 복잡한 인증 필요
- 프록시 서버 경유 필요
- 대량의 이벤트 처리 (연결 풀링 활용)
- SSL/TLS 커스텀 설정 필요

---

## Pattern 3: OkHttp (현대적)

### 특징
- ✅ 현대적이고 직관적인 API
- ✅ 비동기 요청 지원
- ✅ HTTP/2 지원
- ✅ 자동 재시도 및 리다이렉트
- ❌ 외부 의존성 필요

### pom.xml 의존성

```xml
<dependency>
    <groupId>com.squareup.okhttp3</groupId>
    <artifactId>okhttp</artifactId>
    <version>4.9.3</version>
</dependency>
```

### 동기 요청 예제

```java
import okhttp3.*;

private static final OkHttpClient HTTP_CLIENT = new OkHttpClient.Builder()
    .connectTimeout(5, TimeUnit.SECONDS)
    .writeTimeout(10, TimeUnit.SECONDS)
    .readTimeout(10, TimeUnit.SECONDS)
    .build();

private void sendNotification(String webhookUrl, String jsonPayload) throws Exception {
    MediaType JSON = MediaType.get("application/json; charset=utf-8");
    RequestBody body = RequestBody.create(jsonPayload, JSON);

    Request request = new Request.Builder()
        .url(webhookUrl)
        .post(body)
        .addHeader("User-Agent", "JENNIFER-Adapter/1.0")
        .build();

    try (Response response = HTTP_CLIENT.newCall(request).execute()) {
        if (!response.isSuccessful()) {
            LogUtil.warn("HTTP request failed with code: " + response.code());
        }
    }
}
```

### 비동기 요청 예제 (Non-blocking)

```java
private void sendNotificationAsync(String webhookUrl, String jsonPayload) {
    MediaType JSON = MediaType.get("application/json; charset=utf-8");
    RequestBody body = RequestBody.create(jsonPayload, JSON);

    Request request = new Request.Builder()
        .url(webhookUrl)
        .post(body)
        .build();

    HTTP_CLIENT.newCall(request).enqueue(new Callback() {
        @Override
        public void onFailure(Call call, IOException e) {
            LogUtil.error("Failed to send notification", e);
        }

        @Override
        public void onResponse(Call call, Response response) throws IOException {
            if (!response.isSuccessful()) {
                LogUtil.warn("HTTP request failed with code: " + response.code());
            }
            response.close();
        }
    });
}
```

### Interceptor를 활용한 로깅

```java
private static final OkHttpClient HTTP_CLIENT = new OkHttpClient.Builder()
    .connectTimeout(5, TimeUnit.SECONDS)
    .addInterceptor(chain -> {
        Request request = chain.request();
        long t1 = System.nanoTime();
        LogUtil.debug("Sending request to " + request.url());

        Response response = chain.proceed(request);
        long t2 = System.nanoTime();
        LogUtil.debug("Received response in " + ((t2 - t1) / 1e6d) + "ms");

        return response;
    })
    .build();
```

### 권장 사용 사례
- 비동기 처리가 필요한 경우
- HTTP/2 프로토콜 사용
- 현대적이고 읽기 쉬운 코드 선호
- 인터셉터를 활용한 공통 처리 (로깅, 인증 등)

---

## 비교표

| 특징 | HttpURLConnection | Apache HttpClient | OkHttp |
|-----|------------------|------------------|--------|
| 외부 의존성 | ❌ 불필요 | ✅ 필요 | ✅ 필요 |
| 연결 풀링 | ❌ 수동 | ✅ 자동 | ✅ 자동 |
| 비동기 | ❌ 불가 | ❌ 불가 | ✅ 지원 |
| HTTP/2 | ❌ 불가 | ❌ 불가 | ✅ 지원 |
| 코드 복잡도 | 높음 | 중간 | 낮음 |
| 메모리 사용 | 낮음 | 중간 | 중간 |
| 성능 | 보통 | 좋음 | 매우 좋음 |

## 권장 사항

### 🎯 대부분의 경우
**HttpURLConnection 사용**
- Slack, Teams, Telegram 등 웹훅
- 간단한 REST API 호출
- 외부 의존성 최소화

### 🎯 복잡한 인증 필요
**Apache HttpClient 사용**
- OAuth, Bearer Token
- 프록시 설정
- SSL/TLS 커스터마이징

### 🎯 대량 처리 또는 비동기
**OkHttp 사용**
- 비동기 요청 필요
- HTTP/2 지원 필요
- 인터셉터 활용

## 에러 핸들링 예제

```java
@Override
public void on(EventData[] events) {
    for (EventData eventData : events) {
        try {
            String webhookUrl = PropertyUtil.getValue(adapterId, "webhook_url", "");
            if (webhookUrl.isEmpty()) {
                LogUtil.error("webhook_url is not configured");
                continue;
            }

            String message = buildMessage(eventData);
            sendNotification(webhookUrl, message);

        } catch (java.net.SocketTimeoutException e) {
            LogUtil.error("Timeout while sending notification", e);
        } catch (java.net.UnknownHostException e) {
            LogUtil.error("Unknown host: " + e.getMessage());
        } catch (java.io.IOException e) {
            LogUtil.error("I/O error while sending notification", e);
        } catch (Exception e) {
            LogUtil.error("Unexpected error while sending notification", e);
        }
    }
}
```

## 성능 팁

1. **HttpClient 재사용**: 클래스 레벨에서 static final로 선언
2. **타임아웃 설정**: 연결 타임아웃(5초), 읽기 타임아웃(10초) 권장
3. **연결 풀링**: Apache HttpClient 또는 OkHttp 사용 시 자동 적용
4. **비동기 처리**: 대량의 이벤트 발생 시 OkHttp 비동기 사용
5. **에러 로깅**: 모든 예외는 로깅하되, JENNIFER 서버 동작에 영향 없도록
