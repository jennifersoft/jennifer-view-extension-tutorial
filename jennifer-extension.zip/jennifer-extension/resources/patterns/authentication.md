# 인증 패턴

JENNIFER Login Adapter에서 외부 인증 시스템과 연동하는 패턴입니다.

## Login Adapter 타입

### 1. PAGE 타입 (LoginHandler)
- JENNIFER 로그인 페이지에서 직접 인증 처리
- 사용자가 ID/PW 입력 → Adapter가 외부 시스템과 인증
- 예: LDAP, Active Directory

### 2. SSO 타입 (SSOLoginHandler)
- 외부 시스템에서 인증 후 JENNIFER로 리다이렉트
- URL 파라미터로 인증 정보 전달
- 예: SAML, OAuth, 인증키 기반 SSO

---

## Pattern 1: LDAP 인증 (PAGE 타입)

### 기본 흐름

```
1. 사용자가 JENNIFER 로그인 페이지에서 ID/PW 입력
2. LoginHandler.preHandle(userId, password) 호출
3. LDAP 서버에 연결 (admin 계정)
4. 사용자 검색 (uid=userId)
5. 사용자 DN으로 bind 시도 (패스워드 검증)
6. 성공 시 그룹 정보 조회
7. UserData 객체 반환 (userId와 groups 포함) 또는 null
```

### LDAP 연결

```java
private LdapContext connectLdap(String serverUrl, String baseRdn,
                                 String adminId, String adminPwd,
                                 boolean useSsl) throws NamingException {
    Hashtable<String, String> env = new Hashtable<>();
    env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
    env.put(Context.PROVIDER_URL, serverUrl);
    env.put(Context.SECURITY_AUTHENTICATION, "simple");
    env.put(Context.SECURITY_PRINCIPAL, adminId + "," + baseRdn);
    env.put(Context.SECURITY_CREDENTIALS, adminPwd);

    if (useSsl) {
        env.put(Context.SECURITY_PROTOCOL, "ssl");
        // SSL 설정 (선택)
        // env.put("java.naming.ldap.factory.socket", "MySSLSocketFactory");
    }

    return new InitialLdapContext(env, null);
}
```

### 사용자 인증

```java
private boolean authenticateUser(LdapContext ctx, String userId, String password,
                                  String baseOu, String baseRdn) {
    try {
        // 1. 사용자 검색
        String searchBase = "ou=" + baseOu + "," + baseRdn;
        String searchFilter = "(uid=" + userId + ")";

        SearchControls searchControls = new SearchControls();
        searchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);

        NamingEnumeration<SearchResult> results = ctx.search(searchBase, searchFilter, searchControls);

        if (!results.hasMore()) {
            return false;  // 사용자 없음
        }

        SearchResult searchResult = results.next();
        String userDn = searchResult.getNameInNamespace();

        // 2. 사용자 DN으로 bind 시도 (패스워드 검증)
        Hashtable<String, String> userEnv = new Hashtable<>();
        userEnv.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
        userEnv.put(Context.PROVIDER_URL, ctx.getEnvironment().get(Context.PROVIDER_URL).toString());
        userEnv.put(Context.SECURITY_AUTHENTICATION, "simple");
        userEnv.put(Context.SECURITY_PRINCIPAL, userDn);
        userEnv.put(Context.SECURITY_CREDENTIALS, password);

        DirContext userCtx = new InitialDirContext(userEnv);
        userCtx.close();

        return true;  // 인증 성공

    } catch (NamingException e) {
        return false;  // 인증 실패
    }
}
```

### 그룹 조회

```java
private List<String> getUserGroups(LdapContext ctx, String userId, String baseOu) {
    List<String> groups = new ArrayList<>();

    try {
        String searchBase = "ou=" + baseOu + ",...";
        String searchFilter = "(uid=" + userId + ")";

        SearchControls searchControls = new SearchControls();
        searchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
        searchControls.setReturningAttributes(new String[]{"memberOf"});

        NamingEnumeration<SearchResult> results = ctx.search(searchBase, searchFilter, searchControls);

        if (results.hasMore()) {
            SearchResult searchResult = results.next();
            Attribute memberOf = searchResult.getAttributes().get("memberOf");

            if (memberOf != null) {
                NamingEnumeration<?> groupEnum = memberOf.getAll();
                while (groupEnum.hasMore()) {
                    String groupDn = (String) groupEnum.next();
                    String groupName = extractGroupName(groupDn);
                    groups.add(groupName);
                }
            }
        }

    } catch (Exception e) {
        LogUtil.warn("Failed to retrieve groups", e);
    }

    return groups;
}

private String extractGroupName(String groupDn) {
    // cn=Admins,ou=Groups,dc=company,dc=com → Admins
    if (groupDn.startsWith("cn=")) {
        int end = groupDn.indexOf(",");
        if (end > 3) {
            return groupDn.substring(3, end);
        }
    }
    return groupDn;
}
```

### 그룹 필터링

```java
/**
 * Group prefix filter: "JENNIFER*,APP*"
 * Only groups starting with JENNIFER or APP will be included
 */
private boolean matchesGroupPrefix(String groupName, String groupPrefix) {
    if (groupPrefix.isEmpty()) {
        return true;  // No filter
    }

    String[] prefixes = groupPrefix.split(",");
    for (String prefix : prefixes) {
        String pattern = prefix.trim().replace("*", "");
        if (groupName.startsWith(pattern)) {
            return true;
        }
    }

    return false;
}
```

---

## Pattern 2: Active Directory 인증

### AD 특화 설정

```java
// Active Directory는 LDAP과 유사하지만 몇 가지 차이점 존재

// 1. 사용자 검색 필터 (sAMAccountName 사용)
String searchFilter = "(sAMAccountName=" + userId + ")";

// 2. Principal 형식 (UPN 방식)
String userPrincipal = userId + "@" + domain;  // user@company.com

// 3. 그룹 속성
// memberOf: 사용자가 속한 그룹들
// member: 그룹에 속한 사용자들
```

---

## Pattern 3: SSO 인증 (인증키 기반)

### 기본 흐름

```
1. 사용자가 외부 시스템 로그인
2. 외부 시스템이 JENNIFER Plugin API 호출하여 인증키 생성
3. 외부 시스템이 JENNIFER SSO URL로 리다이렉트 (인증키 포함)
4. SSOLoginHandler.preHandle(request) 호출
5. 인증키 검증 (타임아웃 체크)
6. 검증 성공 시 JENNIFER 계정으로 매핑
7. UserData 객체 반환 (jenniferUserId 포함) 또는 null
```

### 인증키 생성 (외부 시스템)

```java
/**
 * External system generates auth key via JENNIFER Plugin API
 */
public String generateAuthKey(String userId, String deviceId, String salt) {
    try {
        long timestamp = System.currentTimeMillis();
        String data = timestamp + userId + deviceId + salt;

        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hash = digest.digest(data.getBytes("UTF-8"));

        StringBuilder hexString = new StringBuilder();
        for (byte b : hash) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) hexString.append('0');
            hexString.append(hex);
        }

        String authKey = hexString.toString();

        // Store auth key in JENNIFER (via Plugin API)
        storeAuthKey(userId, deviceId, authKey, timestamp);

        return authKey;

    } catch (Exception e) {
        throw new RuntimeException("Failed to generate auth key", e);
    }
}
```

### SSO URL 리다이렉트

```
http://jennifer.company.com:7900/sso/login?user_id=user@company.com&device_id=device123&auth_key=abc123def456...
```

### 인증키 검증

```java
@Override
public UserData preHandle(HttpServletRequest request) {
    try {
        // 1. Extract parameters
        String userId = request.getParameter("user_id");
        String deviceId = request.getParameter("device_id");
        String authKey = request.getParameter("auth_key");

        // 2. Get configuration
        String jenniferUserId = PropertyUtil.getValue(adapterId, "JENNIFER_USER_ID", "guest");
        long timeout = Long.parseLong(PropertyUtil.getValue(adapterId, "VALIDATE_TIMEOUT", "5000"));

        // 3. Validate auth key
        if (!validateAuthKey(userId, deviceId, authKey, timeout)) {
            LogUtil.warn("Invalid authentication key for user: " + userId);
            return null;  // 인증 실패
        }

        // 4. Map to JENNIFER account
        UserData userData = new UserData();
        userData.setUserId(jenniferUserId);
        return userData;

    } catch (Exception e) {
        LogUtil.error("SSO error", e);
        return null;  // 인증 실패
    }
}

private boolean validateAuthKey(String userId, String deviceId, String authKey, long timeout) {
    // Get stored auth key
    String storedAuthKey = getStoredAuthKey(userId, deviceId);

    if (!authKey.equals(storedAuthKey)) {
        return false;
    }

    // Check expiration
    long createdTime = getAuthKeyTimestamp(authKey);
    if (System.currentTimeMillis() - createdTime > timeout) {
        return false;  // Expired
    }

    return true;
}
```

---

## Pattern 4: SAML 2.0 SSO (고급)

### SAML 흐름

```
1. 사용자가 JENNIFER 접속
2. JENNIFER가 IdP로 SAML Request 전송
3. IdP에서 사용자 인증
4. IdP가 JENNIFER로 SAML Response 전송 (Assertion 포함)
5. SSOLoginHandler가 Assertion 검증
6. 성공 시 JENNIFER 계정으로 매핑
```

### SAML Assertion 검증 (간단 예시)

```java
import org.opensaml.saml.saml2.core.Assertion;
import org.opensaml.saml.saml2.core.Response;

@Override
public UserData preHandle(HttpServletRequest request) {
    try {
        String samlResponse = request.getParameter("SAMLResponse");

        // Parse SAML Response
        Response response = parseSamlResponse(samlResponse);

        // Validate signature
        if (!validateSignature(response)) {
            LogUtil.warn("Invalid SAML signature");
            return null;  // 인증 실패
        }

        // Extract user info
        Assertion assertion = response.getAssertions().get(0);
        String userId = assertion.getSubject().getNameID().getValue();

        // Map to JENNIFER
        String jenniferUserId = PropertyUtil.getValue(adapterId, "JENNIFER_USER_ID", "guest");

        UserData userData = new UserData();
        userData.setUserId(jenniferUserId);
        return userData;

    } catch (Exception e) {
        LogUtil.error("SAML error", e);
        return null;  // 인증 실패
    }
}
```

---

## 보안 고려사항

### 1. 패스워드 보안
```java
// ❌ 나쁜 예: 패스워드 로깅
LogUtil.info("Authenticating user: " + userId + " with password: " + password);

// ✅ 좋은 예: 패스워드 로깅 금지
LogUtil.info("Authenticating user: " + userId);
```

### 2. SSL/TLS 사용
```java
// LDAP over SSL (LDAPS)
env.put(Context.PROVIDER_URL, "ldaps://ldap.company.com:636");
env.put(Context.SECURITY_PROTOCOL, "ssl");
```

### 3. 타임아웃 설정
```java
// LDAP 연결 타임아웃
env.put("com.sun.jndi.ldap.connect.timeout", "5000");  // 5초
env.put("com.sun.jndi.ldap.read.timeout", "10000");     // 10초
```

### 4. 인증키 만료
```java
// SSO 인증키는 짧은 유효기간 설정 (5-10초)
long timeout = 5000;  // 5초
```

---

## UserData 사용법

### 성공 (PAGE 타입)
```java
UserData userData = new UserData();
userData.setUserId(userId);
List<String> groups = Arrays.asList("Admins", "Developers");
userData.setGroups(groups);
return userData;
```

### 성공 (SSO 타입)
```java
UserData userData = new UserData();
userData.setUserId("jennifer_admin");
return userData;
```

### 실패
```java
LogUtil.warn("Invalid credentials");
return null;  // 인증 실패

LogUtil.error("LDAP connection failed");
return null;  // 인증 실패

LogUtil.warn("Auth key expired");
return null;  // 인증 실패
```

---

## 베스트 프랙티스

1. **패스워드 로깅 금지**: 절대 패스워드를 로그에 기록하지 않기
2. **SSL/TLS 사용**: LDAP over SSL (ldaps://) 권장
3. **타임아웃 설정**: 외부 시스템 응답 대기 타임아웃 필수
4. **에러 메시지 일반화**: 보안상 상세 에러 정보 노출 금지
5. **그룹 필터링**: 필요한 그룹만 매핑
6. **고정 그룹 옵션**: LDAP 조회 실패 시 대체 방안
7. **인증키 만료**: SSO 인증키는 짧은 유효기간 설정

---

## 트러블슈팅

### LDAP 연결 실패
```
Error: javax.naming.CommunicationException
→ 방화벽 확인, LDAP 서버 주소 확인
```

### 사용자 검색 실패
```
Error: User not found
→ baseOu 확인, searchFilter 확인
```

### 인증 실패
```
Error: Invalid credentials
→ 패스워드 확인, 사용자 계정 잠금 상태 확인
```

### SSL 인증서 오류
```
Error: SSLHandshakeException
→ Java Keystore에 인증서 추가 필요
```
