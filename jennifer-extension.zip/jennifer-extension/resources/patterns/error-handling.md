# 에러 핸들링 패턴

JENNIFER Adapter에서 안전하고 견고한 에러 처리 방법입니다.

## 핵심 원칙

> **어댑터의 에러는 절대 JENNIFER 서버의 동작을 멈추게 해서는 안 됩니다.**

1. 모든 예외는 `on()` 메서드 내에서 catch
2. 예외 발생 시 로깅만 하고 정상 return
3. 외부 서비스 장애가 JENNIFER 모니터링에 영향 없도록

---

## Pattern 1: 기본 에러 핸들링

### 최소한의 안전 장치

```java
@Override
public void on(EventData[] events) {
    for (EventData eventData : events) {
        try {
            // 어댑터 로직
            String webhookUrl = PropertyUtil.getValue(adapterId, "webhook_url", "");
            String message = buildMessage(eventData);
            sendNotification(webhookUrl, message);

        } catch (Exception e) {
            // 에러 로깅 후 정상 종료
            LogUtil.error("Failed to send notification", e);
        }
    }
}
```

### 문제점
- 모든 에러를 동일하게 처리
- 재시도 가능한 에러도 포기
- 근본 원인 파악 어려움

---

## Pattern 2: 세분화된 에러 핸들링 (권장)

### 에러 유형별 처리

```java
@Override
public void on(EventData[] events) {
    for (EventData eventData : events) {
        try {
            // 1. 설정 검증
            String webhookUrl = PropertyUtil.getValue(adapterId, "webhook_url", "");
            if (webhookUrl.isEmpty()) {
                LogUtil.error("webhook_url is not configured");
                continue;
            }

            // 2. 메시지 생성
            String message = buildMessage(eventData);

            // 3. 전송
            sendNotification(webhookUrl, message);

        } catch (IllegalArgumentException e) {
            // 설정 오류: 관리자가 수정 필요
            LogUtil.error("Invalid configuration: " + e.getMessage());

        } catch (java.net.SocketTimeoutException e) {
            // 타임아웃: 일시적 네트워크 문제
            LogUtil.warn("Timeout while sending notification to " +
                         eventData.getEventName() + ": " + e.getMessage());

        } catch (java.net.UnknownHostException e) {
            // DNS 오류: webhook URL 확인 필요
            LogUtil.error("Unknown host (check webhook_url): " + e.getMessage());

        } catch (java.io.IOException e) {
            // I/O 오류: 네트워크 문제
            LogUtil.error("I/O error while sending notification: " + e.getMessage(), e);

        } catch (com.google.gson.JsonSyntaxException e) {
            // JSON 파싱 오류: 메시지 포맷 문제
            LogUtil.error("Failed to build JSON message: " + e.getMessage());

        } catch (Exception e) {
            // 기타 예외
            LogUtil.error("Unexpected error while sending notification", e);
        }
    }
}
```

---

## Pattern 3: 재시도 로직

### 간단한 재시도

```java
@Override
public void on(EventData[] events) {
    for (EventData eventData : events) {
        try {
            String webhookUrl = PropertyUtil.getValue(adapterId, "webhook_url", "");
            String message = buildMessage(eventData);

            // 최대 3번 재시도
            sendWithRetry(webhookUrl, message, 3);

        } catch (Exception e) {
            LogUtil.error("Failed to send notification after retries", e);
        }
    }
}

private void sendWithRetry(String webhookUrl, String message, int maxRetries) throws Exception {
    Exception lastException = null;

    for (int i = 0; i < maxRetries; i++) {
        try {
            sendNotification(webhookUrl, message);
            return;  // 성공 시 리턴

        } catch (java.net.SocketTimeoutException e) {
            lastException = e;
            LogUtil.warn("Attempt " + (i + 1) + " failed due to timeout, retrying...");

            // 재시도 전 대기 (exponential backoff)
            if (i < maxRetries - 1) {
                Thread.sleep((long) Math.pow(2, i) * 1000);  // 1초, 2초, 4초
            }

        } catch (Exception e) {
            // 재시도 불가능한 에러는 즉시 throw
            throw e;
        }
    }

    // 모든 재시도 실패
    throw lastException;
}
```

### 설정 가능한 재시도

```java
@Override
public void on(EventData[] events) {
    for (EventData eventData : events) {
        try {
            String webhookUrl = PropertyUtil.getValue(adapterId, "webhook_url", "");
            int maxRetries = Integer.parseInt(PropertyUtil.getValue(adapterId, "max_retries", "3"));
            int retryDelay = Integer.parseInt(PropertyUtil.getValue(adapterId, "retry_delay_ms", "1000"));

            String message = buildMessage(eventData);
            sendWithConfigurableRetry(webhookUrl, message, maxRetries, retryDelay);

        } catch (Exception e) {
            LogUtil.error("Failed to send notification", e);
        }
    }
}

private void sendWithConfigurableRetry(String webhookUrl, String message,
                                        int maxRetries, int retryDelay) throws Exception {
    for (int i = 0; i < maxRetries; i++) {
        try {
            sendNotification(webhookUrl, message);
            return;

        } catch (java.net.SocketTimeoutException | java.io.IOException e) {
            if (i < maxRetries - 1) {
                LogUtil.warn("Retry " + (i + 1) + "/" + maxRetries + " after " + retryDelay + "ms");
                Thread.sleep(retryDelay);
            } else {
                throw e;  // 마지막 시도 실패 시 예외 전파
            }
        }
    }
}
```

---

## Pattern 4: Circuit Breaker (고급)

외부 서비스가 다운되었을 때 계속 요청하지 않도록 차단하는 패턴입니다.

```java
public class MyAdapter implements EventHandler {

    // Circuit Breaker 상태
    private static volatile boolean circuitOpen = false;
    private static volatile long circuitOpenTime = 0;
    private static final long CIRCUIT_TIMEOUT = 60000;  // 1분 후 재시도

    @Override
    public void on(EventData[] events) {
        for (EventData eventData : events) {
            try {
                // Circuit이 열려있으면 요청 건너뛰기
                if (isCircuitOpen()) {
                    LogUtil.warn("Circuit is open, skipping notification");
                    continue;
                }

                String webhookUrl = PropertyUtil.getValue(adapterId, "webhook_url", "");
                String message = buildMessage(eventData);
                sendNotification(webhookUrl, message);

                // 성공 시 Circuit 닫기
                closeCircuit();

            } catch (Exception e) {
                LogUtil.error("Failed to send notification", e);
                // 실패 시 Circuit 열기
                openCircuit();
            }
        }
    }

    private boolean isCircuitOpen() {
        if (!circuitOpen) {
            return false;
        }

        // 타임아웃 시간이 지나면 Circuit 재시도
        if (System.currentTimeMillis() - circuitOpenTime > CIRCUIT_TIMEOUT) {
            LogUtil.info("Circuit timeout expired, attempting to close circuit");
            circuitOpen = false;
            return false;
        }

        return true;
    }

    private void openCircuit() {
        if (!circuitOpen) {
            LogUtil.warn("Opening circuit due to failures");
            circuitOpen = true;
            circuitOpenTime = System.currentTimeMillis();
        }
    }

    private void closeCircuit() {
        if (circuitOpen) {
            LogUtil.info("Closing circuit after successful request");
            circuitOpen = false;
        }
    }
}
```

---

## Pattern 5: Fallback 처리

### 기본 메시지로 대체

```java
@Override
public void on(EventData[] events) {
    for (EventData eventData : events) {
        try {
            String webhookUrl = PropertyUtil.getValue(adapterId, "webhook_url", "");

            String message;
            try {
                // 복잡한 메시지 생성 시도
                message = buildRichMessage(eventData);
            } catch (Exception e) {
                // 실패 시 기본 메시지로 대체
                LogUtil.warn("Failed to build rich message, using simple message", e);
                message = buildSimpleMessage(eventData);
            }

            sendNotification(webhookUrl, message);

        } catch (Exception e) {
            LogUtil.error("Failed to send notification", e);
        }
    }
}

private String buildSimpleMessage(EventData eventData) {
    return String.format(
        "{\"text\":\"JENNIFER Event: %s - %s\"}",
        eventData.getEventName(),
        eventData.getDomainName()
    );
}
```

---

## Pattern 6: 비동기 에러 핸들링

### OkHttp 비동기 사용 시

```java
private void sendNotificationAsync(String webhookUrl, String jsonPayload) {
    Request request = new Request.Builder()
        .url(webhookUrl)
        .post(RequestBody.create(jsonPayload, MediaType.get("application/json")))
        .build();

    HTTP_CLIENT.newCall(request).enqueue(new Callback() {
        @Override
        public void onFailure(Call call, IOException e) {
            // 네트워크 오류
            if (e instanceof SocketTimeoutException) {
                LogUtil.warn("Async request timed out: " + e.getMessage());
            } else if (e instanceof UnknownHostException) {
                LogUtil.error("Unknown host: " + e.getMessage());
            } else {
                LogUtil.error("Async request failed", e);
            }
        }

        @Override
        public void onResponse(Call call, Response response) throws IOException {
            try {
                if (!response.isSuccessful()) {
                    LogUtil.warn("HTTP request failed with code: " + response.code());

                    // 응답 본문 읽기 (에러 메시지 포함 가능)
                    if (response.body() != null) {
                        String errorBody = response.body().string();
                        LogUtil.debug("Error response: " + errorBody);
                    }
                }
            } finally {
                response.close();
            }
        }
    });
}
```

---

## Pattern 7: 로깅 레벨 전략

### 적절한 로그 레벨 사용

```java
@Override
public void on(EventData[] events) {
    for (EventData eventData : events) {
        try {
            // DEBUG: 디버깅용 상세 정보
            LogUtil.debug("Processing event: " + eventData.getEventName() +
                         " for domain: " + eventData.getDomainName());

            String webhookUrl = PropertyUtil.getValue(adapterId, "webhook_url", "");

            // WARN: 설정 누락 (관리자 확인 필요)
            if (webhookUrl.isEmpty()) {
                LogUtil.warn("webhook_url is not configured, skipping notification");
                continue;
            }

            String message = buildMessage(eventData);
            sendNotification(webhookUrl, message);

            // INFO: 성공 (선택적)
            LogUtil.info("Notification sent successfully for event: " + eventData.getEventName());

        } catch (SocketTimeoutException e) {
            // WARN: 일시적 네트워크 문제
            LogUtil.warn("Timeout sending notification: " + e.getMessage());

        } catch (UnknownHostException e) {
            // ERROR: 설정 오류 (webhook_url 잘못됨)
            LogUtil.error("Invalid webhook URL: " + e.getMessage());

        } catch (Exception e) {
            // ERROR: 예상치 못한 오류 (스택 트레이스 포함)
            LogUtil.error("Unexpected error sending notification", e);
        }
    }
}
```

### 로그 레벨 가이드

| 레벨 | 사용 사례 | 예시 |
|------|----------|------|
| DEBUG | 디버깅용 상세 정보 | 이벤트 데이터, 메시지 내용 |
| INFO | 정상 동작 정보 | 알림 전송 성공 |
| WARN | 일시적 문제, 설정 누락 | 타임아웃, 옵션 미설정 |
| ERROR | 심각한 오류 | 예외 발생, 설정 오류 |

---

## Pattern 8: Null Safety

### Null 체크 패턴

```java
private String buildMessage(EventData eventData) {
    StringBuilder sb = new StringBuilder();
    sb.append("{");

    // Null-safe 문자열 가져오기
    String domainName = eventData.getDomainName();
    sb.append("\"domain\":\"").append(domainName != null ? domainName : "Unknown").append("\",");

    String instanceName = eventData.getInstanceName();
    sb.append("\"instance\":\"").append(instanceName != null ? instanceName : "Unknown").append("\",");

    String eventName = eventData.getEventName();
    sb.append("\"event\":\"").append(eventName != null ? eventName : "Unknown").append("\"");

    sb.append("}");
    return sb.toString();
}
```

### Optional 사용 (Java 8+)

```java
import java.util.Optional;

private String buildXViewUrl(EventData eventData) {
    return Optional.ofNullable(PropertyUtil.getValue(adapterId, "jennifer_url", null))
        .filter(url -> !url.isEmpty())
        .map(url -> String.format("%s/popup/xview?domainId=%d&time=%d",
                                    url,
                                    eventData.getDomainId(),
                                    eventData.getTime()))
        .orElse(null);
}
```

---

## 종합 예제

### 모든 패턴을 적용한 견고한 어댑터

```java
public class RobustAdapter implements EventHandler {
    private String adapterId;

    // Circuit Breaker
    private static volatile boolean circuitOpen = false;
    private static volatile long circuitOpenTime = 0;
    private static final long CIRCUIT_TIMEOUT = 60000;

    @Override
    public void setAdapterId(String adapterId) {
        this.adapterId = adapterId;
    }

    @Override
    public void on(EventData[] events) {
        for (EventData eventData : events) {
            try {
                // 1. Circuit Breaker 체크
                if (isCircuitOpen()) {
                    LogUtil.warn("Circuit open, skipping notification");
                    continue;
                }

                // 2. 설정 검증
                String webhookUrl = PropertyUtil.getValue(adapterId, "webhook_url", "");
                if (webhookUrl.isEmpty()) {
                    LogUtil.warn("webhook_url not configured");
                    continue;
                }

                // 3. 메시지 생성 (fallback 포함)
                String message = buildMessageWithFallback(eventData);

                // 4. 재시도와 함께 전송
                int maxRetries = Integer.parseInt(PropertyUtil.getValue(adapterId, "max_retries", "3"));
                sendWithRetry(webhookUrl, message, maxRetries);

                // 5. 성공 시 Circuit 닫기
                closeCircuit();

            } catch (SocketTimeoutException e) {
                LogUtil.warn("Timeout: " + e.getMessage());
                openCircuit();

            } catch (UnknownHostException e) {
                LogUtil.error("Invalid webhook URL: " + e.getMessage());

            } catch (Exception e) {
                LogUtil.error("Failed to send notification", e);
                openCircuit();
            }
        }
    }

    private String buildMessageWithFallback(EventData eventData) {
        try {
            return buildRichMessage(eventData);
        } catch (Exception e) {
            LogUtil.warn("Fallback to simple message", e);
            return buildSimpleMessage(eventData);
        }
    }

    // ... (기타 메서드)
}
```

---

## 베스트 프랙티스

1. **절대 throw 금지**: `on()` 메서드에서 예외를 밖으로 던지지 않기 (배열의 각 이벤트를 처리할 때도 continue 사용)
2. **세분화된 catch**: 예외 유형별로 적절한 처리
3. **재시도 신중히**: 타임아웃, I/O 에러만 재시도
4. **Circuit Breaker**: 외부 서비스 다운 시 불필요한 요청 방지
5. **Fallback**: 복잡한 처리 실패 시 간단한 대안 제공
6. **적절한 로깅**: DEBUG/INFO/WARN/ERROR 레벨 구분
7. **Null Safety**: 모든 외부 입력은 null 체크
8. **타임아웃 필수**: HTTP 요청은 반드시 타임아웃 설정
