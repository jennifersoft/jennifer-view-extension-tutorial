# 파일 로깅 패턴

Transaction Adapter에서 실시간 트랜잭션 데이터를 파일로 저장하는 패턴입니다.

## 핵심 고려사항

1. **Thread Safety**: 여러 스레드가 동시에 파일에 쓰기 가능
2. **성능**: 대량의 트랜잭션 발생 시 I/O 성능 최적화 필요
3. **롤링**: 파일 크기 또는 시간 기반 자동 롤링
4. **버퍼링**: 메모리 버퍼를 활용한 성능 향상

---

## Pattern 1: 기본 파일 쓰기

### 간단한 append 모드

```java
@Override
public void on(TransactionData[] transactions) {
    for (TransactionData txData : transactions) {
        try {
            String logPath = PropertyUtil.getValue(adapterId, "log_path", "../logs/xview.log");
            String logMessage = buildLogMessage(txData);

            try (FileWriter fw = new FileWriter(logPath, true)) {
                fw.write(logMessage);
                fw.write(System.lineSeparator());
            }

        } catch (IOException e) {
            LogUtil.error("Failed to write log", e);
        }
    }
}
```

### 문제점
- ❌ Thread-safe하지 않음
- ❌ 매번 파일 열고 닫기 (성능 저하)
- ❌ 롤링 지원 없음

---

## Pattern 2: BufferedWriter (성능 최적화)

### 버퍼링을 통한 성능 향상

```java
private synchronized void writeLog(String logPath, String message) throws IOException {
    try (FileWriter fw = new FileWriter(logPath, true);
         BufferedWriter bw = new BufferedWriter(fw)) {
        bw.write(message);
        bw.newLine();
    }
}
```

### 장점
- ✅ 메모리 버퍼 사용으로 I/O 최적화
- ✅ `synchronized`로 thread-safe
- ✅ try-with-resources로 자동 close

---

## Pattern 3: 날짜 기반 롤링

### 시간 단위 로그 파일 자동 생성

```java
/**
 * Resolve date pattern in file path
 * Example: ../logs/xview.%d{yyyy-MM-dd_HH}.log → ../logs/xview.2025-11-10_14.log
 */
private String resolveDatePattern(String path) {
    if (!path.contains("%d{")) {
        return path;
    }

    // Find pattern
    int start = path.indexOf("%d{");
    int end = path.indexOf("}", start);

    if (start == -1 || end == -1) {
        return path;
    }

    // Extract date format
    String datePattern = path.substring(start + 3, end);
    SimpleDateFormat sdf = new SimpleDateFormat(datePattern);
    String dateStr = sdf.format(new Date());

    // Replace pattern with actual date
    return path.substring(0, start) + dateStr + path.substring(end + 1);
}
```

### 사용 예제

```java
@Override
public void on(TransactionData[] transactions) {
    for (TransactionData txData : transactions) {
        try {
            String pathPattern = PropertyUtil.getValue(adapterId, "log_path",
                                                        "../logs/xview.%d{yyyy-MM-dd_HH}.log");
            String actualPath = resolveDatePattern(pathPattern);
            String logMessage = buildLogMessage(txData);

            writeLog(actualPath, logMessage);

        } catch (Exception e) {
            LogUtil.error("Failed to write log", e);
        }
    }
}
```

### 날짜 패턴 예시

| 패턴 | 결과 예시 | 롤링 주기 |
|------|----------|----------|
| `%d{yyyy-MM-dd}` | `xview.2025-11-10.log` | 일 단위 |
| `%d{yyyy-MM-dd_HH}` | `xview.2025-11-10_14.log` | 시간 단위 |
| `%d{yyyy-MM-dd_HH-mm}` | `xview.2025-11-10_14-30.log` | 분 단위 |
| `%d{yyyy-ww}` | `xview.2025-45.log` | 주 단위 |

---

## Pattern 4: 크기 기반 롤링

### 파일 크기 제한 및 자동 롤링

```java
public class SizeBasedRollingAdapter implements TransactionHandler {
    private static final long MAX_FILE_SIZE = 100 * 1024 * 1024;  // 100MB

    @Override
    public void on(TransactionData[] transactions) {
        for (TransactionData txData : transactions) {
            try {
                String logPath = PropertyUtil.getValue(adapterId, "log_path", "../logs/xview.log");
                File logFile = new File(logPath);

                // Check file size and rotate if needed
                if (logFile.exists() && logFile.length() > MAX_FILE_SIZE) {
                    rotateLogFile(logFile);
                }

                String logMessage = buildLogMessage(txData);
                writeLog(logPath, logMessage);

            } catch (Exception e) {
                LogUtil.error("Failed to write log", e);
            }
        }
    }

    /**
     * Rotate log file: xview.log → xview.log.1, xview.log.2, ...
     */
    private synchronized void rotateLogFile(File logFile) throws IOException {
        String basePath = logFile.getAbsolutePath();

        // Rotate existing backup files
        for (int i = 9; i > 0; i--) {
            File oldFile = new File(basePath + "." + i);
            if (oldFile.exists()) {
                File newFile = new File(basePath + "." + (i + 1));
                oldFile.renameTo(newFile);
            }
        }

        // Rotate current file to .1
        File backupFile = new File(basePath + ".1");
        logFile.renameTo(backupFile);

        LogUtil.info("Log file rotated: " + logFile.getName() + " → " + backupFile.getName());
    }
}
```

---

## Pattern 5: 비동기 쓰기 (고급)

### 별도 스레드에서 비동기 파일 쓰기

```java
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class AsyncLoggingAdapter implements TransactionHandler {
    private static final BlockingQueue<String> logQueue = new LinkedBlockingQueue<>(10000);
    private static final ExecutorService executor = Executors.newSingleThreadExecutor();

    private String adapterId;

    // Start async writer thread
    static {
        executor.submit(new LogWriter());
    }

    @Override
    public void on(TransactionData[] transactions) {
        for (TransactionData txData : transactions) {
            try {
                String logMessage = buildLogMessage(txData);

                // Add to queue (non-blocking)
                if (!logQueue.offer(logMessage)) {
                    LogUtil.warn("Log queue is full, dropping message");
                }

            } catch (Exception e) {
                LogUtil.error("Failed to enqueue log message", e);
            }
        }
    }

    /**
     * Background thread for writing logs
     */
    private static class LogWriter implements Runnable {
        @Override
        public void run() {
            while (true) {
                try {
                    // Take from queue (blocking)
                    String message = logQueue.take();

                    // Write to file
                    String logPath = "../logs/xview.log";  // Get from config
                    try (FileWriter fw = new FileWriter(logPath, true);
                         BufferedWriter bw = new BufferedWriter(fw)) {
                        bw.write(message);
                        bw.newLine();
                    }

                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                } catch (Exception e) {
                    LogUtil.error("Failed to write log", e);
                }
            }
        }
    }
}
```

### 장점
- ✅ 메인 스레드 블로킹 없음 (빠른 응답)
- ✅ 큐 기반 버퍼링
- ✅ 단일 스레드로 파일 쓰기 (순서 보장)

### 주의사항
- ⚠️ 큐 오버플로우 시 메시지 손실 가능
- ⚠️ JENNIFER 서버 종료 시 큐에 남은 메시지 처리 필요

---

## Pattern 6: 배치 쓰기

### 여러 로그를 모아서 한 번에 쓰기

```java
public class BatchLoggingAdapter implements TransactionHandler {
    private static final List<String> logBuffer = new ArrayList<>();
    private static final int BATCH_SIZE = 100;
    private static final long FLUSH_INTERVAL = 5000;  // 5초

    private static long lastFlushTime = System.currentTimeMillis();

    @Override
    public synchronized void on(TransactionData[] transactions) {
        for (TransactionData txData : transactions) {
            try {
                String logMessage = buildLogMessage(txData);
                logBuffer.add(logMessage);

                // Flush if batch size reached or time elapsed
                if (logBuffer.size() >= BATCH_SIZE ||
                    System.currentTimeMillis() - lastFlushTime > FLUSH_INTERVAL) {
                    flushLogs();
                }

            } catch (Exception e) {
                LogUtil.error("Failed to buffer log", e);
            }
        }
    }

    /**
     * Write all buffered logs at once
     */
    private void flushLogs() throws IOException {
        if (logBuffer.isEmpty()) {
            return;
        }

        String logPath = "../logs/xview.log";  // Get from config

        try (FileWriter fw = new FileWriter(logPath, true);
             BufferedWriter bw = new BufferedWriter(fw)) {

            for (String message : logBuffer) {
                bw.write(message);
                bw.newLine();
            }

            LogUtil.debug("Flushed " + logBuffer.size() + " log entries");
            logBuffer.clear();
            lastFlushTime = System.currentTimeMillis();
        }
    }
}
```

---

## Pattern 7: 압축 로깅

### Gzip 압축을 활용한 디스크 공간 절약

```java
import java.util.zip.GZIPOutputStream;

private void writeCompressedLog(String logPath, String message) throws IOException {
    try (FileOutputStream fos = new FileOutputStream(logPath + ".gz", true);
         GZIPOutputStream gzos = new GZIPOutputStream(fos);
         OutputStreamWriter osw = new OutputStreamWriter(gzos, StandardCharsets.UTF_8);
         BufferedWriter bw = new BufferedWriter(osw)) {

        bw.write(message);
        bw.newLine();
    }
}
```

---

## 로그 포맷 패턴

### 변수 치환 시스템

```java
private static final String DEFAULT_PATTERN =
    "[%startTime, %endTime] " +
    "Domain=%domainName, " +
    "Instance=%instanceName, " +
    "TXID=%txid, " +
    "Response Time=%responseTime ms, " +
    "SQL Time=%sqlTime ms, " +
    "ERROR=%error";

private String buildLogMessage(TransactionData txData, String pattern) {
    SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");

    return pattern
        .replace("%startTime", sdf.format(new Date(txData.getStartTime())))
        .replace("%endTime", sdf.format(new Date(txData.getEndTime())))
        .replace("%domainName", nvl(txData.getDomainName()))
        .replace("%instanceName", nvl(txData.getInstanceName()))
        .replace("%txid", String.valueOf(txData.getTxid()))
        .replace("%responseTime", String.valueOf(txData.getResponseTime()))
        .replace("%sqlTime", String.valueOf(txData.getSqlTime()))
        .replace("%error", nvl(txData.getError()));
}
```

### 지원 변수 목록

#### 시간 필드
- `%startTime`: 트랜잭션 시작 시간
- `%endTime`: 트랜잭션 종료 시간
- `%collectTime`: 수집 시간

#### Domain & Instance
- `%domainId`: Domain ID
- `%domainName`: Domain 이름
- `%instanceId`: Instance ID
- `%instanceName`: Instance 이름

#### 트랜잭션 정보
- `%txid`: 트랜잭션 ID
- `%clientIp`: 클라이언트 IP
- `%clientId`: 클라이언트 ID
- `%userId`: 사용자 ID
- `%application`: 애플리케이션 이름

#### 성능 지표
- `%responseTime`: 응답 시간
- `%frontendTime`: 프론트엔드 시간
- `%networkTime`: 네트워크 시간
- `%sqlTime`: SQL 시간
- `%fetchTime`: Fetch 시간
- `%cpuTime`: CPU 시간
- `%externalcallTime`: 외부 호출 시간

#### 에러
- `%error`: 에러 메시지

---

## 성능 비교

| 패턴 | TPS | 메모리 | 순서 보장 | 데이터 손실 위험 |
|------|-----|--------|----------|----------------|
| 기본 FileWriter | ~500 | 낮음 | ✅ | 낮음 |
| BufferedWriter | ~2,000 | 낮음 | ✅ | 낮음 |
| 비동기 쓰기 | ~10,000 | 중간 | ✅ | 중간 (큐 오버플로우) |
| 배치 쓰기 | ~5,000 | 중간 | ✅ | 낮음 |
| 압축 로깅 | ~1,000 | 높음 | ✅ | 낮음 |

---

## 베스트 프랙티스

1. **기본은 BufferedWriter**: 대부분의 경우 충분한 성능
2. **synchronized 필수**: Thread-safe 보장
3. **try-with-resources**: 자동 리소스 해제
4. **날짜 롤링 권장**: 관리 및 백업 용이
5. **에러 처리**: 파일 쓰기 실패 시에도 JENNIFER 서버는 정상 동작
6. **큐 크기 제한**: 비동기 쓰기 시 메모리 부족 방지
7. **주기적 flush**: 배치 쓰기 시 데이터 손실 방지

## 권장 설정

### 일반적인 환경 (TPS < 1,000)
```java
// BufferedWriter + 시간별 롤링
full_path = ../logs/xview.%d{yyyy-MM-dd_HH}.log
rolling_mode = true
```

### 고부하 환경 (TPS > 5,000)
```java
// 비동기 쓰기 + 배치
queue_size = 10000
batch_size = 100
flush_interval = 5000
```

### 디스크 공간 부족
```java
// 압축 로깅 + 일별 롤링
full_path = ../logs/xview.%d{yyyy-MM-dd}.log.gz
compression = true
```
